
// syndra.ts
export class Syndra {
  orb: PortalOrb;

  constructor() {
    this.orb = new PortalOrb();
  }

  summonOrb(): void {
    this.orb.create();
  }

  pushOrb(direction: Vector): void {
    this.orb.move(direction);
  }
}

export class PortalOrb {
  position: Vector;
  active: boolean;

  constructor() {
    this.position = new Vector(0, 0);
    this.active = false;
  }

  create(): void {
    this.active = true;
    console.log("🌀 Orb created. Portal begins to shimmer.");
  }

  move(direction: Vector): void {
    if (this.active) {
      this.position.x += direction.x;
      this.position.y += direction.y;
      console.log("🌠 Orb pushed. Moving to:", this.position);
    }
  }

  dissipate(): void {
    this.active = false;
    console.log("✨ Portal faded. Gate sealed.");
  }
}

export class Vector {
  constructor(public x: number, public y: number) {}
}
