
// portal-ritual.ts
import { Syndra, Vector } from "./syndra";

const syndra = new Syndra();

function performPortalRitual() {
  syndra.summonOrb(); // Step 1: create orb
  syndra.pushOrb(new Vector(3, 2)); // Step 2: push orb
  setTimeout(() => {
    syndra.orb.dissipate(); // Step 3: fade orb
  }, 3000);
}

performPortalRitual();
