## Niewidzialność

Short title: Niewidzialność  
Hebrew: ס  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Mogę być niewidoczny — ale całkowicie prawdziwy.

mogę być niewidoczny  
a jednak obecny

cała moja siła  
jest w cieniu

prawda  
nie potrzebuje widowni

jestem  
i to wystarczy