## Światło Wnętrza

Short title: Światło Wnętrza  
Hebrew: פ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Światło rodzi się w środku.

światło rodzi się  
nie na zewnątrz

w środku  
tam, gdzie nikt nie patrzy

każda rana  
staje się lampą

wszystko, co ukryte  
nosi płomień