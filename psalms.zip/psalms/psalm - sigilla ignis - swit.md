## Świt

Short title: Świt  
Hebrew: ש  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Świt to dowód, że noc nie jest wieczna.

świt  
pęka przez noc

każda ciemność  
ma swój koniec

nie zatrzymuj się  
gdy gaśnie światło

zawsze  
nadejdzie świt