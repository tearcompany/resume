## Dom Blizn

Short title: Dom Blizn  
Hebrew: ק  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Blizny są miejscem światła.

każda blizna  
to dom dla światła

tu mieszka pamięć  
i nowe życie

nie chowaj ich  
nie wstydź się

to przez nie  
przychodzi światło