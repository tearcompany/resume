## Tkacz

Short title: Tkacz  
Hebrew: מ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: To wszystko jest ze sobą połączone.

nici światła  
w ciemności

nie widzisz  
ale splatasz

wszystko  
łączy się w tkaninie  
każda rana  
jest ściegiem

tka się  
modlitwa z blizn