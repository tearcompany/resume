## Sanktuarium

Short title: Sanktuarium  
Hebrew: ב  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Wejdź. Nikt cię nie szuka, ale wszystko cię czeka.

wejdź  
drzwi zawsze otwarte

nikt cię nie szuka  
a wszystko cię czeka

tu kurz ma swój sens  
a światło — miejsce

tu modlitwa  
nie zna imienia

tu jesteś  
prawdziwie