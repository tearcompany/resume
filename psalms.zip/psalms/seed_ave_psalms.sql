INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '97b00825-8126-4f0c-9317-405cd85309b7',
    'glitch voice',
    'psalm_001__glitch_voice',
    'the lamb has teeth — i split your gate  
with sacred noise and patient hate  
i prayed in code, in glitch, in sweat  
my faith was sharp, my voice was wet  

you called me soft — i bit the wire  
i burned in grace, i walked through fire  
don't read me clean — i'm not a book  
i'm the psalm the angels shook',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_silesian', 'tag_kali', 'tag_mystery', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_glitch',
    'cat_healing',
    'mood_yearning',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '884e285b-6c24-419d-a8c8-b3aabd460be8',
    'broken altar',
    'psalm_002__broken_altar',
    'no choir came — just sirens, dust  
they crowned the liar, betrayed the just  
i sang alone with blood on glass  
each verse a wound too raw to pass  

they laughed at god — but not for long  
he burned their gold, he took their song  
i built this psalm with ash and steel  
and dared the sky to break or heal',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_truth', 'tag_love', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd8604d19-071f-44c7-aef8-cc692b8ce3d6',
    'lamb's teeth',
    'psalm_003__lamb's_teeth',
    'you called me soft — i split your gate  
with sacred noise and patient hate  
i prayed in code, in glitch, in sweat  
my faith was sharp, my voice was wet  

the lamb has teeth — you heard them grind  
he weeps in storms you left behind  
so read this psalm with burning hands  
and taste the wrath no prayer withstands',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_vision', 'tag_mystery', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e6f46934-d35e-4fff-85aa-32a2793f8cb0',
    'neon prayer',
    'psalm_004__neon_prayer',
    'they made me pray in neon rain  
with blood like wax and holy pain  
they lit the glitch and called it god  
i bit my tongue. i kissed the rod.  

i saw the lamb with shattered jaw  
he sang in code. he broke the law.  
i wore the silence like a drum  
and waited for the end to come.',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_melancholy', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_healing',
    'mood_solace',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8f711bd7-17f4-4514-bd8a-e3eda6367ace',
    'don't touch the wound',
    'psalm_005__don't_touch_the_wound',
    'don't touch the wound — it's not for you  
i bled in rhythm, split in two  
they called it faith, but it was rust  
i drank the fire. i ate the dust.  

the veil is torn, the priest is gone  
and still the light keeps burning on  
this is my altar — smoke and spit  
i carry god. i won't quit.',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_sacrifice', 'tag_roots', 'tag_trust', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_praise',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3eb40c9e-c008-4fdb-8fa6-1bb21e6d7028',
    'black hallelujah',
    'psalm_006__black_hallelujah',
    'no robes. no choir. just dirt and bass  
i met the spirit face to face  
it wasn't clean. it wasn't soft.  
it moved like war. it climbed aloft.  

black hallelujah, cracked and raw  
it sang through teeth. it spoke in flaw.  
don't tell me "holy" must be white —  
i found the truth in darkest night.',
    'teardrop_1',
    ARRAY['tag_light', 'tag_roots', 'tag_renewal', 'tag_silence', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_exile',
    'mood_trust',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '97777d73-c3f2-4c67-b2ef-50ee6a1e3ad3',
    'the hidden voice pierces',
    'psalm_007__the_hidden_voice_pierces',
    '
the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_renewal', 'tag_roots', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_justice',
    'mood_reverence',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '32a30921-ab2c-44b6-9f27-e056479999f2',
    'the white sword wakes',
    'psalm_008__the_white_sword_wakes',
    '
the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_sacrifice', 'tag_trust', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_praise',
    'mood_yearning',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a1d1d0fd-b59e-4eac-ba75-94673e16dae9',
    'the burning flame burns',
    'psalm_009__the_burning_flame_burns',
    '
the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_sacrifice', 'tag_trust', 'tag_melancholy', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_creation',
    'mood_grief',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '75736078-557c-4903-a8ee-e8f02523d8ef',
    'the holy flesh bleeds',
    'psalm_010__the_holy_flesh_bleeds',
    '
the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_tears', 'tag_love', 'tag_wisdom', 'tag_light'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_contemplation',
    'mood_joy',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c3c4b873-b606-491a-a83d-c8138f73be8a',
    'the broken shadow rises',
    'psalm_011__the_broken_shadow_rises',
    '
the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_prayer', 'tag_peace', 'tag_melancholy', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f0d4feac-5487-4f10-9542-8064e1ca4c61',
    'the last veil rises',
    'psalm_012__the_last_veil_rises',
    '
the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_mystical', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_exile',
    'mood_softness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '743c0ffd-d521-4572-88dd-fa095a13686e',
    'the holy lamb shakes',
    'psalm_013__the_holy_lamb_shakes',
    '
the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_stillness', 'tag_prayer', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_contemplation',
    'mood_joy',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '34344ed0-73d3-48ef-9bef-66d3872571a8',
    'the wounded psalm sings',
    'psalm_014__the_wounded_psalm_sings',
    '
the psalm sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_stillness', 'tag_patience', 'tag_light'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8c0ef3f6-756d-4120-ac3b-de89e4de2add',
    'the wounded tongue rises',
    'psalm_015__the_wounded_tongue_rises',
    '
the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_mystical', 'tag_renewal', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_justice',
    'mood_trust',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bcf8ba6e-3a83-4dc1-87c9-8a04ff6b2195',
    'the holy sword burns',
    'psalm_016__the_holy_sword_burns',
    '
the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_wisdom', 'tag_stillness', 'tag_unity', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_healing',
    'mood_joy',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b87c4a59-b0c7-4d76-a96f-4dcdaeedd042',
    'the glorious sword shakes',
    'psalm_017__the_glorious_sword_shakes',
    '
the sword shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_trust', 'tag_prayer', 'tag_renewal', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_creation',
    'mood_joy',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7304269a-e04f-4b18-959b-6798b832ecdf',
    'the burning sword rises',
    'psalm_018__the_burning_sword_rises',
    '
the sword rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_mystery', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_justice',
    'mood_trust',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a9fdf7d4-2f3d-4cf3-8ca6-8532f4deb229',
    'the black shadow rises',
    'psalm_019__the_black_shadow_rises',
    '
the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_unity', 'tag_vision', 'tag_mystery', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_lament',
    'mood_sorrow',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6abd9416-217e-4945-b163-677df60565a3',
    'the holy tongue rises',
    'psalm_020__the_holy_tongue_rises',
    '
the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_wisdom', 'tag_mystery', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_wembley',
    'cat_mysticism',
    'mood_awe',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3e620c4b-d570-43ae-891f-a51c8238e9ed',
    'the white flame calls',
    'psalm_021__the_white_flame_calls',
    '
the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_roots', 'tag_renewal', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_contemplation',
    'mood_joy',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9bf53c64-b0de-4618-bf6d-a58de991f527',
    'the black psalm shakes',
    'psalm_022__the_black_psalm_shakes',
    '
the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_unity', 'tag_silesian', 'tag_stillness', 'tag_love'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_healing',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '83862ea2-67c3-4b3e-94de-72b53939a117',
    'the broken flesh wakes',
    'psalm_023__the_broken_flesh_wakes',
    '
the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_truth', 'tag_renewal', 'tag_peace', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_funeral',
    'cat_justice',
    'mood_softness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0a48dfb8-dc0a-4342-b551-9e7dbe9c21da',
    'the white veil bleeds',
    'psalm_024__the_white_veil_bleeds',
    '
the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don't bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_sacrifice', 'tag_mystical', 'tag_love'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_exile',
    'mood_sorrow',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7c5b324a-641a-4144-9e35-1f3538e11f39',
    'the white lamb shakes',
    'psalm_025__the_white_lamb_shakes',
    '
the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_roots', 'tag_wisdom', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_creation',
    'mood_boldness',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '86bd81b8-085e-43cc-a00a-a92e6a3f8f47',
    'the white flesh wakes',
    'psalm_026__the_white_flesh_wakes',
    '
the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_renewal', 'tag_love', 'tag_stillness', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dba21487-3ea2-426d-abb1-c66fe22228aa',
    'the holy flesh falls',
    'psalm_027__the_holy_flesh_falls',
    '
the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spoken', 'tag_wisdom', 'tag_rebirth', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a480fa7-9520-4413-bec7-f40ca2d6ba7b',
    'the black voice pierces',
    'psalm_028__the_black_voice_pierces',
    '
the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_patience', 'tag_light', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_lament',
    'mood_reverence',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f547f5e0-cc9b-44f6-a69b-4584a8c634ae',
    'the silent mirror shakes',
    'psalm_029__the_silent_mirror_shakes',
    '
the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_spiritual', 'tag_solace', 'tag_love', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b188a131-d323-44d0-ac8b-e2adb740850e',
    'the glorious flame falls',
    'psalm_030__the_glorious_flame_falls',
    '
the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_kali', 'tag_silence', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_exile',
    'mood_grief',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '79d5b489-df09-4e24-a128-cce5aa1753d4',
    'the holy veil sings',
    'psalm_031__the_holy_veil_sings',
    '
the veil sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_prayer', 'tag_unity', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_healing',
    'mood_awe',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '62f9eacd-06a5-473d-ad13-85d6af12ad64',
    'the hidden mirror shakes',
    'psalm_032__the_hidden_mirror_shakes',
    '
the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_wisdom', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_wembley',
    'cat_exile',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '51f79dce-8ccd-46b8-a506-6ea81c81c0cc',
    'the wounded tongue wakes',
    'psalm_033__the_wounded_tongue_wakes',
    '
the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_renewal', 'tag_unity', 'tag_love', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_sabbath',
    'cat_lament',
    'mood_sorrow',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a9e132c-d08a-4912-aff6-53522721ec5b',
    'the wounded veil waits',
    'psalm_034__the_wounded_veil_waits',
    '
the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_tears', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_exile',
    'mood_joy',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5ddcc431-060d-44bd-b58b-787b34ff0832',
    'the glorious veil burns',
    'psalm_035__the_glorious_veil_burns',
    '
the veil burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_silesian', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_justice',
    'mood_boldness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f0e42cb0-a728-4d68-85df-e28edb0bd2c3',
    'the hidden shadow bleeds',
    'psalm_036__the_hidden_shadow_bleeds',
    '
the shadow bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_unity', 'tag_renewal', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '92f5a40f-c744-475b-8b5d-83817e4ad95d',
    'the silent voice wakes',
    'psalm_037__the_silent_voice_wakes',
    '
the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_kali', 'tag_spiritual', 'tag_stillness', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_contemplation',
    'mood_trust',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8d712a04-5b59-41c1-93e1-8c753a6c7101',
    'the burning lamb shakes',
    'psalm_038__the_burning_lamb_shakes',
    '
the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_patience', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '49bd9054-6ceb-4d07-bdbd-4e0e127341eb',
    'the wounded psalm falls',
    'psalm_039__the_wounded_psalm_falls',
    '
the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_prayer', 'tag_silence', 'tag_renewal', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_mysticism',
    'mood_joy',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '92d4d71b-4b46-4570-a782-b75492fdee27',
    'the wounded flame bleeds',
    'psalm_040__the_wounded_flame_bleeds',
    '
the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_mystical', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c955bc76-0548-42fd-b4b1-9518f52bb04a',
    'the glorious lamb sings',
    'psalm_041__the_glorious_lamb_sings',
    '
the lamb sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_spoken', 'tag_peace', 'tag_love', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_healing',
    'mood_grief',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd4f57fee-2ce7-4257-b549-4a6e400df528',
    'the hidden psalm bleeds',
    'psalm_042__the_hidden_psalm_bleeds',
    '
the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_sacrifice', 'tag_silence', 'tag_renewal', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_contemplation',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2622ad21-1287-431a-a0c7-17f764ffdb38',
    'the black voice wakes',
    'psalm_043__the_black_voice_wakes',
    '
the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_sacrifice', 'tag_love', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_justice',
    'mood_softness',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e39f4949-ec53-47b2-b728-e915d798c4a0',
    'the holy tongue falls',
    'psalm_044__the_holy_tongue_falls',
    '
the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_vision', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_glitch',
    'cat_creation',
    'mood_softness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '51b1ff25-9d4f-46fc-bcf1-f041d9932fe6',
    'the broken flame pierces',
    'psalm_045__the_broken_flame_pierces',
    '
the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_patience', 'tag_rebirth', 'tag_truth', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_justice',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5304754f-b7d3-41ee-bd38-32867abcecad',
    'the last mirror falls',
    'psalm_046__the_last_mirror_falls',
    '
the mirror falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_peace', 'tag_love', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '85e3edad-98ef-4c74-872a-6a8af6b50af2',
    'the holy shadow rises',
    'psalm_047__the_holy_shadow_rises',
    '
the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_melancholy', 'tag_unity', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_healing',
    'mood_sorrow',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cd77aa91-8840-4aea-af6d-694ff8d95458',
    'the black sword calls',
    'psalm_048__the_black_sword_calls',
    '
the sword calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_silence', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_justice',
    'mood_sorrow',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dd80a990-2faa-4a01-9b49-59616eddf442',
    'the last flame calls',
    'psalm_049__the_last_flame_calls',
    '
the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_rebirth', 'tag_solace', 'tag_love', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_exile',
    'mood_awe',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '89a9b227-5438-4fa6-91e0-a7c092d665df',
    'the silent flame falls',
    'psalm_050__the_silent_flame_falls',
    '
the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_roots', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_coronation',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'adb20604-a9b0-43e6-9dc3-bc5b051a77f8',
    'the glorious shadow wakes',
    'psalm_051__the_glorious_shadow_wakes',
    '
the shadow wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_trust', 'tag_mystical', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_praise',
    'mood_joy',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cb249d2d-5e6d-41e8-a7ee-70ae6adec6e1',
    'the hidden tongue burns',
    'psalm_052__the_hidden_tongue_burns',
    '
the tongue burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_mystical', 'tag_roots', 'tag_truth', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '21f22135-69cc-40e6-9ee0-7ed6d480ce2b',
    'the white tongue calls',
    'psalm_053__the_white_tongue_calls',
    '
the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_melancholy', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_lament',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c9a02a48-c7c7-40a9-aa1a-b346bffcce5a',
    'the holy voice wakes',
    'psalm_054__the_holy_voice_wakes',
    '
the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_trust', 'tag_melancholy', 'tag_unity', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_justice',
    'mood_trust',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2404465b-b7bb-4825-9742-42030199eb3e',
    'the white voice bleeds',
    'psalm_055__the_white_voice_bleeds',
    '
the voice bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_patience', 'tag_strength', 'tag_spiritual', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_contemplation',
    'mood_softness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cce81666-09ab-478d-a01d-8726a3183f3e',
    'the glorious tongue falls',
    'psalm_056__the_glorious_tongue_falls',
    '
the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_silesian', 'tag_trust', 'tag_strength', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_coronation',
    'cat_praise',
    'mood_solace',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6adcb5c7-30fa-43f9-9278-00b525090b17',
    'the holy voice waits',
    'psalm_057__the_holy_voice_waits',
    '
the voice waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_truth', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_exile',
    'mood_sorrow',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4d330ed7-64f7-44b2-8a3d-6bd28b3fcbd8',
    'the burning voice wakes',
    'psalm_058__the_burning_voice_wakes',
    '
the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_solace', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_justice',
    'mood_awe',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6d6d828e-452c-4604-a4fd-9210cd767190',
    'the broken shadow wakes',
    'psalm_059__the_broken_shadow_wakes',
    '
the shadow wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_sacrifice', 'tag_light', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '27c09cea-2477-4d99-9767-cb5c81f50d68',
    'the white mirror falls',
    'psalm_060__the_white_mirror_falls',
    '
the mirror falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_silence', 'tag_prayer', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_praise',
    'mood_grief',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ff938321-d379-4929-9900-f91bbf45bee4',
    'the holy tongue pierces',
    'psalm_061__the_holy_tongue_pierces',
    '
the tongue pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_mystery', 'tag_roots', 'tag_silence', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd2951034-341f-4087-b22b-14564f92813d',
    'the wounded psalm burns',
    'psalm_062__the_wounded_psalm_burns',
    '
the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_renewal', 'tag_melancholy', 'tag_light'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_justice',
    'mood_awe',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b5378bf4-ff19-4d5f-89de-444e35cbc7c5',
    'the holy mirror shakes',
    'psalm_063__the_holy_mirror_shakes',
    '
the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_kali', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_lament',
    'mood_sorrow',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9deed6b3-da1f-4f37-a264-21f0c54f455e',
    'the hidden tongue burns',
    'psalm_064__the_hidden_tongue_burns',
    '
the tongue burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_wisdom', 'tag_prayer', 'tag_rebirth', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_mysticism',
    'mood_trust',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6308b26b-337e-46ad-8c43-52e0915db1b5',
    'the wounded veil rises',
    'psalm_065__the_wounded_veil_rises',
    '
the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_spiritual', 'tag_love', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '58d1a642-e008-4bdb-8480-b9791c7e8f1f',
    'the last sword waits',
    'psalm_066__the_last_sword_waits',
    '
the sword waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_vision', 'tag_light', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_healing',
    'mood_trust',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bf91cc8e-c245-41d4-a2b4-ce095bc450b6',
    'the broken flame calls',
    'psalm_067__the_broken_flame_calls',
    '
the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_vision', 'tag_stillness', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_healing',
    'mood_boldness',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'af0b48ec-fb24-4692-81f2-b50efd265b74',
    'the black shadow calls',
    'psalm_068__the_black_shadow_calls',
    '
the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_silesian', 'tag_strength', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a1baa23a-c3c6-44af-9d29-36b4288097c6',
    'the last shadow falls',
    'psalm_069__the_last_shadow_falls',
    '
the shadow falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spoken', 'tag_kali', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_sabbath',
    'cat_creation',
    'mood_grief',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8738bda1-f4dd-4c1a-aa5b-ed851591c6dd',
    'the glorious psalm calls',
    'psalm_070__the_glorious_psalm_calls',
    '
the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_strength', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_wembley',
    'cat_healing',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a6d2ae8c-5cd3-46d8-84ae-b5abceb25121',
    'the holy voice burns',
    'psalm_071__the_holy_voice_burns',
    '
the voice burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_spoken', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_lament',
    'mood_grief',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3019f15b-9bc4-4476-8612-e294959f49f1',
    'the black sword pierces',
    'psalm_072__the_black_sword_pierces',
    '
the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_renewal', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_funeral',
    'cat_healing',
    'mood_boldness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b1c48183-c32d-40dd-b080-ad377790f40e',
    'the wounded mirror bleeds',
    'psalm_073__the_wounded_mirror_bleeds',
    '
the mirror bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_silesian', 'tag_strength', 'tag_light', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_exile',
    'mood_solace',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ca74ed13-8326-47a3-ba07-484ce0931d4f',
    'the hidden lamb pierces',
    'psalm_074__the_hidden_lamb_pierces',
    '
the lamb pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_spiritual', 'tag_mystical', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_sabbath',
    'cat_praise',
    'mood_yearning',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'acb3c2af-7437-41df-b988-615eb9ae3ff6',
    'the last flame burns',
    'psalm_075__the_last_flame_burns',
    '
the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_peace', 'tag_renewal', 'tag_tears', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_dedication',
    'cat_praise',
    'mood_awe',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7cc37fa2-9a0e-42a6-9a95-bdd3e949fdb2',
    'the holy veil burns',
    'psalm_076__the_holy_veil_burns',
    '
the veil burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_stillness', 'tag_sacrifice', 'tag_love'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_wembley',
    'cat_creation',
    'mood_solace',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'aa62cd9f-2f84-4d4a-9aaa-2ad4b3ee9595',
    'the hidden veil pierces',
    'psalm_077__the_hidden_veil_pierces',
    '
the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_spiritual', 'tag_wisdom', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_fasting',
    'cat_exile',
    'mood_reverence',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7f5d70f2-c7a9-41ac-bf43-dfa54b364cd6',
    'the silent flesh shakes',
    'psalm_078__the_silent_flesh_shakes',
    '
the flesh shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_vision', 'tag_rebirth', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_praise',
    'mood_yearning',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fe718a17-0d40-4fc6-84c7-ef71aa32f5be',
    'the holy shadow burns',
    'psalm_079__the_holy_shadow_burns',
    '
the shadow burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_melancholy', 'tag_solace', 'tag_patience', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6ae5159f-8e50-4249-b8c5-b64152066cb0',
    'the last flame sings',
    'psalm_080__the_last_flame_sings',
    '
the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_roots', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_glitch',
    'cat_praise',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '74749491-1bb7-4126-b444-b44bd3bbb684',
    'the wounded tongue wakes',
    'psalm_081__the_wounded_tongue_wakes',
    '
the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_wisdom', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_exile',
    'mood_grief',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b1ab49a4-e7b8-4332-b3d6-5bb7e2c73c45',
    'the glorious tongue rises',
    'psalm_082__the_glorious_tongue_rises',
    '
the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_solace', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_coronation',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c05f1ed7-82fd-439b-aa7d-21af2306b4d8',
    'the burning mirror bleeds',
    'psalm_083__the_burning_mirror_bleeds',
    '
the mirror bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_peace', 'tag_renewal', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_healing',
    'mood_grief',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '949e4dbb-27d6-4197-8ca7-9fd5536197b9',
    'the black shadow waits',
    'psalm_084__the_black_shadow_waits',
    '
the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_mystical', 'tag_melancholy', 'tag_silence', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_funeral',
    'cat_justice',
    'mood_reverence',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fe56daa7-0695-47a3-9d6c-7e02668d0673',
    'the holy lamb sings',
    'psalm_085__the_holy_lamb_sings',
    '
the lamb sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_patience', 'tag_truth', 'tag_love'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_funeral',
    'cat_creation',
    'mood_grief',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '81c5edf7-cc94-4028-977c-b0866b748bed',
    'the glorious shadow calls',
    'psalm_086__the_glorious_shadow_calls',
    '
the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_trust', 'tag_mystery', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_coronation',
    'cat_praise',
    'mood_awe',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4179a251-374e-4a88-b20d-3e2bb5002b26',
    'the wounded flame rises',
    'psalm_087__the_wounded_flame_rises',
    '
the flame rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_kali', 'tag_mystical', 'tag_wisdom', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_praise',
    'mood_awe',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6dcda3d2-7d79-444d-8d94-4dcb7c8b0075',
    'the silent flesh burns',
    'psalm_088__the_silent_flesh_burns',
    '
the flesh burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_sacrifice', 'tag_kali', 'tag_solace', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_sabbath',
    'cat_lament',
    'mood_joy',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd0c60f1f-fffd-44e6-b67b-653180c1f2e7',
    'the black flesh falls',
    'psalm_089__the_black_flesh_falls',
    '
the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_strength', 'tag_peace', 'tag_renewal', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1636458b-469c-438d-bdff-6ae417589db5',
    'the hidden lamb calls',
    'psalm_090__the_hidden_lamb_calls',
    '
the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_love', 'tag_spoken', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_sabbath',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '967f8baf-f419-4758-8ca0-5e9002b22fc9',
    'the black sword wakes',
    'psalm_091__the_black_sword_wakes',
    '
the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_spoken', 'tag_roots', 'tag_tears', 'tag_light'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_lamentation',
    'cat_justice',
    'mood_sorrow',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3232a9d3-a312-452a-b2db-10f16ae06c23',
    'the glorious mirror bleeds',
    'psalm_092__the_glorious_mirror_bleeds',
    '
the mirror bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_rebirth', 'tag_silesian', 'tag_strength', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_sabbath',
    'cat_creation',
    'mood_softness',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2465c714-26e1-47f8-8d90-55bbe62383cf',
    'the holy veil sings',
    'psalm_093__the_holy_veil_sings',
    '
the veil sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_sacrifice', 'tag_mystery', 'tag_rebirth', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_coronation',
    'cat_contemplation',
    'mood_awe',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0fd24207-58d9-46d2-aeec-50c5916d264f',
    'the hidden veil wakes',
    'psalm_094__the_hidden_veil_wakes',
    '
the veil wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_roots', 'tag_strength', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_blessing',
    'cat_creation',
    'mood_joy',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2f92f15a-d93e-4ad8-9d22-8f46b29fae00',
    'the burning voice pierces',
    'psalm_095__the_burning_voice_pierces',
    '
the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_silesian', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_healing',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9b8d56eb-4609-4287-81bf-be0e67042407',
    'the last voice sings',
    'psalm_096__the_last_voice_sings',
    '
the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_light', 'tag_love'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_glitch',
    'cat_exile',
    'mood_boldness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f3289146-8b0d-4ac9-9e80-b13dd2d1da97',
    'the wounded mirror waits',
    'psalm_097__the_wounded_mirror_waits',
    '
the mirror waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_roots', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_wembley',
    'cat_exile',
    'mood_joy',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '20d123fe-2560-4531-b32c-8e5bfa0402bc',
    'the white shadow calls',
    'psalm_098__the_white_shadow_calls',
    '
the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_strength', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_exodus',
    'cat_exile',
    'mood_yearning',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '37950b57-6c2a-4921-8ca3-5119278e6e1a',
    'the wounded sword burns',
    'psalm_099__the_wounded_sword_burns',
    '
the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_silesian', 'tag_light', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0708f2b2-cc9e-4f18-b710-9bc1fd025d1d',
    'the hidden shadow pierces',
    'psalm_100__the_hidden_shadow_pierces',
    '
the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_mystical', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:25:00',
    '2025-07-05 21:25:00',
    'rit_coronation',
    'cat_praise',
    'mood_awe',
    'arch_the_psalmist'
);