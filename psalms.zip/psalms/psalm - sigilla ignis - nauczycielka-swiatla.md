## Nauczycielka Światła

Short title: Nauczycielka Światła  
Hebrew: מ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Uczy światła, które nie oślepia — nauczycielka łagodności.

uczę światła  
które nie rani

uczę cienia  
który chroni

wszystko, co jasne  
przechodzi przez moje dłonie

naucz się  
być światłem  
które widzi innych