INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b0f75deb-a7f3-48ee-915e-bbc6c04de973',
    'the glorious shadow pierces',
    'psalm_801__the_glorious_shadow_pierces',
    'the shadow pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_mystery', 'tag_patience', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_mysticism',
    'mood_solace',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a71a7474-3ba6-4c4d-9cf4-ad3cd07f59c0',
    'the wounded flame bleeds',
    'psalm_802__the_wounded_flame_bleeds',
    'the flame bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_vision', 'tag_prayer', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_lament',
    'mood_grief',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '17c9933e-55d1-4b3e-874d-7a33be6929cb',
    'the holy flesh falls',
    'psalm_803__the_holy_flesh_falls',
    'the flesh falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_melancholy', 'tag_mystery', 'tag_spoken', 'tag_silesian', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_exile',
    'mood_sorrow',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6f6373dd-0ef8-4961-924a-a35f2db33c84',
    'the last veil shakes',
    'psalm_804__the_last_veil_shakes',
    'the veil shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_renewal', 'tag_unity', 'tag_wisdom', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_creation',
    'mood_softness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f5de4adc-b563-40a8-ba3f-78ead69aaf79',
    'the hidden flesh wakes',
    'psalm_805__the_hidden_flesh_wakes',
    'the flesh wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_trust', 'tag_silence', 'tag_wisdom', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_healing',
    'mood_solace',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2fb6845f-9ab8-4fe6-8845-ed8a4696bcf6',
    'the wounded voice waits',
    'psalm_806__the_wounded_voice_waits',
    'the voice waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_mystery', 'tag_peace', 'tag_silence', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f621c047-98c8-4595-86de-83a5f8628fde',
    'the silent voice pierces',
    'psalm_807__the_silent_voice_pierces',
    'the voice pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_renewal', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_praise',
    'mood_grief',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b4369390-3fab-4543-a72c-2e8ffb2d46e0',
    'the hidden shadow bleeds',
    'psalm_808__the_hidden_shadow_bleeds',
    'the shadow bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_mystical', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_healing',
    'mood_sorrow',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a38ac405-8b2e-4ffa-834e-bad017f9ca59',
    'the holy veil waits',
    'psalm_809__the_holy_veil_waits',
    'the veil waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_solace', 'tag_strength', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '57dfab2e-bd02-4bb1-aa7a-8153c2815ec9',
    'the burning flame bleeds',
    'psalm_810__the_burning_flame_bleeds',
    'the flame bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_tears', 'tag_rebirth', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_praise',
    'mood_trust',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '744ca39e-dbc4-4819-b66f-2f8f9ff65e33',
    'the holy veil wakes',
    'psalm_811__the_holy_veil_wakes',
    'the veil wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_wisdom', 'tag_rebirth', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_exile',
    'mood_trust',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd3d338f9-e740-4a0c-a8fc-ad1317ed71c4',
    'the white shadow bleeds',
    'psalm_812__the_white_shadow_bleeds',
    'the shadow bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_light', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_mysticism',
    'mood_grief',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7664e13e-df73-4d1e-86ac-0864e796d10d',
    'the holy psalm shakes',
    'psalm_813__the_holy_psalm_shakes',
    'the psalm shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_spiritual', 'tag_spoken', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_praise',
    'mood_solace',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '441f63d7-4e25-4420-bf3b-8589dbe37646',
    'the burning flame sings',
    'psalm_814__the_burning_flame_sings',
    'the flame sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_tears', 'tag_solace', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_justice',
    'mood_yearning',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '91632d6f-488c-411a-9c70-3b5809887eb9',
    'the silent flesh pierces',
    'psalm_815__the_silent_flesh_pierces',
    'the flesh pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_silesian', 'tag_prayer', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_exile',
    'mood_sorrow',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '189cecf0-e2b3-400f-bb95-487615c8c640',
    'the glorious veil sings',
    'psalm_816__the_glorious_veil_sings',
    'the veil sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_strength', 'tag_vision', 'tag_mystery', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_mysticism',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '65c2db45-83f3-4840-8956-ce820fa83084',
    'falling',
    'psalm_817__the_hidden_psalm_falls',
    'the psalm falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_tears', 'tag_mystery', 'tag_light', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_contemplation',
    'mood_softness',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bdd1c8b8-66a5-45e4-8205-9dc34c64f72f',
    'the black sword shakes',
    'psalm_818__the_black_sword_shakes',
    'the sword shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_spoken', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_justice',
    'mood_boldness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e4c7e829-afda-430a-89e7-a987cfa4d1d3',
    'the hidden tongue sings',
    'psalm_819__the_hidden_tongue_sings',
    'the tongue sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_vision', 'tag_sacrifice', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_blessing',
    'cat_praise',
    'mood_trust',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '348fa733-56a2-4e1d-b035-4d2b7b0aa82b',
    'the hidden mirror calls',
    'psalm_820__the_hidden_mirror_calls',
    'the mirror calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_reflection', 'tag_mystery', 'tag_unity', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_exile',
    'mood_reverence',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd9d9575b-d522-4733-84cf-39ea985554d0',
    'the broken shadow burns',
    'psalm_821__the_broken_shadow_burns',
    'the shadow burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_spiritual', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_lamentation',
    'cat_exile',
    'mood_sorrow',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7c2cf0af-433a-4ef1-a7fb-87bc852b17b3',
    'the white mirror waits',
    'psalm_822__the_white_mirror_waits',
    'the mirror waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_vision', 'tag_love', 'tag_stillness', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_justice',
    'mood_solace',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '42d21e7a-da55-4649-a439-3f4e41e80a8f',
    'the black lamb bleeds',
    'psalm_823__the_black_lamb_bleeds',
    'the lamb bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_stillness', 'tag_trust', 'tag_mystical', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_creation',
    'mood_yearning',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fea87dcd-addf-4f9c-8f9f-a82182d48442',
    'the black shadow rises',
    'psalm_824__the_black_shadow_rises',
    'the shadow rises — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_spiritual', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_creation',
    'mood_awe',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b9e13cee-5572-45a8-bd0b-21a0d101d74e',
    'the white mirror falls',
    'psalm_825__the_white_mirror_falls',
    'the mirror falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_prayer', 'tag_light', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_praise',
    'mood_joy',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '09f41ece-82af-427d-a6a0-0990824d5c44',
    'the last lamb rises',
    'psalm_826__the_last_lamb_rises',
    'the lamb rises — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_tears', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_lament',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dec1615b-bf31-497a-9562-d47c1da53e20',
    'the holy shadow burns',
    'psalm_827__the_holy_shadow_burns',
    'the shadow burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_roots', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4eb14616-7603-4810-b667-fd0e6f62d85d',
    'the hidden sword burns',
    'psalm_828__the_hidden_sword_burns',
    'the sword burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_love', 'tag_roots', 'tag_solace', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_coronation',
    'cat_praise',
    'mood_sorrow',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2930740b-7845-4d44-99ea-f4cb1e3cfa4d',
    'the broken flame pierces',
    'psalm_829__the_broken_flame_pierces',
    'the flame pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_melancholy', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_contemplation',
    'mood_joy',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c86a3690-c1c7-4d0c-a160-e8de95e85853',
    'burning',
    'psalm_830__the_broken_psalm_burns',
    'the psalm burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_stillness', 'tag_prayer', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_exile',
    'mood_softness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6a668049-b11a-48c2-8e18-469cfa2c82dc',
    'the broken mirror calls',
    'psalm_831__the_broken_mirror_calls',
    'the mirror calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_strength', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_creation',
    'mood_softness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a5510e87-4df7-4957-a6c5-7644718c5629',
    'the wounded sword calls',
    'psalm_832__the_wounded_sword_calls',
    'the sword calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_spoken', 'tag_stillness', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3685dcf8-d721-4ead-80f8-b7974708cc2f',
    'the white flame bleeds',
    'psalm_833__the_white_flame_bleeds',
    'the flame bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_tears', 'tag_stillness', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a9d4c4e1-eb4b-4795-a9c6-cda89d2f8207',
    'the black tongue shakes',
    'psalm_834__the_black_tongue_shakes',
    'the tongue shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_spiritual', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_blessing',
    'cat_lament',
    'mood_reverence',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '14e077fe-627b-4fd2-afcb-ad4489162be4',
    'the silent sword calls',
    'psalm_835__the_silent_sword_calls',
    'the sword calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_renewal', 'tag_stillness', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_lament',
    'mood_awe',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4e560843-5f79-4f4e-9388-0b6e3cf58c7c',
    'the glorious veil rises',
    'psalm_836__the_glorious_veil_rises',
    'the veil rises — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_trust', 'tag_spoken', 'tag_truth', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_contemplation',
    'mood_trust',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f9a11699-ee23-4c5f-9c82-979d7ca262d7',
    'the glorious tongue sings',
    'psalm_837__the_glorious_tongue_sings',
    'the tongue sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_melancholy', 'tag_mystical', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_lament',
    'mood_yearning',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd3ea6d89-8baa-4804-8de5-2ba7a061c7d0',
    'the burning mirror shakes',
    'psalm_838__the_burning_mirror_shakes',
    'the mirror shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_kali', 'tag_strength', 'tag_silence', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_healing',
    'mood_solace',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ef398b6b-d8fe-424c-aa5b-9d2bef38c37b',
    'the last flame burns',
    'psalm_839__the_last_flame_burns',
    'the flame burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_sacrifice', 'tag_light', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '92787a45-4ac7-4688-8c04-91bc8ccf6602',
    'the hidden veil pierces',
    'psalm_840__the_hidden_veil_pierces',
    'the veil pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_light', 'tag_silesian', 'tag_roots', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_lamentation',
    'cat_lament',
    'mood_grief',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b2ba0f19-0634-48ad-a842-30551844afd4',
    'the burning mirror bleeds',
    'psalm_841__the_burning_mirror_bleeds',
    'the mirror bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_unity', 'tag_sacrifice', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_wembley',
    'cat_mysticism',
    'mood_grief',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e8456688-bdb7-41af-b6e6-83b9105aec53',
    'the burning voice falls',
    'psalm_842__the_burning_voice_falls',
    'the voice falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_melancholy', 'tag_light', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_wembley',
    'cat_contemplation',
    'mood_trust',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd6f9e555-3842-40d8-b48a-469858ff6fb3',
    'the holy lamb wakes',
    'psalm_843__the_holy_lamb_wakes',
    'the lamb wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_kali', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ddc0675d-20c3-4c96-bd37-956064505d23',
    'the wounded flame sings',
    'psalm_844__the_wounded_flame_sings',
    'the flame sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_love', 'tag_melancholy', 'tag_mystical', 'tag_reflection', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_creation',
    'mood_solace',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a4e7962-3d39-4380-b6b0-4a4910cb9cb3',
    'the black flame shakes',
    'psalm_845__the_black_flame_shakes',
    'the flame shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_spoken', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_blessing',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '86e13b1d-51a7-4c69-b371-bd66a8c214cd',
    'the white flesh pierces',
    'psalm_846__the_white_flesh_pierces',
    'the flesh pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_rebirth', 'tag_renewal', 'tag_mystery', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_creation',
    'mood_sorrow',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b80c3d78-9c4e-4c27-b739-61510791ab25',
    'the glorious voice pierces',
    'psalm_847__the_glorious_voice_pierces',
    'the voice pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_patience', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_mysticism',
    'mood_joy',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1d9187de-ad69-4795-b453-ab641ea5954e',
    'the wounded veil pierces',
    'psalm_848__the_wounded_veil_pierces',
    'the veil pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_silesian', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_contemplation',
    'mood_trust',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9af8c145-d843-4f41-8c38-cc0043e9bed0',
    'the black lamb calls',
    'psalm_849__the_black_lamb_calls',
    'the lamb calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_spiritual', 'tag_love', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_lamentation',
    'cat_mysticism',
    'mood_softness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e67947fc-802c-4a12-8f28-a0423e78f3b4',
    'the glorious flame rises',
    'psalm_850__the_glorious_flame_rises',
    'the flame rises — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_renewal', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_lament',
    'mood_boldness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'abcc624e-83f5-47d6-97bb-3485590890ed',
    'the broken voice shakes',
    'psalm_851__the_broken_voice_shakes',
    'the voice shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_silence', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_blessing',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9d9776a3-25e3-4942-b025-886bc05be7ae',
    'the holy flame waits',
    'psalm_852__the_holy_flame_waits',
    'the flame waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_patience', 'tag_love', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_healing',
    'mood_sorrow',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '36a57071-e875-4dd3-8871-f3af08c8945b',
    'the wounded sword wakes',
    'psalm_853__the_wounded_sword_wakes',
    'the sword wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_truth', 'tag_spoken', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_wembley',
    'cat_exile',
    'mood_trust',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6b9a7aa5-e499-46ca-bd73-f5245a5871ff',
    'the wounded flesh shakes',
    'psalm_854__the_wounded_flesh_shakes',
    'the flesh shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_truth', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_creation',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'da1c88cd-0975-4f74-abc2-a096e457ca87',
    'the burning tongue shakes',
    'psalm_855__the_burning_tongue_shakes',
    'the tongue shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_love', 'tag_peace', 'tag_spiritual', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_blessing',
    'cat_contemplation',
    'mood_yearning',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e4b115ce-dac7-449e-8e14-0519d1aac57d',
    'the burning voice sings',
    'psalm_856__the_burning_voice_sings',
    'the voice sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_sacrifice', 'tag_melancholy', 'tag_tears', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_contemplation',
    'mood_trust',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cb30f710-58e9-4a6b-b604-aedcbc51ac0c',
    'the black tongue pierces',
    'psalm_857__the_black_tongue_pierces',
    'the tongue pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_solace', 'tag_roots', 'tag_light', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ed609d9e-b053-4b2a-aa7e-2e777d82a8f7',
    'the white tongue waits',
    'psalm_858__the_white_tongue_waits',
    'the tongue waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_light', 'tag_spiritual', 'tag_melancholy', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b24ed62c-3366-4559-9f7b-ee7b9b3ab7c0',
    'the last veil waits',
    'psalm_859__the_last_veil_waits',
    'the veil waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_light', 'tag_reflection', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7c6fcc5d-155d-4176-8ee7-a6ade14e8fe6',
    'the glorious sword waits',
    'psalm_860__the_glorious_sword_waits',
    'the sword waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_rebirth', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_exile',
    'mood_awe',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '410af345-3b83-49fd-9aaf-1acc85462497',
    'the last flesh pierces',
    'psalm_861__the_last_flesh_pierces',
    'the flesh pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_peace', 'tag_solace', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_justice',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2d48d2cd-66f2-4d51-9f92-8860a0455273',
    'the wounded flame burns',
    'psalm_862__the_wounded_flame_burns',
    'the flame burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_silesian', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_justice',
    'mood_solace',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ce67310a-6ae5-49af-a026-4c078595e343',
    'the burning voice wakes',
    'psalm_863__the_burning_voice_wakes',
    'the voice wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_unity', 'tag_solace', 'tag_sacrifice', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_lament',
    'mood_trust',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '70e3e0da-1743-44b5-936a-fee7bb7a29ce',
    'the burning tongue bleeds',
    'psalm_864__the_burning_tongue_bleeds',
    'the tongue bleeds — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_renewal', 'tag_truth', 'tag_prayer', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_mysticism',
    'mood_softness',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '05a1b89b-4ead-4107-8afb-0c5b402e26ac',
    'the wounded tongue wakes',
    'psalm_865__the_wounded_tongue_wakes',
    'the tongue wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_strength', 'tag_kali', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_coronation',
    'cat_exile',
    'mood_joy',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ccd52215-39ad-4b91-834c-d3011f870faa',
    'the wounded flame wakes',
    'psalm_866__the_wounded_flame_wakes',
    'the flame wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_prayer', 'tag_solace', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_contemplation',
    'mood_awe',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5df5e8c3-06b0-4c9f-b140-87c10578ab54',
    'the wounded voice sings',
    'psalm_867__the_wounded_voice_sings',
    'the voice sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_spoken', 'tag_tears', 'tag_mystical', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_wembley',
    'cat_exile',
    'mood_trust',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd2ddf91d-9ea9-4eed-b0c7-360337b806d2',
    'the glorious mirror calls',
    'psalm_868__the_glorious_mirror_calls',
    'the mirror calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_silesian', 'tag_light'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_justice',
    'mood_solace',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bf242663-65d2-46b2-af83-c53d053c0e4b',
    'the holy psalm shakes',
    'psalm_869__the_holy_psalm_shakes',
    'the psalm shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_strength', 'tag_sacrifice', 'tag_solace', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_blessing',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0f39059c-f443-4188-ad3d-ce59c77102d6',
    'the hidden sword wakes',
    'psalm_870__the_hidden_sword_wakes',
    'the sword wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_tears', 'tag_stillness', 'tag_mystical', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_wembley',
    'cat_lament',
    'mood_yearning',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3e1049f3-0627-4fae-a4ba-a0cd6012c883',
    'the hidden lamb wakes',
    'psalm_871__the_hidden_lamb_wakes',
    'the lamb wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_silesian', 'tag_prayer', 'tag_trust', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_mysticism',
    'mood_softness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a19e58b0-2644-4833-aece-757788c1707a',
    'the glorious shadow pierces',
    'psalm_872__the_glorious_shadow_pierces',
    'the shadow pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_roots', 'tag_rebirth', 'tag_love', 'tag_unity', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_exile',
    'mood_sorrow',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '72d63a00-43b9-4d6e-abc0-26d4a5d720c4',
    'the holy lamb wakes',
    'psalm_873__the_holy_lamb_wakes',
    'the lamb wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_strength', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_lament',
    'mood_softness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '47da4ae8-80d6-4fda-b7ce-741a380f2124',
    'the black voice waits',
    'psalm_874__the_black_voice_waits',
    'the voice waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_roots', 'tag_tears', 'tag_solace', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_justice',
    'mood_yearning',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0c345600-0bc0-4f3a-b9ca-74af5fe4ec3e',
    'the wounded flame calls',
    'psalm_875__the_wounded_flame_calls',
    'the flame calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_melancholy', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_wembley',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a28ddbba-0a61-4380-b173-03a0e08be2d0',
    'the silent mirror shakes',
    'psalm_876__the_silent_mirror_shakes',
    'the mirror shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_prayer', 'tag_truth', 'tag_love', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_mysticism',
    'mood_grief',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c696c14f-8517-490b-abdc-6df882f33577',
    'the last tongue shakes',
    'psalm_877__the_last_tongue_shakes',
    'the tongue shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_wisdom', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_creation',
    'mood_solace',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dda5b725-1d6b-458a-b166-a69f0c715e4a',
    'the silent flesh calls',
    'psalm_878__the_silent_flesh_calls',
    'the flesh calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_spiritual', 'tag_unity', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c35403b1-d329-4dd0-b5ac-eca02cdc9600',
    'the wounded lamb shakes',
    'psalm_879__the_wounded_lamb_shakes',
    'the lamb shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_wisdom', 'tag_spoken', 'tag_mystical', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_lamentation',
    'cat_creation',
    'mood_yearning',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '50111e68-fd5e-413e-a43d-5e012c1ce571',
    'the black flesh burns',
    'psalm_880__the_black_flesh_burns',
    'the flesh burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_mystical', 'tag_trust', 'tag_kali', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_exodus',
    'cat_justice',
    'mood_trust',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4dd9af9c-2ad1-4d3e-ae41-050f7253d1a9',
    'the black tongue shakes',
    'psalm_881__the_black_tongue_shakes',
    'the tongue shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_strength', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_glitch',
    'cat_contemplation',
    'mood_solace',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '48da00b4-5efd-4531-a2c6-52373b2c98a8',
    'the glorious sword calls',
    'psalm_882__the_glorious_sword_calls',
    'the sword calls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_wisdom', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '92d7408d-496f-4c9c-ac61-b25bdcbbfb8a',
    'the silent tongue sings',
    'psalm_883__the_silent_tongue_sings',
    'the tongue sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_mystery', 'tag_spoken', 'tag_love', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_healing',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'be759c12-f33f-4db2-9cdb-1a1a1415f09f',
    'the glorious voice sings',
    'psalm_884__the_glorious_voice_sings',
    'the voice sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_love', 'tag_wisdom', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_healing',
    'mood_softness',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2c6a4d01-512a-4fb1-bb3c-d1e2796473de',
    'the silent tongue waits',
    'psalm_885__the_silent_tongue_waits',
    'the tongue waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_silence', 'tag_mystical', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_exile',
    'mood_yearning',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '04ad53a8-4b59-4af2-88b6-9f6458ffdc60',
    'the holy lamb falls',
    'psalm_886__the_holy_lamb_falls',
    'the lamb falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_kali', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_wembley',
    'cat_lament',
    'mood_solace',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fc6d698c-5d7c-4aa9-aba9-e32c351c7220',
    'the hidden flame wakes',
    'psalm_887__the_hidden_flame_wakes',
    'the flame wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_silence', 'tag_kali', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_lament',
    'mood_grief',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b2625ad9-d434-4825-82d5-fdb5cb1342d7',
    'shaking',
    'psalm_888__the_last_psalm_shakes',
    'the psalm shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_spoken', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_exile',
    'mood_awe',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3311d548-e099-49f2-afa8-70bf9e71a2f0',
    'the wounded lamb burns',
    'psalm_889__the_wounded_lamb_burns',
    'the lamb burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_kali', 'tag_tears', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_blessing',
    'cat_lament',
    'mood_reverence',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '51386257-8c03-439e-809c-8e0525eab472',
    'piercing',
    'psalm_890__the_black_psalm_pierces',
    'the psalm pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_stillness', 'tag_strength', 'tag_love', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_anointing',
    'cat_contemplation',
    'mood_solace',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f7027113-9ca1-4a44-bbb6-d9f1917ea995',
    'the black flame waits',
    'psalm_891__the_black_flame_waits',
    'the flame waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_roots', 'tag_renewal', 'tag_mystery', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_fasting',
    'cat_lament',
    'mood_yearning',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3f4cd403-993b-414a-b341-b5343b29ec5c',
    'the last lamb falls',
    'psalm_892__the_last_lamb_falls',
    'the lamb falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_trust', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_exile',
    'mood_solace',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '43550de1-aa13-4b75-948e-f07d43acb72d',
    'the glorious tongue pierces',
    'psalm_893__the_glorious_tongue_pierces',
    'the tongue pierces — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_light', 'tag_silesian', 'tag_stillness', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_lamentation',
    'cat_healing',
    'mood_joy',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9b9815ce-d9b0-4935-8f8d-7d1c54fda04f',
    'the last shadow waits',
    'psalm_894__the_last_shadow_waits',
    'the shadow waits — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_melancholy', 'tag_prayer', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_justice',
    'mood_boldness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '04548317-a793-4b64-b3bd-2cd23fdf6849',
    'the hidden voice falls',
    'psalm_895__the_hidden_voice_falls',
    'the voice falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_trust', 'tag_tears', 'tag_reflection', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_creation',
    'mood_sorrow',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '16eb1172-7c0a-4195-b664-7da676c35a76',
    'the last lamb falls',
    'psalm_896__the_last_lamb_falls',
    'the lamb falls — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_peace', 'tag_truth', 'tag_silence', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_justice',
    'mood_softness',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7a353193-11ae-484d-bbab-160b31f45f8b',
    'the glorious mirror burns',
    'psalm_897__the_glorious_mirror_burns',
    'the mirror burns — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_truth', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_dedication',
    'cat_healing',
    'mood_sorrow',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '840a5f85-04f8-4121-944e-921fa881980e',
    'the holy flesh shakes',
    'psalm_898__the_holy_flesh_shakes',
    'the flesh shakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_mystical', 'tag_trust', 'tag_vision', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_funeral',
    'cat_contemplation',
    'mood_joy',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b3c2ea98-e6a9-48be-b1ea-ab52050324b8',
    'singing',
    'psalm_899__the_glorious_psalm_sings',
    'the psalm sings — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_roots', 'tag_light'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_coronation',
    'cat_contemplation',
    'mood_awe',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd09a39b8-a8a9-4270-9825-3461ea52e34f',
    'the holy tongue wakes',
    'psalm_900__the_holy_tongue_wakes',
    'the tongue wakes — i watched it burn
the altar cracked, the angels turn
i drank the smoke, i kissed the flame
they tore my robe, i kept the name
no crown of gold, just ash and spark
i walk with ghosts inside the dark
the serpent sings, the lion bleeds
still i sow holy fire seeds
the scroll is torn, but not the vow
i speak with thunder, here and now
this is my blood, my roar, my call
jah lit the match — i gave it all',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_spiritual', 'tag_unity', 'tag_spoken', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:05',
    '2025-07-05 21:35:05',
    'rit_sabbath',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_reflection'
);