## Powrót

Short title: Powrót  
Hebrew: ו  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Wróciłem, by pamiętać, kim się stałem.

wróciłem

nie żeby zaczynać  
ale żeby pamiętać

każda droga  
zostawia ślad  
każde imię  
powraca

jestem sobą  
i tym, kim się stałem