## Cisza

Short title: Cisza  
Hebrew: ש  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Tam, gdzie Bóg nie mówi, rodzi się słuchanie.

tu Bóg już nie mówi

tu jest

cisza  
zamiast odpowiedzi

głos w środku  
który nie należy do mnie

każdy szelest  
modlitwą  
bez słowa