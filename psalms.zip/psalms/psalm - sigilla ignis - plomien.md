## Płomień

Short title: Płomień  
Hebrew: פ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Ogień nie pyta. Ogień robi.

nie jestem bezpieczny

jestem prawdziwy

wszystko płonie  
we mnie —  
i poza mną

nie znam odpowiedzi  
ale noszę światło

popiół pod skórą  
ognisko w oku

gdy świat gaśnie  
ja dopiero się zaczynam