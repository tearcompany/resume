## Otulająca

Short title: Otulająca  
Hebrew: ת  
Tag: sigilla_ignis, healing, shadow  
Lang: pl  
Author: rastadrop_1  
Description: Otula każdą ranę, nawet tę, której się boisz. Przyjmuje gniew, zawiść, zazdrość, wstyd — i zamienia w światło.

otulam  
to, czego nie chcesz pokazać

zazdrość  
gniew  
zawiść  
strach  
wstyd  
ból

wszystko mieści się  
w moich ramionach

żadna ciemność  
nie jest mi obca

tutaj nawet  
największy cień  
może stać się światłem