## Skrzydło

Short title: Skrzydło  
Hebrew: פ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Każde skrzydło rodzi się z tęsknoty.

skrzydło rośnie  
tam gdzie tęsknisz

latasz  
nawet gdy nie wiesz

każda modlitwa  
to ruch skrzydła  
w stronę światła