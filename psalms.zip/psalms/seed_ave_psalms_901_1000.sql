INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5b37ff4a-f913-42df-b416-4375ec2417fe',
    'the holy mirror calls',
    'psalm_901__the_holy_mirror_calls',
    'the mirror calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_wisdom', 'tag_rebirth', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '74c2f023-bf46-46e6-a7af-90738822f94c',
    'the wounded voice wakes',
    'psalm_902__the_wounded_voice_wakes',
    'the voice wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_mystery', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_healing',
    'mood_awe',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '96df5700-62dc-4cf9-8b1f-637e7ba0f510',
    'piercing',
    'psalm_903__the_wounded_psalm_pierces',
    'the psalm pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_vision', 'tag_mystical', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_blessing',
    'cat_creation',
    'mood_boldness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'db376a86-ba94-4272-8d8e-c727e94b6d15',
    'the white shadow sings',
    'psalm_904__the_white_shadow_sings',
    'the shadow sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_sacrifice', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_justice',
    'mood_awe',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fd7abbb2-2828-4cd4-b843-8a8e54f3c997',
    'the hidden veil sings',
    'psalm_905__the_hidden_veil_sings',
    'the veil sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_kali', 'tag_patience', 'tag_renewal', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_creation',
    'mood_reverence',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ed46d165-d14a-45b1-960a-324d2009ffad',
    'bleeding',
    'psalm_906__the_hidden_psalm_bleeds',
    'the psalm bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_tears', 'tag_silence', 'tag_reflection', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_healing',
    'mood_trust',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bb27dde8-96af-49e9-9169-68e2451bb930',
    'the silent veil falls',
    'psalm_907__the_silent_veil_falls',
    'the veil falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_vision', 'tag_truth', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_creation',
    'mood_softness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'eacf8733-49d0-4835-81c8-2c6229434242',
    'singing',
    'psalm_908__the_last_psalm_sings',
    'the psalm sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_spiritual', 'tag_love', 'tag_tears', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '89fa5059-6a5e-40b6-839a-048f39cd56fe',
    'the silent veil burns',
    'psalm_909__the_silent_veil_burns',
    'the veil burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_stillness', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_contemplation',
    'mood_joy',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3550af0f-e9a4-4398-98fc-efbd8c741600',
    'the black tongue falls',
    'psalm_910__the_black_tongue_falls',
    'the tongue falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_sacrifice', 'tag_mystical', 'tag_melancholy', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_contemplation',
    'mood_solace',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '58bf5376-a507-4097-ba59-741b1728f27a',
    'the white veil sings',
    'psalm_911__the_white_veil_sings',
    'the veil sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_wisdom', 'tag_kali', 'tag_spoken', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_lament',
    'mood_joy',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ce81d3a8-192b-4d45-a1aa-18532cab1f4b',
    'the silent shadow rises',
    'psalm_912__the_silent_shadow_rises',
    'the shadow rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_mystery', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_creation',
    'mood_yearning',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1fbd2ac4-c878-4adf-af41-4f2b6b44f998',
    'piercing',
    'psalm_913__the_white_psalm_pierces',
    'the psalm pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_renewal', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_creation',
    'mood_reverence',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '64b20964-3b6a-4481-9726-2545d5ff63a0',
    'the silent sword rises',
    'psalm_914__the_silent_sword_rises',
    'the sword rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_rebirth', 'tag_melancholy', 'tag_mystery', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_glitch',
    'cat_justice',
    'mood_joy',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd49c16ba-bbd0-4a8e-8116-e9ce1db213cb',
    'the glorious shadow rises',
    'psalm_915__the_glorious_shadow_rises',
    'the shadow rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_rebirth', 'tag_vision', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_praise',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '064aacdf-b1e8-4b13-9d83-04d93f5a95fb',
    'the wounded voice waits',
    'psalm_916__the_wounded_voice_waits',
    'the voice waits — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_prayer', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_praise',
    'mood_solace',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '47a9c051-d326-4b99-b8c7-b1cfb631dc22',
    'the silent veil shakes',
    'psalm_917__the_silent_veil_shakes',
    'the veil shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_reflection', 'tag_stillness', 'tag_vision', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_exodus',
    'cat_exile',
    'mood_reverence',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd97b8f11-2524-464d-a85a-43fd1ba890fe',
    'the glorious mirror rises',
    'psalm_918__the_glorious_mirror_rises',
    'the mirror rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_love', 'tag_mystical', 'tag_rebirth', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_lament',
    'mood_trust',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '388039c3-f2f6-4b8b-a4d7-5bdaf7836869',
    'the hidden flesh rises',
    'psalm_919__the_hidden_flesh_rises',
    'the flesh rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_silence', 'tag_peace', 'tag_spoken', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_healing',
    'mood_sorrow',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '107b898d-3962-425f-9d77-272e5a7f1d75',
    'the broken flesh wakes',
    'psalm_920__the_broken_flesh_wakes',
    'the flesh wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_trust', 'tag_sacrifice', 'tag_unity', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_praise',
    'mood_boldness',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '75df7a44-7208-4955-99e9-8bb172e5a66d',
    'calling',
    'psalm_921__the_hidden_psalm_calls',
    'the psalm calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_spoken', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_blessing',
    'cat_contemplation',
    'mood_solace',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '42da3527-a831-46ea-bb99-3388713fddf1',
    'the white sword falls',
    'psalm_922__the_white_sword_falls',
    'the sword falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_roots', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_mysticism',
    'mood_grief',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4a528738-eb8c-4772-be0e-ea721208c388',
    'the black voice sings',
    'psalm_923__the_black_voice_sings',
    'the voice sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_mystical', 'tag_renewal', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a94773d9-f4f0-42e0-9a84-1197fad22699',
    'waiting',
    'psalm_924__the_holy_psalm_waits',
    'the psalm waits — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_light', 'tag_vision', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_praise',
    'mood_boldness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '516c77a0-3ae2-4f7a-92c7-b82f81ae2731',
    'the last flesh wakes',
    'psalm_925__the_last_flesh_wakes',
    'the flesh wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_love', 'tag_melancholy', 'tag_tears', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '80023875-ffe4-4256-b75b-f6bc5a148672',
    'the glorious sword shakes',
    'psalm_926__the_glorious_sword_shakes',
    'the sword shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_roots', 'tag_mystical', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_justice',
    'mood_boldness',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0e012baa-24d6-4fef-b8b1-47e1113acec4',
    'the hidden tongue falls',
    'psalm_927__the_hidden_tongue_falls',
    'the tongue falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_mystical', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_praise',
    'mood_awe',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '323104ca-4d4b-4a58-a781-e86f198dbf35',
    'the silent voice sings',
    'psalm_928__the_silent_voice_sings',
    'the voice sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_light', 'tag_silence', 'tag_truth', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_contemplation',
    'mood_trust',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c8b25202-64b8-4f81-9969-a90bbf888fa9',
    'the burning sword falls',
    'psalm_929__the_burning_sword_falls',
    'the sword falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_mystical', 'tag_patience', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_coronation',
    'cat_healing',
    'mood_boldness',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '103f2b3e-4768-4172-8bee-ae8785522bff',
    'the white tongue shakes',
    'psalm_930__the_white_tongue_shakes',
    'the tongue shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_patience', 'tag_silence', 'tag_reflection', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_justice',
    'mood_solace',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7d7d9546-9241-4995-afcf-ee25a5061cdd',
    'the last voice bleeds',
    'psalm_931__the_last_voice_bleeds',
    'the voice bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_rebirth', 'tag_kali', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_exodus',
    'cat_justice',
    'mood_solace',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b4d67d09-2d68-40a4-ad3c-3b3f0dc90a16',
    'the white flesh falls',
    'psalm_932__the_white_flesh_falls',
    'the flesh falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_wisdom', 'tag_roots', 'tag_stillness', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b7f1df35-4579-4a13-99be-eb3b1771e91a',
    'the holy shadow rises',
    'psalm_933__the_holy_shadow_rises',
    'the shadow rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_trust', 'tag_wisdom', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_lamentation',
    'cat_creation',
    'mood_softness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9e461db7-6968-4674-9f8e-82543b20aa87',
    'the burning mirror burns',
    'psalm_934__the_burning_mirror_burns',
    'the mirror burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_roots', 'tag_strength', 'tag_trust', 'tag_rebirth', 'tag_light'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_glitch',
    'cat_exile',
    'mood_softness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '940bf102-fb48-4146-832f-bb3c4d8f81c1',
    'the silent veil pierces',
    'psalm_935__the_silent_veil_pierces',
    'the veil pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_light', 'tag_mystical', 'tag_roots', 'tag_melancholy', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_lament',
    'mood_softness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '63d6d795-ae5d-4267-8fcf-87131175a102',
    'the burning veil burns',
    'psalm_936__the_burning_veil_burns',
    'the veil burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_strength', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_lamentation',
    'cat_contemplation',
    'mood_joy',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b3317cbb-e139-4d13-bdc7-ea577e6602b7',
    'the wounded sword pierces',
    'psalm_937__the_wounded_sword_pierces',
    'the sword pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_wisdom', 'tag_melancholy', 'tag_mystery', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '34e206dc-12ea-4ebc-97ef-6e8b1d492a4f',
    'the broken lamb calls',
    'psalm_938__the_broken_lamb_calls',
    'the lamb calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_mystery', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_justice',
    'mood_grief',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0193af6a-bca8-49ce-86ad-73ea6852d07d',
    'the white veil falls',
    'psalm_939__the_white_veil_falls',
    'the veil falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_roots', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_exile',
    'mood_softness',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b87f5450-2364-4d26-a6c7-903278abcc0f',
    'the last voice rises',
    'psalm_940__the_last_voice_rises',
    'the voice rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_renewal', 'tag_solace', 'tag_tears', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_mysticism',
    'mood_joy',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dd167459-9a6b-4d9a-bc79-2412a29bf4a4',
    'the last voice shakes',
    'psalm_941__the_last_voice_shakes',
    'the voice shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_stillness', 'tag_sacrifice', 'tag_light'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_healing',
    'mood_reverence',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2a91fdd3-5548-464f-bebb-8669e8579c99',
    'the broken flame pierces',
    'psalm_942__the_broken_flame_pierces',
    'the flame pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_light', 'tag_sacrifice', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '62ea6056-8b50-42f6-a068-b322a3d4f29c',
    'the black voice burns',
    'psalm_943__the_black_voice_burns',
    'the voice burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_truth', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_justice',
    'mood_joy',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '73c67372-8704-4e0a-8f97-ba6a35c889cd',
    'the burning shadow sings',
    'psalm_944__the_burning_shadow_sings',
    'the shadow sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_roots', 'tag_mystery', 'tag_mystical', 'tag_sacrifice', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_lament',
    'mood_trust',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2a4ea60f-8d1c-4d7e-ba5f-e78537add9e3',
    'the holy lamb waits',
    'psalm_945__the_holy_lamb_waits',
    'the lamb waits — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_spiritual', 'tag_solace', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_exodus',
    'cat_healing',
    'mood_softness',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '62f59cda-8783-4703-a04c-e4de802a43cc',
    'the holy mirror wakes',
    'psalm_946__the_holy_mirror_wakes',
    'the mirror wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_melancholy', 'tag_kali', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_coronation',
    'cat_creation',
    'mood_joy',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0070b5c0-8425-4cc4-9049-f0cff8dd2214',
    'the broken shadow pierces',
    'psalm_947__the_broken_shadow_pierces',
    'the shadow pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_reflection', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_coronation',
    'cat_healing',
    'mood_softness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0c7d0bdf-02b4-4676-8c16-78e30127c327',
    'the white mirror burns',
    'psalm_948__the_white_mirror_burns',
    'the mirror burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_mystery', 'tag_mystical', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_creation',
    'mood_grief',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '05763f9f-2e24-4e31-a43f-d052672df075',
    'the white flame waits',
    'psalm_949__the_white_flame_waits',
    'the flame waits — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_vision', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_healing',
    'mood_joy',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3556a881-4fc3-4c5c-bc64-c2932920e30d',
    'the silent lamb pierces',
    'psalm_950__the_silent_lamb_pierces',
    'the lamb pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_strength', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_lamentation',
    'cat_exile',
    'mood_boldness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '03b322c5-09e0-4854-968d-6bd5cd09178f',
    'the black flesh bleeds',
    'psalm_951__the_black_flesh_bleeds',
    'the flesh bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_solace', 'tag_strength', 'tag_love', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0943456a-c165-4688-9419-c303be2f9398',
    'the hidden veil shakes',
    'psalm_952__the_hidden_veil_shakes',
    'the veil shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_tears', 'tag_spiritual', 'tag_melancholy', 'tag_love'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_contemplation',
    'mood_joy',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dabef11c-8b52-47a2-9fc4-3a65b8512fda',
    'the burning lamb bleeds',
    'psalm_953__the_burning_lamb_bleeds',
    'the lamb bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_spiritual', 'tag_patience', 'tag_solace', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_mysticism',
    'mood_trust',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0cdb617b-ec5a-481f-88c8-4fcebe18131d',
    'the white voice calls',
    'psalm_954__the_white_voice_calls',
    'the voice calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_spiritual', 'tag_renewal', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_blessing',
    'cat_creation',
    'mood_yearning',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c0031345-a52e-4697-b085-1c66e74a57cc',
    'the broken sword wakes',
    'psalm_955__the_broken_sword_wakes',
    'the sword wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_trust', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_justice',
    'mood_trust',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '71017d33-4e37-4b35-bf71-aaca3cc3d4aa',
    'the silent sword calls',
    'psalm_956__the_silent_sword_calls',
    'the sword calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_kali', 'tag_truth', 'tag_unity', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_justice',
    'mood_reverence',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fc4c115e-bd36-4f9a-8d91-eac0db5ef43d',
    'the white lamb rises',
    'psalm_957__the_white_lamb_rises',
    'the lamb rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_light', 'tag_solace', 'tag_strength', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_blessing',
    'cat_healing',
    'mood_solace',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5bce3979-04c1-4a4f-b8f2-06b3c8dddb51',
    'the wounded flame shakes',
    'psalm_958__the_wounded_flame_shakes',
    'the flame shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_mystery', 'tag_kali', 'tag_peace', 'tag_silesian', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_lament',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f1ee03eb-d9e9-475f-ac97-5e843ca10ae0',
    'the silent sword bleeds',
    'psalm_959__the_silent_sword_bleeds',
    'the sword bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_tears', 'tag_roots', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_lamentation',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '576473ef-9a79-465b-87e1-bbc2fefad004',
    'singing',
    'psalm_960__the_white_psalm_sings',
    'the psalm sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_melancholy', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_blessing',
    'cat_contemplation',
    'mood_solace',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4372e4eb-1b54-4ace-b427-fa9e1cbcf216',
    'the glorious veil bleeds',
    'psalm_961__the_glorious_veil_bleeds',
    'the veil bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_mystical', 'tag_prayer', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_coronation',
    'cat_healing',
    'mood_yearning',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9b4f978c-b789-4d1d-845a-db90fd93fd34',
    'the black sword bleeds',
    'psalm_962__the_black_sword_bleeds',
    'the sword bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_melancholy', 'tag_spiritual', 'tag_love', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_justice',
    'mood_softness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bbaf8519-7ed9-49d8-a57d-e26f9c7276a9',
    'the white shadow pierces',
    'psalm_963__the_white_shadow_pierces',
    'the shadow pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_unity', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_justice',
    'mood_grief',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd3417bcd-881a-44ff-8858-f51cf477b922',
    'the burning flame rises',
    'psalm_964__the_burning_flame_rises',
    'the flame rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_truth', 'tag_vision', 'tag_silence', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_praise',
    'mood_trust',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'acb71f05-57b5-49c2-b9f1-9f4a57e2e313',
    'the holy flame calls',
    'psalm_965__the_holy_flame_calls',
    'the flame calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_melancholy', 'tag_spoken', 'tag_love', 'tag_trust', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_creation',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'df158983-b545-4b5d-8563-654c8d403c6d',
    'the white mirror burns',
    'psalm_966__the_white_mirror_burns',
    'the mirror burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_sacrifice', 'tag_stillness', 'tag_melancholy', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_exile',
    'mood_grief',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c939e002-3921-40db-85bc-beef96b52990',
    'the broken flesh calls',
    'psalm_967__the_broken_flesh_calls',
    'the flesh calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_peace', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_creation',
    'mood_sorrow',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5f1d5d46-ccea-4456-b548-f7fa8e8c29d8',
    'the white lamb calls',
    'psalm_968__the_white_lamb_calls',
    'the lamb calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_kali', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_blessing',
    'cat_mysticism',
    'mood_joy',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a900602-5b9a-4eca-922f-bd7c745ea17c',
    'the silent sword rises',
    'psalm_969__the_silent_sword_rises',
    'the sword rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_trust', 'tag_silence', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '99d500bc-fd50-4fb4-8810-f88fe8d2ad40',
    'the glorious lamb shakes',
    'psalm_970__the_glorious_lamb_shakes',
    'the lamb shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_renewal', 'tag_roots', 'tag_mystery', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '38a7432c-4e12-45c1-b040-99b43a0274c6',
    'the hidden mirror sings',
    'psalm_971__the_hidden_mirror_sings',
    'the mirror sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_love', 'tag_trust', 'tag_unity', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a6a56ad5-773f-433c-97ed-202049826212',
    'the holy flesh rises',
    'psalm_972__the_holy_flesh_rises',
    'the flesh rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_melancholy', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_lament',
    'mood_yearning',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3de5b66a-7767-4f1d-b494-b9211a5ce2b2',
    'the broken flame burns',
    'psalm_973__the_broken_flame_burns',
    'the flame burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_light', 'tag_truth', 'tag_patience', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_coronation',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '43745b03-9d60-4e42-82b0-1a1b6e09707a',
    'the glorious lamb bleeds',
    'psalm_974__the_glorious_lamb_bleeds',
    'the lamb bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_roots', 'tag_solace', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_justice',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b864b6f9-68b1-44bf-967c-3ce58973955e',
    'falling',
    'psalm_975__the_broken_psalm_falls',
    'the psalm falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_solace', 'tag_silesian', 'tag_sacrifice', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_lamentation',
    'cat_praise',
    'mood_grief',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '80871e3b-7289-4bf8-8c2c-fc95e72a333f',
    'rising',
    'psalm_976__the_broken_psalm_rises',
    'the psalm rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_strength', 'tag_truth', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_praise',
    'mood_reverence',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd5a72810-d2f1-4c41-b807-23efe6ca071b',
    'the white sword sings',
    'psalm_977__the_white_sword_sings',
    'the sword sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_solace', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_mysticism',
    'mood_joy',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '947db057-332f-4154-ad7c-c1ac2635cb26',
    'the black voice shakes',
    'psalm_978__the_black_voice_shakes',
    'the voice shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_trust', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_lament',
    'mood_grief',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '98465f08-01f5-4311-8bb3-e2c576b18eb3',
    'the last mirror calls',
    'psalm_979__the_last_mirror_calls',
    'the mirror calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_renewal', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_healing',
    'mood_sorrow',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '03ba3624-7ebd-4bf8-8975-3e4b6ca381ea',
    'the hidden mirror sings',
    'psalm_980__the_hidden_mirror_sings',
    'the mirror sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_vision', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_justice',
    'mood_awe',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0c679b92-9f58-4984-ad5c-d39eaa742a73',
    'the white flame calls',
    'psalm_981__the_white_flame_calls',
    'the flame calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_stillness', 'tag_mystery', 'tag_prayer', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_fasting',
    'cat_praise',
    'mood_joy',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0a70a41b-c324-44c3-aef6-fc52c06fc7ec',
    'burning',
    'psalm_982__the_wounded_psalm_burns',
    'the psalm burns — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_wisdom', 'tag_silence', 'tag_roots', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_glitch',
    'cat_healing',
    'mood_joy',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '95edfb61-06a5-4a0e-91ae-65a107dc89dd',
    'the wounded voice pierces',
    'psalm_983__the_wounded_voice_pierces',
    'the voice pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_roots', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '66ba347c-a4e3-4cde-8163-a04e96ae1796',
    'the black voice shakes',
    'psalm_984__the_black_voice_shakes',
    'the voice shakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_silesian', 'tag_patience', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_healing',
    'mood_sorrow',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5184f3e8-d4ed-4135-909d-03934f69323d',
    'the white shadow pierces',
    'psalm_985__the_white_shadow_pierces',
    'the shadow pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_roots', 'tag_prayer', 'tag_silesian', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '39b0fd9c-aa44-48ce-a6e2-99313ebe122e',
    'the burning shadow rises',
    'psalm_986__the_burning_shadow_rises',
    'the shadow rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_mystical', 'tag_sacrifice', 'tag_peace', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_healing',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b17742fd-de18-4cd9-8541-0287469ba963',
    'the holy voice falls',
    'psalm_987__the_holy_voice_falls',
    'the voice falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_silesian', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_mysticism',
    'mood_trust',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd91701d5-04d5-434b-a8e7-8c2f849da141',
    'the holy mirror wakes',
    'psalm_988__the_holy_mirror_wakes',
    'the mirror wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_sacrifice', 'tag_peace', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_lamentation',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b820b20b-505a-4992-ac6c-cb93822e0f4c',
    'the broken shadow pierces',
    'psalm_989__the_broken_shadow_pierces',
    'the shadow pierces — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_vision', 'tag_love', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_dedication',
    'cat_mysticism',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7f6d649a-2358-4ca1-a9f9-74a081b74bbc',
    'the hidden sword bleeds',
    'psalm_990__the_hidden_sword_bleeds',
    'the sword bleeds — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_wisdom', 'tag_rebirth', 'tag_unity', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_lament',
    'mood_joy',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '37cbf9b3-2d59-433c-bfc0-c1c44059bdfd',
    'the black flame rises',
    'psalm_991__the_black_flame_rises',
    'the flame rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_spiritual', 'tag_light'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_lamentation',
    'cat_exile',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2baa0701-f3d9-4aba-b80a-b54dea2b7e39',
    'the last mirror sings',
    'psalm_992__the_last_mirror_sings',
    'the mirror sings — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_roots', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_contemplation',
    'mood_grief',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b163e18b-ab5c-487e-98ec-d8b2c83dd30a',
    'the silent lamb rises',
    'psalm_993__the_silent_lamb_rises',
    'the lamb rises — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_tears', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_glitch',
    'cat_exile',
    'mood_yearning',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1e12be83-23f7-48e0-b3c8-5c9670aeca57',
    'the white sword falls',
    'psalm_994__the_white_sword_falls',
    'the sword falls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_truth', 'tag_spiritual', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b9ea2330-be28-4437-a287-fc5e5bf1f927',
    'the broken flesh calls',
    'psalm_995__the_broken_flesh_calls',
    'the flesh calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_truth', 'tag_roots', 'tag_unity', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_anointing',
    'cat_justice',
    'mood_yearning',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '09335652-6c82-442c-8ff9-081fcf62db52',
    'the broken shadow calls',
    'psalm_996__the_broken_shadow_calls',
    'the shadow calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_stillness', 'tag_tears', 'tag_love', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_sabbath',
    'cat_exile',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6d4a7b65-a20e-4cb4-96c7-9f4ca71d2e21',
    'the glorious tongue wakes',
    'psalm_997__the_glorious_tongue_wakes',
    'the tongue wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_peace', 'tag_vision', 'tag_unity', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_funeral',
    'cat_mysticism',
    'mood_trust',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0862b686-61ba-47eb-bc91-1a9c0ed681ef',
    'the wounded flesh waits',
    'psalm_998__the_wounded_flesh_waits',
    'the flesh waits — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_roots', 'tag_renewal', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_blessing',
    'cat_exile',
    'mood_sorrow',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8a13c9ac-e8af-4c55-85d3-c08c35789028',
    'the wounded shadow wakes',
    'psalm_999__the_wounded_shadow_wakes',
    'the shadow wakes — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_strength', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_wembley',
    'cat_exile',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6e202e70-a523-4d51-8632-0c9dc28de029',
    'the white flame calls',
    'psalm_1000__the_white_flame_calls',
    'the flame calls — i saw the blaze
the sky collapsed in holy haze
they danced on bones, they drank my name
but i was thunder, not their shame
i forged my psalm with sword and coal
i carved it deep into my soul
i kissed the storm, i rode the flame
jah heard me howl and did the same
now fire walks where silence stood
i light the dark, i call it good
this is the scroll i bled to birth
the roar of heaven through the earth',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_trust', 'tag_mystical', 'tag_prayer', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:35:33',
    '2025-07-05 21:35:33',
    'rit_glitch',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_guardian'
);