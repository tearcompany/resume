INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0553ba61-06e4-48df-be64-f4027718715e',
    'the wounded lamb bleeds',
    'psalm_501__the_wounded_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_strength', 'tag_mystical', 'tag_patience', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_lament',
    'mood_sorrow',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a4340822-cd0e-420e-b5e3-a691c62db388',
    'the white mirror pierces',
    'psalm_502__the_white_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_renewal', 'tag_prayer', 'tag_reflection', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8a75579b-61ac-4d5e-8359-33e2724601fb',
    'the broken tongue shakes',
    'psalm_503__the_broken_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_stillness', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_wembley',
    'cat_contemplation',
    'mood_grief',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c6a53c6b-f564-4065-814a-5fc4ecfdfaa3',
    'burning',
    'psalm_504__the_wounded_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_peace', 'tag_rebirth', 'tag_vision', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_contemplation',
    'mood_softness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '28c17b21-47bc-4ea8-9bd8-9b8d9664aa7a',
    'the white flesh falls',
    'psalm_505__the_white_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_roots', 'tag_silesian', 'tag_spiritual', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2d5bb359-f827-4aa3-aa93-c27ee015f56c',
    'the silent shadow pierces',
    'psalm_506__the_silent_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_rebirth', 'tag_light', 'tag_sacrifice', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_healing',
    'mood_sorrow',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ceddabf7-1a8d-4e3e-937c-cee376efa20f',
    'the silent flame sings',
    'psalm_507__the_silent_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_strength', 'tag_sacrifice', 'tag_rebirth', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5bc5ab46-8d23-4ff6-b171-36d9bdde722e',
    'the broken mirror falls',
    'psalm_508__the_broken_mirror_falls',
    'the mirror falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_spiritual', 'tag_tears', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_lament',
    'mood_reverence',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1e9cdf4f-efa9-4aa3-8b69-32faa5ad3191',
    'the burning voice shakes',
    'psalm_509__the_burning_voice_shakes',
    'the voice shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_kali', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_justice',
    'mood_awe',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1baa9c2b-b6c6-4c0f-9dfb-736d95333caa',
    'the holy flame pierces',
    'psalm_510__the_holy_flame_pierces',
    'the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_sacrifice', 'tag_spiritual', 'tag_silence', 'tag_light'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '71407073-12ee-4cf2-b5a9-3b78edd16d99',
    'the burning lamb sings',
    'psalm_511__the_burning_lamb_sings',
    'the lamb sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_tears', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_justice',
    'mood_grief',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3ed88782-a75a-456e-8736-973e1d990ce0',
    'the white flame falls',
    'psalm_512__the_white_flame_falls',
    'the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_spoken', 'tag_peace', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_healing',
    'mood_trust',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '62c939cf-6bc1-43d0-91d1-0a0af75cb9ce',
    'the white sword falls',
    'psalm_513__the_white_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_stillness', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_fasting',
    'cat_lament',
    'mood_boldness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3fbf2748-2637-444e-a509-f0fae28f7d55',
    'the wounded flesh burns',
    'psalm_514__the_wounded_flesh_burns',
    'the flesh burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_mystical', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_creation',
    'mood_boldness',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '086877fc-174b-40e0-ab21-eb7bc885f6a5',
    'the holy lamb shakes',
    'psalm_515__the_holy_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_sacrifice', 'tag_rebirth', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_lament',
    'mood_solace',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3304ab32-760a-402f-b50e-e2afd78813aa',
    'the black tongue sings',
    'psalm_516__the_black_tongue_sings',
    'the tongue sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_trust', 'tag_prayer', 'tag_love', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_exodus',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1dc891ec-7242-43b0-b87d-2fdc54758b03',
    'the silent veil sings',
    'psalm_517__the_silent_veil_sings',
    'the veil sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_renewal', 'tag_spoken', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '87463ddd-3926-4bfb-917c-ef1cc042585c',
    'the burning tongue shakes',
    'psalm_518__the_burning_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_spiritual', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_mysticism',
    'mood_joy',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9ee79aed-7458-4d04-b244-d637fb1e0593',
    'the black sword falls',
    'psalm_519__the_black_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_prayer', 'tag_solace', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fb187baa-79b4-488f-be98-f139585087fd',
    'falling',
    'psalm_520__the_glorious_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_silesian', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_wembley',
    'cat_mysticism',
    'mood_grief',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '66002229-edb2-445a-a99d-ba3e4f588ddb',
    'the glorious shadow pierces',
    'psalm_521__the_glorious_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_spiritual', 'tag_light', 'tag_mystery', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_healing',
    'mood_reverence',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3c63520a-1246-40aa-a216-07dfceda071f',
    'the black tongue calls',
    'psalm_522__the_black_tongue_calls',
    'the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_vision', 'tag_silence', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_mysticism',
    'mood_awe',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dc737a55-69bc-4543-a00f-a281bc5e4137',
    'the silent tongue rises',
    'psalm_523__the_silent_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_prayer', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_exile',
    'mood_sorrow',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '16ccee7e-59d5-4989-b1bd-27e953fc5f43',
    'the burning flesh rises',
    'psalm_524__the_burning_flesh_rises',
    'the flesh rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_roots', 'tag_unity', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a0e733b4-92af-4e03-a21c-a2769e645f4f',
    'the black voice sings',
    'psalm_525__the_black_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_mystical', 'tag_wisdom', 'tag_vision', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a93ae652-6f88-4de4-a5f5-2dce4c8a3cad',
    'the holy veil pierces',
    'psalm_526__the_holy_veil_pierces',
    'the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_reflection', 'tag_unity', 'tag_spiritual', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_justice',
    'mood_trust',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '44a9c579-0973-4053-a80a-87dca4cbd5d7',
    'the broken tongue burns',
    'psalm_527__the_broken_tongue_burns',
    'the tongue burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_strength', 'tag_solace', 'tag_silesian', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_anointing',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b3969eb1-9a52-484c-8e47-26bb3546ac09',
    'the burning lamb wakes',
    'psalm_528__the_burning_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_truth', 'tag_unity', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_creation',
    'mood_awe',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c7a1f0d1-b793-4e98-87b8-3597c923ddac',
    'the wounded veil bleeds',
    'psalm_529__the_wounded_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_silence', 'tag_trust', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a9286cb3-c56e-4a55-a685-cfbc753a7522',
    'the hidden sword rises',
    'psalm_530__the_hidden_sword_rises',
    'the sword rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystery', 'tag_melancholy', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_praise',
    'mood_grief',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fe66e802-e966-4cef-a220-0dfe4291db19',
    'the burning veil bleeds',
    'psalm_531__the_burning_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_truth', 'tag_love', 'tag_spiritual', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_anointing',
    'cat_creation',
    'mood_reverence',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '764bdf92-6a57-4ab7-b1dd-145b3c850fa3',
    'the holy flame bleeds',
    'psalm_532__the_holy_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_tears', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_anointing',
    'cat_healing',
    'mood_awe',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '76064c98-8cd3-41da-8886-55fa206bf73c',
    'the glorious flame rises',
    'psalm_533__the_glorious_flame_rises',
    'the flame rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_mystical', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_praise',
    'mood_sorrow',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3f04227a-be62-4ef2-9ac5-9bf04ce0919a',
    'the silent voice burns',
    'psalm_534__the_silent_voice_burns',
    'the voice burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_unity', 'tag_love', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_contemplation',
    'mood_solace',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '385ffd03-1059-40d7-a3c5-e3e07600d9e5',
    'the wounded tongue sings',
    'psalm_535__the_wounded_tongue_sings',
    'the tongue sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_roots', 'tag_mystical', 'tag_mystery', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_fasting',
    'cat_justice',
    'mood_boldness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ba558418-80f6-41ed-a594-89af6e393338',
    'the holy lamb falls',
    'psalm_536__the_holy_lamb_falls',
    'the lamb falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_vision', 'tag_peace', 'tag_sacrifice', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9340c4eb-bbf3-4d91-88d6-05a55b62149c',
    'the broken shadow burns',
    'psalm_537__the_broken_shadow_burns',
    'the shadow burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_reflection', 'tag_silence', 'tag_trust', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_mysticism',
    'mood_awe',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0765556d-df1c-45b3-8f00-0163527596ed',
    'waking',
    'psalm_538__the_black_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_prayer', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_wembley',
    'cat_praise',
    'mood_reverence',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd0eb0ab4-f528-4edd-826b-3df1a0f96e39',
    'the broken tongue shakes',
    'psalm_539__the_broken_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_melancholy', 'tag_wisdom', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_lament',
    'mood_awe',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4d3db8a9-8838-475c-a538-ffd6d5440d44',
    'the hidden sword pierces',
    'psalm_540__the_hidden_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_mystical', 'tag_silesian', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_justice',
    'mood_joy',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0c1d6634-5d36-4c2b-aaf0-ded1771b65bf',
    'the holy veil rises',
    'psalm_541__the_holy_veil_rises',
    'the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_trust', 'tag_spoken', 'tag_patience', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_justice',
    'mood_reverence',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0cca5447-0267-4dbd-88cb-469ed800bb1d',
    'the white shadow sings',
    'psalm_542__the_white_shadow_sings',
    'the shadow sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_melancholy', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_fasting',
    'cat_creation',
    'mood_awe',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '79a0e331-3940-4fda-afab-befd0e20126b',
    'falling',
    'psalm_543__the_white_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_vision', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_anointing',
    'cat_mysticism',
    'mood_joy',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd20c31a8-13bb-4a19-aa67-274b2b826734',
    'the burning mirror pierces',
    'psalm_544__the_burning_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_tears', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_creation',
    'mood_sorrow',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a18fc3ec-994c-446c-99c1-23563af5fc4b',
    'the black flesh shakes',
    'psalm_545__the_black_flesh_shakes',
    'the flesh shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_truth', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_sabbath',
    'cat_exile',
    'mood_softness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '781eb931-fba4-4021-99c0-929b54c10d5c',
    'the hidden shadow rises',
    'psalm_546__the_hidden_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_peace', 'tag_light', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_creation',
    'mood_sorrow',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dc0509ca-e1a0-45bb-97d9-39e9545709b5',
    'the last voice sings',
    'psalm_547__the_last_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_trust', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_sabbath',
    'cat_contemplation',
    'mood_awe',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a3a6134e-e71c-4813-a1f0-2360a1fa35e5',
    'the black tongue waits',
    'psalm_548__the_black_tongue_waits',
    'the tongue waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_strength', 'tag_rebirth', 'tag_love', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_justice',
    'mood_trust',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd54bcfe6-caa0-4ecc-b3e9-237c0bcaefa2',
    'the wounded lamb bleeds',
    'psalm_549__the_wounded_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_stillness', 'tag_trust', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_mysticism',
    'mood_sorrow',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2520bd2f-41af-48ab-a233-61a0000170aa',
    'the last lamb waits',
    'psalm_550__the_last_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_unity', 'tag_mystical', 'tag_silence', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_mysticism',
    'mood_joy',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2aa02f60-d319-40b3-8ea1-8451040189f9',
    'the black lamb wakes',
    'psalm_551__the_black_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_solace', 'tag_melancholy', 'tag_mystery', 'tag_love'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_wembley',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2a50a5eb-60fb-47ac-a144-5857209b61a8',
    'the last voice calls',
    'psalm_552__the_last_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_rebirth', 'tag_peace', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_exile',
    'mood_joy',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c3bd2d8b-091f-44eb-9171-b4fa514861dc',
    'the broken veil shakes',
    'psalm_553__the_broken_veil_shakes',
    'the veil shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_patience', 'tag_melancholy', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'efaee036-a9fb-41c8-ae9a-1400ded66333',
    'the hidden psalm calls',
    'psalm_554__the_hidden_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_love', 'tag_wisdom', 'tag_stillness', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_creation',
    'mood_sorrow',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '065a6cfa-752f-4e67-8559-a302dfc98e22',
    'the black tongue sings',
    'psalm_555__the_black_tongue_sings',
    'the tongue sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_love', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_creation',
    'mood_sorrow',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5083ad73-f0f6-4afa-a693-a571d93c15c5',
    'the black lamb sings',
    'psalm_556__the_black_lamb_sings',
    'the lamb sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_light', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7192ec2e-1e97-4daa-bc97-276d8a528d5e',
    'the wounded flame burns',
    'psalm_557__the_wounded_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_prayer', 'tag_silesian', 'tag_renewal', 'tag_love'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_wembley',
    'cat_justice',
    'mood_grief',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '214b3876-2b40-4b98-91cb-fb28a8a002a0',
    'the white shadow bleeds',
    'psalm_558__the_white_shadow_bleeds',
    'the shadow bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_patience', 'tag_spiritual', 'tag_vision', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_blessing',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'efb3b0a6-74c8-491e-99da-dc42fb251ac8',
    'the holy flame falls',
    'psalm_559__the_holy_flame_falls',
    'the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_solace', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_praise',
    'mood_reverence',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ef6ec39f-1f1c-4529-9bc9-6cd9baf983fd',
    'the burning mirror calls',
    'psalm_560__the_burning_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_patience', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_contemplation',
    'mood_awe',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '401304f1-6318-4a09-a5ad-ec6ed3b25ff6',
    'the silent mirror burns',
    'psalm_561__the_silent_mirror_burns',
    'the mirror burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_spiritual', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_mysticism',
    'mood_trust',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '89727ee6-1570-4361-8f45-265e7d6ebf07',
    'the last voice wakes',
    'psalm_562__the_last_voice_wakes',
    'the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_light', 'tag_reflection', 'tag_wisdom', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ec2dabce-5e5d-42ac-abc0-f251b3f3a56d',
    'the wounded lamb rises',
    'psalm_563__the_wounded_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_silesian', 'tag_prayer', 'tag_rebirth', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_fasting',
    'cat_lament',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cf2073af-7455-4429-a3e4-bfca077f1255',
    'the white tongue wakes',
    'psalm_564__the_white_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_silesian', 'tag_love', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c75f4216-09f4-4798-8901-2841a082b811',
    'the wounded tongue falls',
    'psalm_565__the_wounded_tongue_falls',
    'the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_sacrifice', 'tag_love', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_mysticism',
    'mood_softness',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0345e179-63ab-45c7-b6b3-3d058e3536ca',
    'the burning veil burns',
    'psalm_566__the_burning_veil_burns',
    'the veil burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_spiritual', 'tag_peace', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_wembley',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1c551e69-8a95-4645-9267-c0449c3282bc',
    'the burning lamb waits',
    'psalm_567__the_burning_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_tears', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '726602d2-f52d-43a3-9cc2-2973b1afbc12',
    'the broken mirror pierces',
    'psalm_568__the_broken_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_roots', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_anointing',
    'cat_contemplation',
    'mood_trust',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '29b1362d-2bfe-4ac4-a2b5-ba747196c0ca',
    'the hidden sword rises',
    'psalm_569__the_hidden_sword_rises',
    'the sword rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_vision', 'tag_mystical', 'tag_kali', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_healing',
    'mood_trust',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd82ba8c0-8cba-4664-bce9-babca322f323',
    'burning',
    'psalm_570__the_last_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_reflection', 'tag_silence', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_anointing',
    'cat_exile',
    'mood_solace',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '03f60713-c1aa-464f-82f0-909ac5a530b3',
    'the hidden flame sings',
    'psalm_571__the_hidden_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_kali', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_lament',
    'mood_softness',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '20cc76ad-53af-45a6-8ac0-269878475fc7',
    'falling',
    'psalm_572__the_last_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_wisdom', 'tag_sacrifice', 'tag_reflection', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_justice',
    'mood_grief',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a7a9d7cf-95bc-4006-a5d2-3857f2020002',
    'the wounded shadow falls',
    'psalm_573__the_wounded_shadow_falls',
    'the shadow falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_mystery', 'tag_roots', 'tag_kali', 'tag_light'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_blessing',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2dc14aa8-a4ca-4a59-aa21-9f7c5f468170',
    'the white shadow sings',
    'psalm_574__the_white_shadow_sings',
    'the shadow sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_patience', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_fasting',
    'cat_justice',
    'mood_sorrow',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1e2d5ec7-56a0-40b6-be08-056495c80b7b',
    'the wounded shadow pierces',
    'psalm_575__the_wounded_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_prayer', 'tag_melancholy', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ed34bdc2-bad7-494c-9975-ae35908778a1',
    'the broken mirror shakes',
    'psalm_576__the_broken_mirror_shakes',
    'the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_light', 'tag_roots', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0a07255b-bca6-47e4-907d-c1bb77674062',
    'the burning tongue shakes',
    'psalm_577__the_burning_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_spiritual', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_healing',
    'mood_reverence',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b6e26d54-cce8-448e-83ea-236161abd84f',
    'the burning mirror rises',
    'psalm_578__the_burning_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_melancholy', 'tag_spoken', 'tag_wisdom', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_fasting',
    'cat_creation',
    'mood_boldness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5350b5d1-33bf-4b99-822b-41ef2f3dd2ae',
    'the broken veil waits',
    'psalm_579__the_broken_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_reflection', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3d498bd8-ae5d-404a-9b95-f986fcd9a1de',
    'calling',
    'psalm_580__the_burning_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_prayer', 'tag_patience', 'tag_mystical', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_creation',
    'mood_awe',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '80b1b7ad-b3f5-4b3e-9be1-f33bbc06fff4',
    'the last sword pierces',
    'psalm_581__the_last_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_vision', 'tag_rebirth', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_dedication',
    'cat_mysticism',
    'mood_awe',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'facf095e-e855-4085-bf54-434c8f10e9ed',
    'the broken flame calls',
    'psalm_582__the_broken_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_melancholy', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_mysticism',
    'mood_joy',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '09f50da7-d827-4be1-aeda-675a184f86a4',
    'the last flesh bleeds',
    'psalm_583__the_last_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_unity', 'tag_melancholy', 'tag_reflection', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_lament',
    'mood_yearning',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2bd858d2-a7ed-4c05-8632-e537585f3c18',
    'waiting',
    'psalm_584__the_burning_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_melancholy', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_exodus',
    'cat_healing',
    'mood_softness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fa75028a-e9d4-4124-9773-b8b085f8e77f',
    'the black shadow pierces',
    'psalm_585__the_black_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_rebirth', 'tag_silesian', 'tag_silence', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_healing',
    'mood_joy',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '459bcbcf-1f7d-4941-a5c4-8d294a07cee2',
    'the last sword sings',
    'psalm_586__the_last_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_tears', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_exile',
    'mood_yearning',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '89a749b0-a35d-4a90-a5a9-794ee85e8453',
    'the holy tongue shakes',
    'psalm_587__the_holy_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_unity', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '61124a2f-4348-44b7-ba85-d0ba26986e12',
    'the hidden flame calls',
    'psalm_588__the_hidden_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_spiritual', 'tag_melancholy', 'tag_roots', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_justice',
    'mood_joy',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f0d2a7af-9ac0-4e29-b1cd-eca52f1d0c4c',
    'the black voice pierces',
    'psalm_589__the_black_voice_pierces',
    'the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_unity', 'tag_peace', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '70463b8c-2b71-480b-937c-e61fd0e459f6',
    'the hidden mirror falls',
    'psalm_590__the_hidden_mirror_falls',
    'the mirror falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_reflection', 'tag_renewal', 'tag_tears', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_justice',
    'mood_sorrow',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '68e3950d-b5bd-4f12-87d4-399f9e048653',
    'the hidden voice shakes',
    'psalm_591__the_hidden_voice_shakes',
    'the voice shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_reflection', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_creation',
    'mood_reverence',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '102a421b-595d-459d-8040-68178c1f1590',
    'the silent shadow rises',
    'psalm_592__the_silent_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_reflection', 'tag_rebirth', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_anointing',
    'cat_healing',
    'mood_yearning',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6e5cf079-1959-4a65-9d61-bc4a95e772c0',
    'the glorious flesh rises',
    'psalm_593__the_glorious_flesh_rises',
    'the flesh rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_sacrifice', 'tag_vision', 'tag_silesian', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_fasting',
    'cat_exile',
    'mood_softness',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5f75e43e-27be-4177-ab95-a75736bf06d6',
    'the white veil falls',
    'psalm_594__the_white_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_solace', 'tag_prayer', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_blessing',
    'cat_healing',
    'mood_awe',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '358f06b4-87fb-4989-82ae-98cb0f083c3b',
    'the burning mirror rises',
    'psalm_595__the_burning_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_vision', 'tag_rebirth', 'tag_tears', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_coronation',
    'cat_healing',
    'mood_reverence',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6bd2cd46-a5f5-46ad-8f44-0b10a5fb11a5',
    'bleeding',
    'psalm_596__the_burning_psalm_bleeds',
    'the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_prayer', 'tag_truth', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_lamentation',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cd55a196-d8aa-4d31-9ec5-5bfbbd2a07c8',
    'the burning flesh wakes',
    'psalm_597__the_burning_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_patience', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_sabbath',
    'cat_creation',
    'mood_yearning',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '62b4f9e1-bd03-434c-beb2-bea6d3e02db2',
    'the broken flame bleeds',
    'psalm_598__the_broken_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_prayer', 'tag_love'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '79188679-f17c-44cd-bc0d-14905574b655',
    'the wounded flame shakes',
    'psalm_599__the_wounded_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_renewal', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_sabbath',
    'cat_praise',
    'mood_boldness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '37e952e7-6962-4350-b141-df4a59ae4deb',
    'the hidden psalm calls',
    'psalm_600__the_hidden_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_renewal', 'tag_rebirth', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:32:10',
    '2025-07-05 21:32:10',
    'rit_healing',
    'cat_justice',
    'mood_sorrow',
    'arch_the_judge_of_echoes'
);