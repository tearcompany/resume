## Przejście

Short title: Przejście  
Hebrew: נ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Jeśli umrzesz — będziesz żyć.

przejdź  
nie oglądaj się  
przez cień  
przez rzekę

umarłeś  
ale żyjesz  
bo światło  
zostaje

granica  
jest tylko bramą