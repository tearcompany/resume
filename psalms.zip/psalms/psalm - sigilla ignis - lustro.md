## Lustro

Short title: Lustro  
Hebrew: ל  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Patrząc w lustro, widzisz drugiego.

patrzę w lustro  
i widzę nie siebie

widzę  
kogoś, kto czeka  
na rozpoznanie

odbicie  
jest zawsze spotkaniem

każde spojrzenie  
to modlitwa