## Ziarno

Short title: Ziarno  
Hebrew: ד  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Zanim wyrośniesz, musisz zniknąć.

ziarno  
ginie w ziemi  
cicho

nikt nie widzi  
nikt nie wie

wyrośnie  
to, co umarło

pustka  
zanim powstanie światło