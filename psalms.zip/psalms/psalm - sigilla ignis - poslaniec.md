## Posłaniec

Short title: Posłaniec  
Hebrew: צ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Nie ty jesteś przesłaniem — przez ciebie wszystko przechodzi.

nie jestem listem  
ani szeptem

jestem drogą  
dla światła

wiatr przechodzi przeze mnie  
zostawia echo

nie jestem celem  
jestem przejściem

jestem tym, co niesie  
nie tym, co zostaje