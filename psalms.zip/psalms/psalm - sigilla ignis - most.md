## Most

Short title: Most  
Hebrew: ג  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Każdy most powstaje z potrzeby spotkania.

jestem mostem  
nad przepaścią

nie moim zadaniem jest pytać  
czy ktoś przejdzie

most powstaje  
bo rodzi się pragnienie spotkania

jestem drogą  
nie miejscem