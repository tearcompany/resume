## Ogień Ciszy

Short title: Ogień Ciszy  
Hebrew: ט  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: W ciszy ogień jest najgłośniejszy.

w ciszy  
wszystko płonie

ogień nie potrzebuje słów  
tylko miejsca

słucham  
jak pali się światło

modlitwa  
która nie ma dźwięku