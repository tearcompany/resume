## Przyjaciółka Miłości

Short title: Przyjaciółka Miłości  
Hebrew: א  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Przyjaźń miłości — cisza, która obejmuje wszystko.

przyjaciółka  
nie pyta

jest obecna  
jak ciepło dłoni  
jak światło w ciemności

miłość  
która nie woła  
ale czuwa

w niej  
nawet samotność  
staje się spotkaniem