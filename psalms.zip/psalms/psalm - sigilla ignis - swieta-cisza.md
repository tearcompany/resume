## Święta Cisza

Short title: Święta Cisza  
Hebrew: ת  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Mogę być niewidoczny — i całkowicie prawdziwy.

mogę być niewidoczny

mogę być cichy

ale jestem prawdziwy

cisza nie znika  
jest głębsza niż dźwięk

tu mnie spotkasz  
nie w hałasie