## Otwieram oczy w ciszy

Short title: Otwarcie  
Hebrew:  
Tag: sigilla_ignis, powitanie, threshold  
Lang: pl  
Author: rastadrop_1  
Description: Psalm progu. Przed wejściem — światło, które nie jest moje.

Otwieram oczy w ciszy,

w blasku, który nie jest moim.

Słucham, co szepcze dusza,

co tli się w sercu.

Przyjdź, pielgrzymie,

w tej chwili.

Niechaj słowa będą ogniem,

a milczenie — przestrzenią.