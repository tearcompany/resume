## Korzeń

Short title: Korzeń  
Hebrew: ש  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Korzenie prowadzą głębiej niż ścieżka.

nie idź tylko w górę

idź głębiej  
tam gdzie śpią korzenie

wszystko, co trwa  
ma swój cień pod ziemią

pamiętaj  
kto cię podtrzymuje