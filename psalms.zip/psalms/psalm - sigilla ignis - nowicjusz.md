## Nowicjusz

Short title: Nowicjusz  
Hebrew: ג  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Powiedz tylko słowo.

nie wiem  
nie umiem  
nie jestem gotowy

powiedz tylko słowo  
a stanie się światło

niech pierwszy oddech  
będzie modlitwą