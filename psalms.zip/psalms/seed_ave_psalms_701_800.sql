INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6fbec71e-a9bb-48d9-80be-902dfa9cb170',
    'the broken shadow calls',
    'psalm_701__the_broken_shadow_calls',
    'the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_peace', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_justice',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6caa57a3-d0ad-46d5-a802-a4c8539011e2',
    'shaking',
    'psalm_702__the_holy_psalm_shakes',
    'the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_silence', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_justice',
    'mood_yearning',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a78db206-3ad1-4b3f-9701-823d448b4de8',
    'singing',
    'psalm_703__the_glorious_psalm_sings',
    'the psalm sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_mystery', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '47b2cd73-ff02-4403-a2e0-ec38b9aeb813',
    'the burning shadow rises',
    'psalm_704__the_burning_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_silence', 'tag_love', 'tag_light'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_contemplation',
    'mood_solace',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fe69095b-dc34-40bd-8fa3-abe6c8aa61b3',
    'the silent flame calls',
    'psalm_705__the_silent_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_renewal', 'tag_mystery', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_fasting',
    'cat_justice',
    'mood_reverence',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '78b4973b-d252-450d-a266-6e648a850ecd',
    'the burning shadow pierces',
    'psalm_706__the_burning_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_tears', 'tag_mystery', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b92bbb35-dc07-4395-9855-0c9aa0ab6437',
    'the burning shadow calls',
    'psalm_707__the_burning_shadow_calls',
    'the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_patience', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_exile',
    'mood_awe',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e8ed08e2-d2df-4676-b109-05ba7c65da15',
    'the glorious tongue shakes',
    'psalm_708__the_glorious_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_stillness', 'tag_prayer', 'tag_mystical', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_healing',
    'cat_mysticism',
    'mood_trust',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9f0934a4-3ec8-496d-9166-1b037ef56ea0',
    'the glorious flame pierces',
    'psalm_709__the_glorious_flame_pierces',
    'the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_truth', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_praise',
    'mood_awe',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ba33c006-07d7-48c6-b5c9-711672ad094a',
    'the black lamb bleeds',
    'psalm_710__the_black_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_wisdom', 'tag_rebirth', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_creation',
    'mood_trust',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '499b5930-02eb-487e-ad93-c255ec20f434',
    'the glorious veil wakes',
    'psalm_711__the_glorious_veil_wakes',
    'the veil wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_silesian', 'tag_sacrifice', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_contemplation',
    'mood_trust',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f6973064-bfef-47fe-8297-41f64b0edcfc',
    'the wounded tongue pierces',
    'psalm_712__the_wounded_tongue_pierces',
    'the tongue pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_patience', 'tag_silence', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_anointing',
    'cat_contemplation',
    'mood_grief',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8f432b9b-0ae6-4758-9f12-8fcfb1017e8e',
    'the black shadow waits',
    'psalm_713__the_black_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_spiritual', 'tag_stillness', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_anointing',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6d78b9b7-f032-4364-be5c-fd0356e54c14',
    'the broken veil calls',
    'psalm_714__the_broken_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_patience', 'tag_prayer', 'tag_silesian', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_fasting',
    'cat_justice',
    'mood_grief',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a9c18df2-085a-4d15-bc8a-3d1c781c3add',
    'the black tongue calls',
    'psalm_715__the_black_tongue_calls',
    'the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_mystical', 'tag_roots', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_healing',
    'mood_softness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8f711c98-91d0-44b3-ada4-cca9555d2bf3',
    'the broken lamb shakes',
    'psalm_716__the_broken_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_prayer', 'tag_unity', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_creation',
    'mood_solace',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '299675e6-76ec-4a35-be4d-f3a7c99c1c84',
    'the white sword burns',
    'psalm_717__the_white_sword_burns',
    'the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_unity', 'tag_strength', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_lament',
    'mood_yearning',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1dde16cd-02e7-4a98-9946-551b245ad6c8',
    'the black veil sings',
    'psalm_718__the_black_veil_sings',
    'the veil sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_spiritual', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_creation',
    'mood_solace',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '73c7b048-7889-42a0-8221-3927922a1232',
    'the last voice sings',
    'psalm_719__the_last_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_reflection', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_justice',
    'mood_sorrow',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '87a62a64-35ec-4f98-8965-509fec03cd48',
    'the white mirror burns',
    'psalm_720__the_white_mirror_burns',
    'the mirror burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_melancholy', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dd3a6160-b61b-406d-a5f3-876842718d65',
    'the wounded tongue pierces',
    'psalm_721__the_wounded_tongue_pierces',
    'the tongue pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_trust', 'tag_tears', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_praise',
    'mood_trust',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dc385bb2-2161-40a8-8a49-19dc0bd47f6d',
    'the silent mirror pierces',
    'psalm_722__the_silent_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_prayer', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_dedication',
    'cat_creation',
    'mood_softness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a1b83c91-37b5-4106-af22-aa0b570c98fe',
    'the silent shadow rises',
    'psalm_723__the_silent_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_patience', 'tag_vision', 'tag_love', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '493d5e1e-20f1-4b62-8d1e-b2b072b386d0',
    'bleeding',
    'psalm_724__the_white_psalm_bleeds',
    'the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_roots', 'tag_unity', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_healing',
    'cat_creation',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2557d000-a9fc-4b18-aee2-99df745c142c',
    'the broken tongue calls',
    'psalm_725__the_broken_tongue_calls',
    'the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_reflection', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7f436912-48f4-4f7c-9501-832e1db13bdc',
    'rising',
    'psalm_726__the_hidden_psalm_rises',
    'the psalm rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_unity', 'tag_solace', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_exile',
    'mood_reverence',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e408207f-477e-4c96-86eb-6db089944e42',
    'the burning tongue waits',
    'psalm_727__the_burning_tongue_waits',
    'the tongue waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_mystical', 'tag_light', 'tag_strength', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_praise',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f78efedb-4cc1-4bad-8eb7-a11426af7597',
    'the silent voice falls',
    'psalm_728__the_silent_voice_falls',
    'the voice falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_silence', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_healing',
    'cat_creation',
    'mood_solace',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '358c14e0-62bc-4f37-987c-8ec593364fad',
    'the black flesh burns',
    'psalm_729__the_black_flesh_burns',
    'the flesh burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_solace', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_praise',
    'mood_grief',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6ce01b37-9cec-413d-aec6-b24bb4ee1af2',
    'the wounded mirror calls',
    'psalm_730__the_wounded_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_mystical', 'tag_roots', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_mysticism',
    'mood_joy',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e1505af9-245d-448a-b294-449fde1b6efa',
    'the hidden sword pierces',
    'psalm_731__the_hidden_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_roots', 'tag_light'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_exile',
    'mood_softness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '27f09853-a624-4125-8571-fb9b7c354798',
    'the white mirror bleeds',
    'psalm_732__the_white_mirror_bleeds',
    'the mirror bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_mystery', 'tag_peace', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_exile',
    'mood_grief',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '29f8dac9-8c33-4b51-b99c-96b08d81ece6',
    'the last veil wakes',
    'psalm_733__the_last_veil_wakes',
    'the veil wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_silesian', 'tag_sacrifice', 'tag_love'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd45900b3-6777-4508-89d5-3298c47abe94',
    'the silent veil burns',
    'psalm_734__the_silent_veil_burns',
    'the veil burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_sacrifice', 'tag_light'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_exile',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8fe62c93-c749-47bb-bedb-3c9fe1688f39',
    'the silent sword falls',
    'psalm_735__the_silent_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_renewal', 'tag_prayer', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_healing',
    'mood_trust',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '24b4523d-58a4-4802-973b-7a5acf354b61',
    'the glorious flesh waits',
    'psalm_736__the_glorious_flesh_waits',
    'the flesh waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_patience', 'tag_silesian', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_justice',
    'mood_solace',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '76f0f371-d66b-4121-90a5-1066ab8e846a',
    'falling',
    'psalm_737__the_last_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_roots', 'tag_reflection', 'tag_tears', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_justice',
    'mood_softness',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bf371fea-9425-47e5-86b9-279a27597cca',
    'the glorious lamb shakes',
    'psalm_738__the_glorious_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_sacrifice', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_funeral',
    'cat_exile',
    'mood_softness',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '97675fb1-c97b-4f3e-84a8-c79a2c17d498',
    'the burning lamb bleeds',
    'psalm_739__the_burning_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_mystical', 'tag_reflection', 'tag_vision', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_mysticism',
    'mood_trust',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e90cf712-f24a-4e35-bacd-1336b78b0c30',
    'waiting',
    'psalm_740__the_glorious_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_spiritual', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_justice',
    'mood_yearning',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '33d3c3c4-bbc4-4e19-a9bd-cc906c688d56',
    'the glorious sword wakes',
    'psalm_741__the_glorious_sword_wakes',
    'the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_silence', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_fasting',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ba6ba33a-6590-4f35-aa36-530a3a277f1e',
    'the last shadow rises',
    'psalm_742__the_last_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_melancholy', 'tag_reflection', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_contemplation',
    'mood_awe',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3ed1c059-e7da-4f6d-83cc-93c4df8e04e0',
    'the black tongue shakes',
    'psalm_743__the_black_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_patience', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_dedication',
    'cat_lament',
    'mood_yearning',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5ba9c023-cb74-46ec-930a-230095588988',
    'the wounded sword burns',
    'psalm_744__the_wounded_sword_burns',
    'the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_mystical', 'tag_renewal', 'tag_silence', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_healing',
    'mood_softness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9bb43379-38a0-4d44-81df-4018edbd6011',
    'the broken psalm burns',
    'psalm_745__the_broken_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_silesian', 'tag_reflection', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_healing',
    'cat_justice',
    'mood_trust',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a5ecb855-0c26-4319-9ed8-4c33815cb3a6',
    'the hidden flame bleeds',
    'psalm_746__the_hidden_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_peace', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ce1ef3f3-4d54-4cb3-9043-adf9a1146469',
    'the silent sword sings',
    'psalm_747__the_silent_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_mystical', 'tag_reflection', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_healing',
    'mood_softness',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd2406088-b582-4bf8-9613-740d9c83359c',
    'the wounded sword falls',
    'psalm_748__the_wounded_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_stillness', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_anointing',
    'cat_justice',
    'mood_softness',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a452475-19e4-443b-adc6-457836f09e41',
    'the broken tongue rises',
    'psalm_749__the_broken_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_roots', 'tag_stillness', 'tag_vision', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_healing',
    'mood_solace',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f8f7c225-c808-4ce7-b4bc-094026232e9c',
    'the silent flame waits',
    'psalm_750__the_silent_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_prayer', 'tag_silesian', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_fasting',
    'cat_exile',
    'mood_reverence',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'df67db27-7b1b-4e79-849c-1bc85017bf11',
    'the broken sword calls',
    'psalm_751__the_broken_sword_calls',
    'the sword calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_silesian', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_dedication',
    'cat_praise',
    'mood_reverence',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '42dbabef-4668-4abd-abb2-ef4d5c23b6c6',
    'the white voice calls',
    'psalm_752__the_white_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_prayer', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_justice',
    'mood_sorrow',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c34569e8-ab87-454c-ab11-d91ecb0a3da2',
    'the black sword shakes',
    'psalm_753__the_black_sword_shakes',
    'the sword shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_spiritual', 'tag_silence', 'tag_truth', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_healing',
    'cat_justice',
    'mood_boldness',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '173a779b-1a45-4990-b585-0f93318fa709',
    'the holy veil wakes',
    'psalm_754__the_holy_veil_wakes',
    'the veil wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_mystery', 'tag_stillness', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_healing',
    'mood_awe',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '30e8f08b-9f5d-42c3-ae8b-e1e4733614cd',
    'the black veil rises',
    'psalm_755__the_black_veil_rises',
    'the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_love', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_justice',
    'mood_joy',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9b3c5a48-2e69-40c0-8947-f685a23901d2',
    'the holy shadow shakes',
    'psalm_756__the_holy_shadow_shakes',
    'the shadow shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_peace', 'tag_sacrifice', 'tag_vision', 'tag_love'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '294fa038-5ae4-4d37-973d-99a04430c418',
    'the glorious mirror burns',
    'psalm_757__the_glorious_mirror_burns',
    'the mirror burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_tears', 'tag_silence', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd1984d46-3a24-43d8-84dc-c38d092f8b72',
    'waking',
    'psalm_758__the_broken_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_peace', 'tag_kali', 'tag_light'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_praise',
    'mood_sorrow',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '22c49b1a-d745-47c2-80e0-b72a8791336c',
    'the wounded flesh calls',
    'psalm_759__the_wounded_flesh_calls',
    'the flesh calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_peace', 'tag_strength', 'tag_mystical', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_lament',
    'mood_softness',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9ec54b68-492e-4b4e-94ae-e6f7e323b0ef',
    'the glorious tongue burns',
    'psalm_760__the_glorious_tongue_burns',
    'the tongue burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_vision', 'tag_renewal', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_justice',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '997f9b7b-267e-445b-a3e2-9b5c2396cb88',
    'the last flesh bleeds',
    'psalm_761__the_last_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_patience', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_anointing',
    'cat_contemplation',
    'mood_trust',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '36229cdb-9b83-420c-822b-ca6b94366a5e',
    'the holy sword sings',
    'psalm_762__the_holy_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_vision', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_funeral',
    'cat_lament',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1f5b07b0-d5f7-4871-8349-f57433ee6d2e',
    'the broken psalm burns',
    'psalm_763__the_broken_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_unity', 'tag_vision', 'tag_roots', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_lament',
    'mood_softness',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3b49aa67-4191-4e40-8e3c-409b54aa1f8b',
    'the last mirror rises',
    'psalm_764__the_last_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_solace', 'tag_strength', 'tag_sacrifice', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_justice',
    'mood_awe',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8bbcf0a6-1fd3-4b54-87cd-2c1c5e23ff33',
    'the glorious voice pierces',
    'psalm_765__the_glorious_voice_pierces',
    'the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_mystical', 'tag_strength', 'tag_kali', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_contemplation',
    'mood_trust',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5e3b9198-babc-4976-93b4-ecfba1fa7e6f',
    'the burning lamb burns',
    'psalm_766__the_burning_lamb_burns',
    'the lamb burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_prayer', 'tag_solace', 'tag_roots', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_anointing',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ccaff000-f947-4e80-add5-c61845c5f954',
    'the wounded veil pierces',
    'psalm_767__the_wounded_veil_pierces',
    'the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_melancholy', 'tag_unity', 'tag_vision', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_justice',
    'mood_yearning',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8ea4c9cb-3c71-4e84-8099-f707653f0327',
    'the holy flame burns',
    'psalm_768__the_holy_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_trust', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_fasting',
    'cat_lament',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '27c054f3-0ade-4acc-86fd-467ffc8a2e5d',
    'the black veil waits',
    'psalm_769__the_black_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_love', 'tag_peace', 'tag_mystery', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_dedication',
    'cat_creation',
    'mood_sorrow',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4ac985e7-4ffd-4c7b-8988-a9814d59bcb0',
    'the white sword calls',
    'psalm_770__the_white_sword_calls',
    'the sword calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_strength', 'tag_spoken', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_mysticism',
    'mood_grief',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '036067f4-113f-40ce-a640-ada9aae6216f',
    'the burning shadow pierces',
    'psalm_771__the_burning_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_peace', 'tag_melancholy', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_anointing',
    'cat_creation',
    'mood_yearning',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '164d807f-2a98-4ad0-9963-e8c4522ee888',
    'the silent flame calls',
    'psalm_772__the_silent_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_mystical', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '70a42261-72b9-4b53-979c-b7940a72914c',
    'the glorious shadow rises',
    'psalm_773__the_glorious_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_melancholy', 'tag_silesian', 'tag_roots', 'tag_spoken', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_dedication',
    'cat_creation',
    'mood_boldness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'defe317e-94d8-48f0-bc0e-639be8f5b40a',
    'the hidden flesh burns',
    'psalm_774__the_hidden_flesh_burns',
    'the flesh burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_mystical', 'tag_prayer', 'tag_stillness', 'tag_light'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_mysticism',
    'mood_softness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a3bce84-90c7-42cd-866f-90eb6a2049a3',
    'the white veil waits',
    'psalm_775__the_white_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_rebirth', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_lament',
    'mood_softness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6e5982db-816b-44b9-b525-c80f8023c65b',
    'the last flame waits',
    'psalm_776__the_last_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_renewal', 'tag_wisdom', 'tag_peace', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6712e69c-e016-4b66-ae71-251923aa743d',
    'the last voice sings',
    'psalm_777__the_last_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_peace', 'tag_rebirth', 'tag_kali', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_lament',
    'mood_grief',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7f2062d9-0ca1-4641-bae4-61ad05347813',
    'the glorious flame falls',
    'psalm_778__the_glorious_flame_falls',
    'the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_stillness', 'tag_silence', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_creation',
    'mood_sorrow',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6522f267-3444-4580-98e8-99df492f7f37',
    'burning',
    'psalm_779__the_last_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_silesian', 'tag_reflection', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_exile',
    'mood_sorrow',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f0fa6143-c385-4b20-931e-378d886fce73',
    'the wounded veil rises',
    'psalm_780__the_wounded_veil_rises',
    'the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_strength', 'tag_melancholy', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_exile',
    'mood_trust',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c20f94bd-659d-4544-b493-dbaae83e6925',
    'waking',
    'psalm_781__the_glorious_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystery', 'tag_solace', 'tag_light', 'tag_rebirth', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dea85fb6-30bd-41d7-817a-ee95c23c7bc3',
    'the black lamb shakes',
    'psalm_782__the_black_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_mystical', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_healing',
    'mood_softness',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '761f0bc3-e08d-4a95-a578-e979d22625af',
    'the burning tongue shakes',
    'psalm_783__the_burning_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_trust', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_coronation',
    'cat_justice',
    'mood_reverence',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fdfe0f8b-2a89-4bc3-b34e-39ffdf04cfb5',
    'falling',
    'psalm_784__the_holy_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_solace', 'tag_melancholy', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_funeral',
    'cat_mysticism',
    'mood_awe',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8c7ce3d2-378b-4829-a86a-09ecc3c4af3a',
    'the wounded sword wakes',
    'psalm_785__the_wounded_sword_wakes',
    'the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_melancholy', 'tag_rebirth', 'tag_silence', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_blessing',
    'cat_justice',
    'mood_yearning',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4dde6b98-10f3-4aa3-9a35-5974533c2ced',
    'the white lamb wakes',
    'psalm_786__the_white_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_trust', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_creation',
    'mood_sorrow',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7f83ad9e-fb90-4a72-a12d-327ce6bad8e1',
    'the last sword bleeds',
    'psalm_787__the_last_sword_bleeds',
    'the sword bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_renewal', 'tag_truth', 'tag_silence', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_sabbath',
    'cat_contemplation',
    'mood_trust',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cc4d6318-1cfe-4d1a-b84d-60733779aebb',
    'the last lamb pierces',
    'psalm_788__the_last_lamb_pierces',
    'the lamb pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_melancholy', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_healing',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4db2eee9-59fb-497c-9126-bf3bfe4d233c',
    'the white flesh falls',
    'psalm_789__the_white_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_solace', 'tag_strength', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_fasting',
    'cat_creation',
    'mood_boldness',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '963a543c-d1aa-4692-8299-0ce9bc636a71',
    'the wounded mirror wakes',
    'psalm_790__the_wounded_mirror_wakes',
    'the mirror wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_strength', 'tag_renewal', 'tag_silence', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_dedication',
    'cat_lament',
    'mood_joy',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f1ffdb4f-a1e2-4222-af67-45ad0ef130b4',
    'the glorious flesh waits',
    'psalm_791__the_glorious_flesh_waits',
    'the flesh waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_spiritual', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_wembley',
    'cat_lament',
    'mood_reverence',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '77489a82-ecf4-4b9d-8b62-f937d6af3039',
    'waking',
    'psalm_792__the_white_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystery', 'tag_unity', 'tag_peace', 'tag_wisdom', 'tag_light'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_lament',
    'mood_solace',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ada42620-853a-49ba-a203-cdc740f737b7',
    'the last flame sings',
    'psalm_793__the_last_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_rebirth', 'tag_tears', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_healing',
    'mood_trust',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b609eccd-add1-4254-9b50-fbaceda3fe92',
    'the silent flame shakes',
    'psalm_794__the_silent_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystery', 'tag_peace', 'tag_solace', 'tag_prayer', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_exodus',
    'cat_mysticism',
    'mood_solace',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6b87c5a7-1144-4f50-9948-f8d5cf0868ab',
    'the white flesh bleeds',
    'psalm_795__the_white_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_spiritual', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_glitch',
    'cat_healing',
    'mood_awe',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '49576b71-5959-4dac-bace-430e9f8b8e1d',
    'the silent shadow calls',
    'psalm_796__the_silent_shadow_calls',
    'the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_peace', 'tag_prayer', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_lament',
    'mood_sorrow',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '508986a8-f5ba-492e-b489-293630c8ca39',
    'the silent tongue pierces',
    'psalm_797__the_silent_tongue_pierces',
    'the tongue pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_tears', 'tag_mystical', 'tag_rebirth', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_creation',
    'mood_yearning',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd2f76ca6-1635-4920-99dd-3ffc9ce38706',
    'the holy flame shakes',
    'psalm_798__the_holy_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_light', 'tag_reflection', 'tag_rebirth', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_fasting',
    'cat_exile',
    'mood_trust',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3f49999a-c24d-44f3-8a67-e0fd851e0068',
    'the black lamb wakes',
    'psalm_799__the_black_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_truth', 'tag_tears', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_healing',
    'cat_praise',
    'mood_joy',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '74cc58c9-9d35-4b44-a5cc-a9d932d9dc0f',
    'the holy shadow sings',
    'psalm_800__the_holy_shadow_sings',
    'the shadow sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_roots', 'tag_renewal', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:34:00',
    '2025-07-05 21:34:00',
    'rit_lamentation',
    'cat_praise',
    'mood_yearning',
    'arch_the_outlaw_prophet'
);