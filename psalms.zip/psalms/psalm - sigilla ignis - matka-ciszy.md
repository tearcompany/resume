## Matka Ciszy

Short title: Matka Ciszy  
Hebrew: מ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Milczenie rodzi nowe światło.

milczenie jest łonem  
ciszy

w nim rośnie światło  
którego nie pojmuję

jestem matką  
każdego szeptu  
każdej modlitwy

rodzę się w ciszy  
i w niej wracam