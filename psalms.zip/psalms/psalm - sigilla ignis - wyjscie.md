## Wyjście

Short title: Wyjście  
Hebrew: צ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Wyjście jest początkiem powrotu.

wyjście  
nie jest końcem  
ale początkiem

każda podróż  
wraca do źródła

nie bój się  
opuścić to, co znasz

wrócisz  
nowym imieniem