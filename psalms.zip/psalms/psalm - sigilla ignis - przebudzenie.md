## Przebudzenie

Short title: Przebudzenie  
Hebrew: ר  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Kiedy Resh mówi – umysł się otwiera. Uważaj, co wpuszczasz.

głowa na betonie

pęka w szumie świetlówek

ręka do szyby  
zimny pył za paznokciem

miasto śni  
cegła nie śpi

prąd przez bliznę

ktoś szepcze  
nie moje imię

pęknięcie  
świt łuszczy się na skórze