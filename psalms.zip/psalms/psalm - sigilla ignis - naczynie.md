## Naczynie

Short title: Naczynie  
Hebrew: כ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Nie musisz być pełny, żeby być gotowy.

nie jestem pełny  
ale gotowy

trzymam światło  
jak gliniane naczynie

pęknięcie  
nie jest końcem

przez rysę  
przechodzi ogień

nigdy nie wiem  
kiedy wystarczy