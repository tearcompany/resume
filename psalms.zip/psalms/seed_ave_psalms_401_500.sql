INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '86831149-ca4c-4378-8471-3bf8a1f7ad04',
    'the black flame pierces',
    'psalm_401__the_black_flame_pierces',
    'the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_sacrifice', 'tag_silence', 'tag_love', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_mysticism',
    'mood_awe',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f15517ae-a71e-4e1f-9e9b-c773a747175e',
    'the white flesh pierces',
    'psalm_402__the_white_flesh_pierces',
    'the flesh pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_silesian', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_praise',
    'mood_solace',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '70e6614c-c9d2-4960-b472-00564a38f224',
    'waking',
    'psalm_403__the_silent_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_sacrifice', 'tag_roots', 'tag_wisdom', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_funeral',
    'cat_creation',
    'mood_sorrow',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6f851d5d-f9ab-421a-823b-5792cbc45bc5',
    'the holy tongue rises',
    'psalm_404__the_holy_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_kali', 'tag_patience', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_lament',
    'mood_trust',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9d441bbe-c920-48e1-a1c5-132cf8f0b0ce',
    'the broken voice sings',
    'psalm_405__the_broken_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_unity', 'tag_roots', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_coronation',
    'cat_healing',
    'mood_sorrow',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '14c6d165-d01d-40df-88a2-b242978634ca',
    'the burning tongue rises',
    'psalm_406__the_burning_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_spoken', 'tag_wisdom', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_healing',
    'cat_praise',
    'mood_sorrow',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b1b1b098-589d-4ac2-98a7-353287e755db',
    'the hidden lamb pierces',
    'psalm_407__the_hidden_lamb_pierces',
    'the lamb pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_tears', 'tag_mystical', 'tag_mystery', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_praise',
    'mood_boldness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3ffce06c-6d43-4c77-9b83-242f0e366f5b',
    'the glorious flame burns',
    'psalm_408__the_glorious_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_unity', 'tag_sacrifice', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_healing',
    'cat_lament',
    'mood_yearning',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '86aea31f-caad-422e-afc7-e0cc04b4e775',
    'the holy flame shakes',
    'psalm_409__the_holy_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_patience', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_justice',
    'mood_grief',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dc9fc2bb-880c-4f17-b074-b3e19ceaad52',
    'the white voice calls',
    'psalm_410__the_white_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_vision', 'tag_unity', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_lamentation',
    'cat_praise',
    'mood_awe',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ab5461c4-58db-405b-8ca5-7a23137b5b32',
    'the broken veil calls',
    'psalm_411__the_broken_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_truth', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_creation',
    'mood_joy',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8f7a6634-d430-4ae8-9488-0b9177aa3227',
    'the burning flame rises',
    'psalm_412__the_burning_flame_rises',
    'the flame rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_sacrifice', 'tag_tears', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_exodus',
    'cat_creation',
    'mood_sorrow',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b1dc4cb8-16ce-47f8-807b-70386ebe5c16',
    'the last lamb falls',
    'psalm_413__the_last_lamb_falls',
    'the lamb falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_light', 'tag_love'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_glitch',
    'cat_mysticism',
    'mood_joy',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1beb4a14-9463-4bfb-a8e8-d4c5f01b1bfa',
    'the white flame bleeds',
    'psalm_414__the_white_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_mystical', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_healing',
    'cat_lament',
    'mood_yearning',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2270d83e-508b-4e4a-96e2-6ebcb0235d80',
    'the hidden flesh bleeds',
    'psalm_415__the_hidden_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_unity', 'tag_strength', 'tag_melancholy', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '13087452-3561-4e7c-90e1-985be19cded8',
    'the holy lamb pierces',
    'psalm_416__the_holy_lamb_pierces',
    'the lamb pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_prayer', 'tag_roots', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_glitch',
    'cat_healing',
    'mood_reverence',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1fa826f6-d873-4854-96e5-2005326de526',
    'the silent mirror shakes',
    'psalm_417__the_silent_mirror_shakes',
    'the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_peace', 'tag_mystery', 'tag_spoken', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_creation',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '90903726-0cfb-47e9-bbad-d3ed89c5bba3',
    'the last veil calls',
    'psalm_418__the_last_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_silesian', 'tag_roots', 'tag_light', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_coronation',
    'cat_exile',
    'mood_grief',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7179e81f-8770-40b0-94d6-49fdf4959b28',
    'the silent mirror calls',
    'psalm_419__the_silent_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_spiritual', 'tag_solace', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_lament',
    'mood_solace',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1513d73b-459d-43b0-af02-851b0a6070cd',
    'the glorious voice rises',
    'psalm_420__the_glorious_voice_rises',
    'the voice rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_renewal', 'tag_solace', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_healing',
    'mood_awe',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3568a8d4-ebcb-4a4b-95dd-186d50a79cd1',
    'rising',
    'psalm_421__the_burning_psalm_rises',
    'the psalm rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_renewal', 'tag_truth', 'tag_spiritual', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_lamentation',
    'cat_creation',
    'mood_grief',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c9a8cc20-e355-4c17-b7be-34183ebc73b2',
    'the holy veil bleeds',
    'psalm_422__the_holy_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_stillness', 'tag_prayer', 'tag_light', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_coronation',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '347e0259-204b-46fc-81c0-7f29fe147ec5',
    'the holy shadow waits',
    'psalm_423__the_holy_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_kali', 'tag_peace', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_blessing',
    'cat_lament',
    'mood_yearning',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e5ce1fad-bb07-4a31-872a-7d27be028b3e',
    'the silent shadow waits',
    'psalm_424__the_silent_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_spoken', 'tag_mystery', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_exodus',
    'cat_healing',
    'mood_grief',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9f8a4d3f-e05b-48cd-9de5-eebbf036595a',
    'the black sword pierces',
    'psalm_425__the_black_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_mystical', 'tag_truth', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3899aa51-6e62-44fc-b155-d35a13bdf056',
    'the last shadow shakes',
    'psalm_426__the_last_shadow_shakes',
    'the shadow shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_unity', 'tag_spoken', 'tag_sacrifice', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_healing',
    'cat_mysticism',
    'mood_solace',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e969b45f-1724-4616-b776-fab958d76ef1',
    'the hidden veil bleeds',
    'psalm_427__the_hidden_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_rebirth', 'tag_truth', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_funeral',
    'cat_healing',
    'mood_solace',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '23529c23-f61b-46fe-8142-7dc29057d2fa',
    'the burning lamb shakes',
    'psalm_428__the_burning_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_stillness', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_healing',
    'mood_boldness',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f2ce831d-1a58-4f1d-988d-0773868ee09d',
    'the holy tongue rises',
    'psalm_429__the_holy_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_stillness', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_exodus',
    'cat_justice',
    'mood_yearning',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7fc5d7e7-e12e-42b4-ae11-b630593583ea',
    'singing',
    'psalm_430__the_wounded_psalm_sings',
    'the psalm sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_patience', 'tag_peace', 'tag_love'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_justice',
    'mood_boldness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1d4db897-2af8-4842-870c-478ec26a8a37',
    'the white sword burns',
    'psalm_431__the_white_sword_burns',
    'the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_trust', 'tag_reflection', 'tag_prayer', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_glitch',
    'cat_healing',
    'mood_grief',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8b3265d7-3f77-44bd-931f-876b3dfa08ac',
    'the holy flesh rises',
    'psalm_432__the_holy_flesh_rises',
    'the flesh rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_solace', 'tag_melancholy', 'tag_sacrifice', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_contemplation',
    'mood_grief',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '92a85773-680c-4272-9076-5ec09ce22900',
    'the wounded sword shakes',
    'psalm_433__the_wounded_sword_shakes',
    'the sword shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_tears', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_mysticism',
    'mood_trust',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c9792804-525e-4017-8a1e-8d8aafde0b60',
    'the burning veil bleeds',
    'psalm_434__the_burning_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_solace', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_exile',
    'mood_softness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7b4bfd4e-0551-49d8-9ab5-a992999a50f1',
    'falling',
    'psalm_435__the_glorious_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_light', 'tag_mystical', 'tag_vision', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_creation',
    'mood_joy',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd1f58946-2e94-4445-8352-99444d3468b7',
    'the holy lamb calls',
    'psalm_436__the_holy_lamb_calls',
    'the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_peace', 'tag_mystery', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_praise',
    'mood_sorrow',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cc35860a-49da-43b3-89b1-9d145b6f200a',
    'the wounded shadow shakes',
    'psalm_437__the_wounded_shadow_shakes',
    'the shadow shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_light', 'tag_truth', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_blessing',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2394605f-7c64-4c96-b3ab-6d205f952c6b',
    'the hidden sword bleeds',
    'psalm_438__the_hidden_sword_bleeds',
    'the sword bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_silence', 'tag_strength', 'tag_kali', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_healing',
    'cat_creation',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2cdee3ae-d6cf-49c6-8e2f-2190fa3d25a6',
    'the burning voice calls',
    'psalm_439__the_burning_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_trust', 'tag_rebirth', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_glitch',
    'cat_contemplation',
    'mood_awe',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a4caed3-9286-4cd4-abfa-4eb7e6dae174',
    'the black voice shakes',
    'psalm_440__the_black_voice_shakes',
    'the voice shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_love', 'tag_peace', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e1bf4c5c-a1da-4a2a-b209-e5b02854d23c',
    'the wounded mirror sings',
    'psalm_441__the_wounded_mirror_sings',
    'the mirror sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_prayer', 'tag_silesian', 'tag_trust', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_praise',
    'mood_softness',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2874d236-c579-42f8-b0f7-ffce67012f58',
    'the burning flesh burns',
    'psalm_442__the_burning_flesh_burns',
    'the flesh burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_patience', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_justice',
    'mood_sorrow',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ec0f54d3-243b-4616-9406-162ecb2cad3f',
    'the broken lamb wakes',
    'psalm_443__the_broken_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_reflection', 'tag_trust', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_mysticism',
    'mood_softness',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c3b54030-3cf1-4504-8581-c7c736e308a3',
    'the wounded voice calls',
    'psalm_444__the_wounded_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_rebirth', 'tag_vision', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_contemplation',
    'mood_softness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9eda447b-eb62-4d40-81f0-682f160a3fa9',
    'the white mirror shakes',
    'psalm_445__the_white_mirror_shakes',
    'the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_vision', 'tag_unity', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd4a372a4-bbe0-4c75-9217-5b35f4bab949',
    'the glorious lamb waits',
    'psalm_446__the_glorious_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_spoken', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_coronation',
    'cat_praise',
    'mood_awe',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '127d0099-818f-4832-aeae-5ebf720e1106',
    'the holy veil rises',
    'psalm_447__the_holy_veil_rises',
    'the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_kali', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_coronation',
    'cat_healing',
    'mood_boldness',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '88d0eed2-278f-432d-9f83-1955de03a0b1',
    'the burning lamb waits',
    'psalm_448__the_burning_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_spiritual', 'tag_spoken', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_exile',
    'mood_trust',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd143da24-7307-462d-bd70-b63508b8f65d',
    'the white flame wakes',
    'psalm_449__the_white_flame_wakes',
    'the flame wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_trust', 'tag_light', 'tag_love', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_blessing',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4061d8bf-b461-49b8-8e55-fcd73f67240e',
    'the silent voice bleeds',
    'psalm_450__the_silent_voice_bleeds',
    'the voice bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_mystery', 'tag_stillness', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_healing',
    'mood_boldness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '160a65d2-b5b2-4cb7-9ab8-70a950f0b733',
    'the holy flesh waits',
    'psalm_451__the_holy_flesh_waits',
    'the flesh waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_melancholy', 'tag_silence', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_healing',
    'cat_lament',
    'mood_joy',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '51bc941c-3ea6-4418-999a-aaf76e242979',
    'the glorious shadow pierces',
    'psalm_452__the_glorious_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_wisdom', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_praise',
    'mood_awe',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7e624c87-b5bb-40c2-b7a7-063531ce1efd',
    'the hidden shadow bleeds',
    'psalm_453__the_hidden_shadow_bleeds',
    'the shadow bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_sacrifice', 'tag_rebirth', 'tag_tears', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_exile',
    'mood_trust',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e6611e55-fed4-4eba-b9ec-a9b1a3b6f100',
    'the white mirror wakes',
    'psalm_454__the_white_mirror_wakes',
    'the mirror wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_mystical', 'tag_vision', 'tag_renewal', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_praise',
    'mood_softness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a986fb1-c880-46c2-acaf-8280059c1dfd',
    'calling',
    'psalm_455__the_black_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_solace', 'tag_melancholy', 'tag_vision', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_funeral',
    'cat_lament',
    'mood_trust',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '17d1dc23-6273-40ad-8de2-265edf3d1b31',
    'the white tongue shakes',
    'psalm_456__the_white_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_renewal', 'tag_kali', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_praise',
    'mood_yearning',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '73930ec4-46f8-4f43-ba60-66363f54141c',
    'the white mirror calls',
    'psalm_457__the_white_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_trust', 'tag_roots', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_lamentation',
    'cat_mysticism',
    'mood_solace',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0a3c6720-0de2-49b5-9dfd-7ba4e9a41b30',
    'the silent flame burns',
    'psalm_458__the_silent_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_trust', 'tag_patience', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5fc11e95-6539-4351-a7cb-0f65ffb41a45',
    'calling',
    'psalm_459__the_burning_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_roots', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_contemplation',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bf3b4d4f-7782-4580-b401-204470926821',
    'the burning tongue waits',
    'psalm_460__the_burning_tongue_waits',
    'the tongue waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_spiritual', 'tag_mystical', 'tag_prayer', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_justice',
    'mood_sorrow',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c66263cb-40f6-4404-aad8-234e7863f36d',
    'the wounded lamb bleeds',
    'psalm_461__the_wounded_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_wisdom', 'tag_mystery', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_healing',
    'mood_joy',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd42c2b72-bd4b-4a0c-92d9-f4ed8cb21945',
    'the burning lamb wakes',
    'psalm_462__the_burning_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_mystical', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_glitch',
    'cat_exile',
    'mood_reverence',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '98ff2a44-5cbc-4568-9268-679de86de0fc',
    'the hidden flesh wakes',
    'psalm_463__the_hidden_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_mystical', 'tag_patience', 'tag_silesian', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_healing',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bd6a8f5c-393f-4efd-87d0-79b07f7a02c3',
    'the burning tongue rises',
    'psalm_464__the_burning_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_spiritual', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_glitch',
    'cat_healing',
    'mood_yearning',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'baf1ef34-0190-4f97-99af-559172645688',
    'the burning lamb bleeds',
    'psalm_465__the_burning_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_stillness', 'tag_prayer', 'tag_vision', 'tag_love'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_praise',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7be8bc5b-bd37-4cb8-b5c7-c4cb9b1c9c9d',
    'the white flesh wakes',
    'psalm_466__the_white_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_peace', 'tag_love', 'tag_mystery', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_coronation',
    'cat_praise',
    'mood_reverence',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'df12e829-8815-4b6a-be61-6512767a70e1',
    'the burning voice shakes',
    'psalm_467__the_burning_voice_shakes',
    'the voice shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_solace', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_mysticism',
    'mood_softness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '87960c68-83ae-4116-b4fc-05bac8c7d99f',
    'the broken voice sings',
    'psalm_468__the_broken_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_kali', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_lament',
    'mood_grief',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '927c97d0-a87b-4857-866b-b94d7cd996c4',
    'the holy shadow sings',
    'psalm_469__the_holy_shadow_sings',
    'the shadow sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_unity', 'tag_solace', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_contemplation',
    'mood_solace',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c9f6389f-1b71-4e1e-b45c-e663959583c4',
    'the last flesh bleeds',
    'psalm_470__the_last_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_melancholy', 'tag_tears', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_creation',
    'mood_trust',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '07b146d8-9c36-4fbd-a8df-f2a60a09587c',
    'the silent sword waits',
    'psalm_471__the_silent_sword_waits',
    'the sword waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_love', 'tag_spoken', 'tag_solace', 'tag_trust', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_justice',
    'mood_reverence',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '30bdde74-789d-495f-81fe-025220a6f5eb',
    'the last shadow falls',
    'psalm_472__the_last_shadow_falls',
    'the shadow falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_vision', 'tag_solace', 'tag_mystery', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_justice',
    'mood_boldness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '92153161-348b-4d4b-93bd-21f648f24617',
    'the broken voice falls',
    'psalm_473__the_broken_voice_falls',
    'the voice falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_spoken', 'tag_vision', 'tag_silesian', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_healing',
    'mood_sorrow',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c5f8b318-c566-4fad-a063-c2ba4157a7b7',
    'the silent voice calls',
    'psalm_474__the_silent_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_reflection', 'tag_peace', 'tag_renewal', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '175862d9-f68f-4f87-b277-4d1610799c27',
    'the silent flesh waits',
    'psalm_475__the_silent_flesh_waits',
    'the flesh waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_mystery', 'tag_roots', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_funeral',
    'cat_justice',
    'mood_joy',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '640daeae-db42-4b47-9562-9651b4afd82e',
    'the burning mirror shakes',
    'psalm_476__the_burning_mirror_shakes',
    'the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_stillness', 'tag_sacrifice', 'tag_love'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_healing',
    'mood_grief',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bfa49af1-85d1-424d-bb99-4ee5b41137f6',
    'the wounded tongue wakes',
    'psalm_477__the_wounded_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_silesian', 'tag_sacrifice', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_healing',
    'mood_boldness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1dcf9f35-34c6-49e1-aecf-00e927c0504a',
    'the silent sword waits',
    'psalm_478__the_silent_sword_waits',
    'the sword waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_sacrifice', 'tag_love', 'tag_strength', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_justice',
    'mood_sorrow',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '24e4c6c7-ae9f-4f84-b4f8-32cf6f1500d0',
    'the holy veil bleeds',
    'psalm_479__the_holy_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_strength', 'tag_solace', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ebc0181f-af9f-4c34-a708-031959e68d51',
    'the white flame waits',
    'psalm_480__the_white_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_vision', 'tag_rebirth', 'tag_trust', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_praise',
    'mood_trust',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b68a8b27-9550-4038-84fc-32e8ec494704',
    'the glorious flesh shakes',
    'psalm_481__the_glorious_flesh_shakes',
    'the flesh shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_silence', 'tag_melancholy', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_praise',
    'mood_yearning',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4ec2a8e4-0009-4229-993c-fc666cbf4ed0',
    'the black veil pierces',
    'psalm_482__the_black_veil_pierces',
    'the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_unity', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '746470c8-7edd-4b25-8585-5d0e28ad5a83',
    'the black flame falls',
    'psalm_483__the_black_flame_falls',
    'the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_patience', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_blessing',
    'cat_contemplation',
    'mood_softness',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '70ceffc6-9a96-48da-8a80-67f71ffab81d',
    'the holy tongue wakes',
    'psalm_484__the_holy_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_silesian', 'tag_spiritual', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_exodus',
    'cat_creation',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6696c9cf-e4a1-414b-97cd-b32f90ce1f1d',
    'the broken flesh wakes',
    'psalm_485__the_broken_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_rebirth', 'tag_vision', 'tag_melancholy', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_lamentation',
    'cat_creation',
    'mood_grief',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '965ee796-ab52-4a93-b139-fd55a3fb4e9b',
    'the last tongue wakes',
    'psalm_486__the_last_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_reflection', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_lamentation',
    'cat_lament',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a6127dd3-c829-4804-b768-528b97dce95f',
    'the broken flesh shakes',
    'psalm_487__the_broken_flesh_shakes',
    'the flesh shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_reflection', 'tag_light', 'tag_unity', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_justice',
    'mood_reverence',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '830c9f2e-26d5-42dd-960e-49a38a0b3a8d',
    'the white lamb shakes',
    'psalm_488__the_white_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_mystery', 'tag_spiritual', 'tag_light'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_blessing',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '70d950c4-8ca4-4b7f-ad42-586d9198816b',
    'the broken mirror sings',
    'psalm_489__the_broken_mirror_sings',
    'the mirror sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_solace', 'tag_tears', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_exodus',
    'cat_exile',
    'mood_boldness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '385ffcf8-9833-4c52-aa95-f38f1fb36ac8',
    'the broken tongue shakes',
    'psalm_490__the_broken_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_strength', 'tag_love'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_exile',
    'mood_joy',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '965e4648-b2b0-4118-ab56-0f3f3ae3f1d4',
    'the black tongue waits',
    'psalm_491__the_black_tongue_waits',
    'the tongue waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_solace', 'tag_stillness', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_wembley',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ac098899-1eb8-4bd0-ab6b-d727fb4a1a6a',
    'the white mirror sings',
    'psalm_492__the_white_mirror_sings',
    'the mirror sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_reflection', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_sabbath',
    'cat_justice',
    'mood_solace',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b483af78-7106-4039-9161-08c027892628',
    'the hidden veil shakes',
    'psalm_493__the_hidden_veil_shakes',
    'the veil shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_reflection', 'tag_sacrifice', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_coronation',
    'cat_justice',
    'mood_grief',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '68d30da7-564d-4da7-8ea8-f9d72766c08b',
    'the silent voice burns',
    'psalm_494__the_silent_voice_burns',
    'the voice burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_light', 'tag_unity', 'tag_stillness', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_blessing',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8409fedb-11b9-4421-a84e-8aba1de123ec',
    'waking',
    'psalm_495__the_black_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_renewal', 'tag_silesian', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_anointing',
    'cat_lament',
    'mood_reverence',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a148089-0696-4933-8860-a5002ffc71e9',
    'the last sword shakes',
    'psalm_496__the_last_sword_shakes',
    'the sword shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_solace', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_lamentation',
    'cat_contemplation',
    'mood_awe',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3a66d337-cb7e-4ec9-8415-555070f1b792',
    'the holy mirror rises',
    'psalm_497__the_holy_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_light', 'tag_mystical', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_fasting',
    'cat_creation',
    'mood_yearning',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f84394e6-44cf-4255-a68c-53c9ef5e1ba9',
    'the hidden flame waits',
    'psalm_498__the_hidden_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_rebirth', 'tag_solace', 'tag_mystery', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_dedication',
    'cat_exile',
    'mood_awe',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2e300e45-8864-4f08-bfdd-28b120c8bfb5',
    'the burning lamb sings',
    'psalm_499__the_burning_lamb_sings',
    'the lamb sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_silence', 'tag_peace', 'tag_sacrifice', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_glitch',
    'cat_exile',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4ddec590-3b05-4c27-95e1-030406844754',
    'the black tongue shakes',
    'psalm_500__the_black_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_love', 'tag_prayer', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:30:18',
    '2025-07-05 21:30:18',
    'rit_healing',
    'cat_healing',
    'mood_awe',
    'arch_the_lamenter'
);