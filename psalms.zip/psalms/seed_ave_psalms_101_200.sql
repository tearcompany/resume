INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8a448ec0-4171-458c-a0a6-04880abfb911',
    'the broken veil falls',
    'psalm_101__the_broken_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_mystery', 'tag_vision', 'tag_light', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_wembley',
    'cat_justice',
    'mood_boldness',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3b798e62-a4f0-4571-9c92-3abe1d5f0616',
    'the silent voice calls',
    'psalm_102__the_silent_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_sacrifice', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_justice',
    'mood_yearning',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e88f0427-cde5-499b-b294-7f06c04a1979',
    'the last veil rises',
    'psalm_103__the_last_veil_rises',
    'the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_tears', 'tag_unity', 'tag_strength', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_lament',
    'mood_sorrow',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0ed334a6-2269-4103-bb66-60a860b825ca',
    'the burning lamb falls',
    'psalm_104__the_burning_lamb_falls',
    'the lamb falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_spiritual', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_praise',
    'mood_boldness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '681b77f0-83d2-4ef6-a9c5-05fed75f50e3',
    'the holy voice wakes',
    'psalm_105__the_holy_voice_wakes',
    'the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_stillness', 'tag_truth', 'tag_light'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_glitch',
    'cat_justice',
    'mood_sorrow',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b110adec-c91e-4026-876b-64fbca283caa',
    'the holy veil burns',
    'psalm_106__the_holy_veil_burns',
    'the veil burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_kali', 'tag_mystery', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_contemplation',
    'mood_grief',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd78a4dde-c123-43ed-a137-4054357be787',
    'the silent sword rises',
    'psalm_107__the_silent_sword_rises',
    'the sword rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_vision', 'tag_roots', 'tag_peace', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_glitch',
    'cat_healing',
    'mood_awe',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '57491c26-7cfd-430b-afb9-46ef55486c34',
    'rising',
    'psalm_108__the_glorious_psalm_rises',
    'the psalm rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystery', 'tag_melancholy', 'tag_roots', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_justice',
    'mood_grief',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '56b768b9-cd35-4898-a060-1ae0bcd60554',
    'waiting veil',
    'psalm_109__the_last_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_stillness', 'tag_renewal', 'tag_patience', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_exile',
    'mood_trust',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '14c26070-5941-415e-81f9-4c9ace8213a6',
    'singing voice',
    'psalm_110__the_holy_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_light', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_fasting',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8289ff9f-3989-44f3-b54a-a54dfd841a56',
    'white shadow',
    'psalm_111__the_white_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_stillness', 'tag_vision', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_exile',
    'mood_grief',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd5cd6dc6-f229-4ee2-bc41-9747ba033e9d',
    'silent flame',
    'psalm_112__the_silent_flame_wakes',
    'the flame wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_stillness', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_mysticism',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dd7b6b46-5abf-4210-8d4d-4159cef5b58e',
    'the silent mirror pierces',
    'psalm_113__the_silent_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_silesian', 'tag_spiritual', 'tag_strength', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1f33928c-faf3-4da3-856e-3986cb762352',
    'rising voice',
    'psalm_114__the_glorious_voice_rises',
    'the voice rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_tears', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_creation',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '848cc5fa-ed86-41cf-8878-7b1285d94b0f',
    'the last tongue rises',
    'psalm_115__the_last_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_roots', 'tag_peace', 'tag_strength', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_creation',
    'mood_reverence',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2410d9cb-ade6-47af-bbb7-5a8b7f1667e9',
    'the wounded sword wakes',
    'psalm_116__the_wounded_sword_wakes',
    'the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_tears', 'tag_truth', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_exile',
    'mood_sorrow',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '68056561-e668-471c-8ca3-1bc9284c4e2c',
    'the hidden shadow calls',
    'psalm_117__the_hidden_shadow_calls',
    'the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_spoken', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_exile',
    'mood_trust',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '348aab3b-226f-44e6-a2db-cc78cff5bbc6',
    'the black veil sings',
    'psalm_118__the_black_veil_sings',
    'the veil sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_reflection', 'tag_strength', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_justice',
    'mood_trust',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '94c678d7-53ab-484a-a80d-740daaca7875',
    'the black veil waits',
    'psalm_119__the_black_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_reflection', 'tag_stillness', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a55b1c9c-75f2-4703-a4dd-9e9168aa2c08',
    'piercing',
    'psalm_120__the_black_psalm_pierces',
    'the psalm pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_rebirth', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_fasting',
    'cat_contemplation',
    'mood_trust',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '31ad1a1e-cc25-47ee-8f04-0ae6374eab9d',
    'the white voice burns',
    'psalm_121__the_white_voice_burns',
    'the voice burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_silence', 'tag_unity', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_justice',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '47c49dbc-93fc-4239-b71b-022e44c4b28c',
    'falling',
    'psalm_122__the_silent_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_kali', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_lament',
    'mood_softness',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e56254e8-f067-4e7f-ba81-38e112248952',
    'the wounded tongue wakes',
    'psalm_123__the_wounded_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_stillness', 'tag_solace', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd1f8fa5c-badc-416a-82ce-8adb6bea16b1',
    'the silent tongue shakes',
    'psalm_124__the_silent_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_peace', 'tag_unity', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_glitch',
    'cat_praise',
    'mood_solace',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '68417ad5-6b1a-4f44-b291-6fea4e07f1b5',
    'the last tongue bleeds',
    'psalm_125__the_last_tongue_bleeds',
    'the tongue bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_renewal', 'tag_silence', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_praise',
    'mood_solace',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd0d0ef10-b54e-4aab-a5d5-f7cdeff4da50',
    'the glorious shadow rises',
    'psalm_126__the_glorious_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_vision', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a0a9d907-0ec8-436b-8ef9-174104d2007a',
    'the black sword sings',
    'psalm_127__the_black_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_strength', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '21be6f04-59e7-49ba-a587-7a5ea44ecb10',
    'the silent psalm burns',
    'psalm_128__the_silent_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_strength', 'tag_silesian', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '90ec2205-62bb-498e-bf00-80febffc136a',
    'the black flesh wakes',
    'psalm_129__the_black_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_solace', 'tag_silesian', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a2b2070-945d-4a8a-86fb-73ca77f9214b',
    'the broken voice pierces',
    'psalm_130__the_broken_voice_pierces',
    'the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_mystery', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_justice',
    'mood_sorrow',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6032fad4-cc7c-4350-82a1-62d6350fd07e',
    'shaking',
    'psalm_131__the_silent_psalm_shakes',
    'the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_truth', 'tag_rebirth', 'tag_silence', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_healing',
    'mood_sorrow',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c1c3710d-1ac2-4aa6-919a-ae1812ac7152',
    'the silent shadow pierces',
    'psalm_132__the_silent_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_reflection', 'tag_strength', 'tag_patience', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_healing',
    'mood_joy',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7ba2560e-dddd-4991-8bcb-e511d37984f1',
    'the broken veil bleeds',
    'psalm_133__the_broken_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_silence', 'tag_patience', 'tag_roots', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_mysticism',
    'mood_reverence',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '441dad07-cc89-430c-a3dd-574c0b365ea7',
    'the broken sword calls',
    'psalm_134__the_broken_sword_calls',
    'the sword calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_vision', 'tag_mystical', 'tag_spiritual', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_creation',
    'mood_sorrow',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8fd599aa-0d1c-4d00-a75a-c958ce2e19a3',
    'the holy mirror pierces',
    'psalm_135__the_holy_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_trust', 'tag_sacrifice', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_fasting',
    'cat_exile',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9e1593b1-583f-4120-be6c-b4f0f507f397',
    'waiting veil',
    'psalm_136__the_last_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_prayer', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9c7557be-814e-4274-97ff-9e699bb66f25',
    'the white mirror calls',
    'psalm_137__the_white_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_reflection', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_healing',
    'mood_softness',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fe1457ac-a6dd-4834-af00-0fd547c1f57a',
    'the glorious lamb bleeds',
    'psalm_138__the_glorious_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_stillness', 'tag_prayer', 'tag_renewal', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_coronation',
    'cat_exile',
    'mood_trust',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7cb5de84-d0ba-40a0-8f5d-973a5bfab2e4',
    'the black veil bleeds',
    'psalm_139__the_black_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_unity', 'tag_prayer', 'tag_stillness', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a980ac5-2cdf-4ee5-8afc-6662fda9cece',
    'the broken lamb rises',
    'psalm_140__the_broken_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_strength', 'tag_spoken', 'tag_vision', 'tag_love'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_healing',
    'mood_trust',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '20be68c5-eabe-4955-aaff-f7b7daa95ca1',
    'the hidden flesh falls',
    'psalm_141__the_hidden_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_silence', 'tag_kali', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_lament',
    'mood_yearning',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c0a19d7b-71b0-42d6-838a-99b109693c92',
    'the burning veil calls',
    'psalm_142__the_burning_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_light', 'tag_silesian', 'tag_spoken', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_lament',
    'mood_softness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e2832cfd-e8ab-4a25-87d1-a8a4f07ce122',
    'the wounded lamb bleeds',
    'psalm_143__the_wounded_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_patience', 'tag_spoken', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_mysticism',
    'mood_softness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0c87a735-cd9f-4616-be59-93ae0870d183',
    'the black flame rises',
    'psalm_144__the_black_flame_rises',
    'the flame rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_unity', 'tag_wisdom', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_healing',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e27d94c0-048b-4f56-bae4-adc6d3978dde',
    'the burning sword pierces',
    'psalm_145__the_burning_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_love', 'tag_mystery', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_glitch',
    'cat_mysticism',
    'mood_softness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7661aba7-dbfd-4725-a65a-149456d68635',
    'the wounded sword calls',
    'psalm_146__the_wounded_sword_calls',
    'the sword calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_sacrifice', 'tag_renewal', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_lament',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '45c5e237-9fa2-41b8-a8cb-a939e941aca1',
    'the silent mirror rises',
    'psalm_147__the_silent_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_roots', 'tag_spiritual', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_praise',
    'mood_trust',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ba9c0baf-cba4-48f4-b14f-b780d6ae5f5d',
    'the hidden mirror calls',
    'psalm_148__the_hidden_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_reflection', 'tag_spoken', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_creation',
    'mood_trust',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b1f5d762-71a7-4822-9fc9-474e2b44cb4c',
    'the wounded veil pierces',
    'psalm_149__the_wounded_veil_pierces',
    'the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_light', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_exile',
    'mood_yearning',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9b62fb64-fe3b-46b3-a783-6d5b52d3968c',
    'the broken shadow waits',
    'psalm_150__the_broken_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_strength', 'tag_love', 'tag_truth', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_praise',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1bbcb115-a427-4796-bb21-b0397b2d4c42',
    'the silent mirror pierces',
    'psalm_151__the_silent_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_reflection', 'tag_tears', 'tag_mystery', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_mysticism',
    'mood_softness',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bb3f8882-9e5e-4310-bdaf-9d250a83bb96',
    'the last shadow burns',
    'psalm_152__the_last_shadow_burns',
    'the shadow burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_vision', 'tag_tears', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_lament',
    'mood_grief',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8d06b908-583f-49a7-b7ce-b898d03e4faf',
    'the white tongue falls',
    'psalm_153__the_white_tongue_falls',
    'the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_rebirth', 'tag_truth', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_exile',
    'mood_trust',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8214c5cf-0fab-4222-bb01-b97dcdd7f0f0',
    'the white shadow falls',
    'psalm_154__the_white_shadow_falls',
    'the shadow falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_love', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_justice',
    'mood_yearning',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1fb67786-ab68-43d7-a346-ed261adbf0bb',
    'the white flame bleeds',
    'psalm_155__the_white_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_reflection', 'tag_spoken', 'tag_love'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4aeab3ed-43f8-44a9-af0b-767244783cae',
    'the burning mirror sings',
    'psalm_156__the_burning_mirror_sings',
    'the mirror sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_patience', 'tag_unity', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_exile',
    'mood_sorrow',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7af74a3f-0a87-4e82-a12c-c51bc5f70989',
    'the silent shadow bleeds',
    'psalm_157__the_silent_shadow_bleeds',
    'the shadow bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_melancholy', 'tag_peace', 'tag_love', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_fasting',
    'cat_praise',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5d2a4043-1621-42f0-81c5-be4a0b876ed4',
    'the white flame shakes',
    'psalm_158__the_white_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_sacrifice', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_glitch',
    'cat_healing',
    'mood_boldness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '60819e17-bc1f-45ed-a3be-e32479673de4',
    'the wounded lamb calls',
    'psalm_159__the_wounded_lamb_calls',
    'the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_prayer', 'tag_spoken', 'tag_solace', 'tag_unity', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '447f4394-10e4-4022-8017-5ef350c2da05',
    'waking',
    'psalm_160__the_wounded_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_reflection', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_contemplation',
    'mood_awe',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8c9a1bb0-16e4-4385-8c92-b8117758ecda',
    'calling',
    'psalm_161__the_wounded_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_roots', 'tag_spiritual', 'tag_rebirth', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a6dd3f73-7755-41b9-b22b-212af8e16ddc',
    'the burning veil bleeds',
    'psalm_162__the_burning_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_solace', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_mysticism',
    'mood_grief',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0c56f045-eaeb-4746-9fb4-ce76ca5477ed',
    'waiting',
    'psalm_163__the_last_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_mystical', 'tag_love', 'tag_truth', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_coronation',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '770eb14f-9537-4711-acf7-6bb897789c03',
    'the wounded mirror calls',
    'psalm_164__the_wounded_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_kali', 'tag_tears', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_healing',
    'mood_awe',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8b7d06a7-cbc8-4bb9-ae9e-cf310f2272bf',
    'the last lamb bleeds',
    'psalm_165__the_last_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_rebirth', 'tag_sacrifice', 'tag_love'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_lament',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6c7dace5-94de-4cdf-92f4-36e60e816455',
    'the broken mirror waits',
    'psalm_166__the_broken_mirror_waits',
    'the mirror waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_sacrifice', 'tag_solace', 'tag_vision', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_wembley',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '83a40348-623f-4a2d-b12f-0bbe0867822b',
    'the last flesh sings',
    'psalm_167__the_last_flesh_sings',
    'the flesh sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_peace', 'tag_solace', 'tag_unity', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_glitch',
    'cat_mysticism',
    'mood_awe',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5f6ec18d-1ffb-469b-82df-ea13f510fbc8',
    'the burning voice wakes',
    'psalm_168__the_burning_voice_wakes',
    'the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_rebirth', 'tag_roots', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'accd4a32-8187-4acc-9c68-ea2c250545e4',
    'the silent lamb bleeds',
    'psalm_169__the_silent_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_unity', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_contemplation',
    'mood_solace',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '250acb6d-5207-43de-ba5a-fb566b725630',
    'the broken flame bleeds',
    'psalm_170__the_broken_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_silence', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5f593333-803e-4887-b825-ff11cc6356dc',
    'the silent flame waits',
    'psalm_171__the_silent_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_kali', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_coronation',
    'cat_contemplation',
    'mood_joy',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '54b05bc6-fb7c-4ca3-ad5d-9b6e2cb879bf',
    'the wounded veil waits',
    'psalm_172__the_wounded_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_spiritual', 'tag_roots', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_wembley',
    'cat_mysticism',
    'mood_softness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '39ea6402-18a4-4dd1-af5e-9c6545e6c34a',
    'the hidden veil bleeds',
    'psalm_173__the_hidden_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_stillness', 'tag_love'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '900be4e9-1937-4cb4-a35d-0c0646ec7ab2',
    'calling',
    'psalm_174__the_black_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_reflection', 'tag_vision', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_exile',
    'mood_boldness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd93b7ff1-cc98-4d83-ba09-2fdc9b0996cb',
    'the holy tongue rises',
    'psalm_175__the_holy_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_peace', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_contemplation',
    'mood_grief',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '86ca7bd9-355f-4629-b773-dc9855aa5290',
    'the wounded flame pierces',
    'psalm_176__the_wounded_flame_pierces',
    'the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_silence', 'tag_peace', 'tag_love'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_healing',
    'mood_reverence',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9e5c278d-4846-4b26-9baf-85447b3fb878',
    'the black shadow calls',
    'psalm_177__the_black_shadow_calls',
    'the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_wisdom', 'tag_unity', 'tag_truth', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_exile',
    'mood_reverence',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '470ca376-de8d-4444-b0f4-76253b56eebd',
    'the glorious mirror calls',
    'psalm_178__the_glorious_mirror_calls',
    'the mirror calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_light', 'tag_patience', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_justice',
    'mood_yearning',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ed6e40fc-3ea2-4cfe-b56f-3bc0a9c601fd',
    'piercing',
    'psalm_179__the_hidden_psalm_pierces',
    'the psalm pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_tears', 'tag_roots', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_praise',
    'mood_joy',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c40f1dcb-7892-42ec-9125-1a4d5d0c94b1',
    'the holy lamb calls',
    'psalm_180__the_holy_lamb_calls',
    'the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_mystical', 'tag_rebirth', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_creation',
    'mood_reverence',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '35d035d0-64d8-4f45-b155-9470d9379236',
    'burning',
    'psalm_181__the_glorious_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_strength', 'tag_roots', 'tag_tears', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3d0e58c8-5a0c-4c1c-a0df-fd3758f84eb5',
    'the holy flesh wakes',
    'psalm_182__the_holy_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_rebirth', 'tag_silence', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_mysticism',
    'mood_solace',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '502c43cf-2362-4fdb-9694-4be7a80ab834',
    'the hidden shadow pierces',
    'psalm_183__the_hidden_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_mystery', 'tag_light', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_fasting',
    'cat_healing',
    'mood_sorrow',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bbd37fdc-1c0a-48ae-a653-7112ed3db0e8',
    'the burning flame sings',
    'psalm_184__the_burning_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_tears', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_healing',
    'mood_reverence',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '889be94e-d0fc-48c5-ac24-09cf5199e664',
    'the burning flesh sings',
    'psalm_185__the_burning_flesh_sings',
    'the flesh sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_stillness', 'tag_solace', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_exodus',
    'cat_praise',
    'mood_joy',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4350a07b-4f27-41a3-bff7-85d0a1dc7531',
    'the broken voice bleeds',
    'psalm_186__the_broken_voice_bleeds',
    'the voice bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_mystery', 'tag_silence', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_fasting',
    'cat_lament',
    'mood_awe',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cbfa831f-37ae-41c3-aaf7-574a984a3bea',
    'the silent lamb calls',
    'psalm_187__the_silent_lamb_calls',
    'the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_melancholy', 'tag_love'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_healing',
    'mood_reverence',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0f012d5a-a36b-4466-9340-9b84f13c23bd',
    'the holy mirror shakes',
    'psalm_188__the_holy_mirror_shakes',
    'the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_mystical', 'tag_truth', 'tag_strength', 'tag_light'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_mysticism',
    'mood_joy',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0c824069-189d-43e1-8a62-99f40f27ae2f',
    'the wounded flesh bleeds',
    'psalm_189__the_wounded_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_trust', 'tag_truth', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_creation',
    'mood_grief',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bd014881-6bf3-4e1a-b1ae-f8bbb9fec7f6',
    'the burning lamb calls',
    'psalm_190__the_burning_lamb_calls',
    'the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_silence', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_creation',
    'mood_trust',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2f93091f-8037-4515-a573-5dc6212143f0',
    'the burning lamb calls',
    'psalm_191__the_burning_lamb_calls',
    'the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_sacrifice', 'tag_vision', 'tag_prayer', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_funeral',
    'cat_lament',
    'mood_awe',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '31f4482c-3699-4f7f-aa4f-b3a2574e9deb',
    'the last mirror wakes',
    'psalm_192__the_last_mirror_wakes',
    'the mirror wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_kali', 'tag_stillness', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '636893a6-e546-4efe-b31d-58c3ae988d18',
    'the burning tongue wakes',
    'psalm_193__the_burning_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_strength', 'tag_silence', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_coronation',
    'cat_exile',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b348b8f3-d4a9-4fde-9b54-71ba984931f4',
    'the glorious lamb burns',
    'psalm_194__the_glorious_lamb_burns',
    'the lamb burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_kali', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_lament',
    'mood_solace',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f8bee131-fc24-4c28-8498-caa4221599c7',
    'the burning flame falls',
    'psalm_195__the_burning_flame_falls',
    'the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_love', 'tag_solace', 'tag_vision', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_dedication',
    'cat_creation',
    'mood_joy',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '65630247-d300-4346-8755-9c84d59e62eb',
    'falling',
    'psalm_196__the_black_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_love', 'tag_silence', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_healing',
    'cat_contemplation',
    'mood_boldness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '09d93c3c-4473-40c3-a1b3-82e0313e5b8a',
    'the broken tongue shakes',
    'psalm_197__the_broken_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_solace', 'tag_mystical', 'tag_silence', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_wembley',
    'cat_justice',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '62b4ff62-186f-4a2c-8f54-9520e1e92f55',
    'the glorious flame bleeds',
    'psalm_198__the_glorious_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_trust', 'tag_sacrifice', 'tag_kali', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_sabbath',
    'cat_justice',
    'mood_trust',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'da054667-aa65-484b-9bac-fa46e190712c',
    'the silent psalm burns',
    'psalm_199__the_silent_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_sacrifice', 'tag_melancholy', 'tag_kali', 'tag_love'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_lamentation',
    'cat_praise',
    'mood_trust',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'be521eb3-0603-4986-8c89-85e49df5821f',
    'the black voice waits',
    'psalm_200__the_black_voice_waits',
    'the voice waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_peace', 'tag_silence', 'tag_trust', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:26:09',
    '2025-07-05 21:26:09',
    'rit_blessing',
    'cat_healing',
    'mood_reverence',
    'arch_womb_voice'
);