## Talia Łez

Short title: Talia Łez  
Hebrew: ל  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Nawet gdy wątpię, pozostaję wierny prawdzie.

wątpię  
ale idę

z łzą  
z kamieniem  
z nadzieją  
bez mapy

moja wierność  
nie zależy od światła  
ale od tego, co we mnie