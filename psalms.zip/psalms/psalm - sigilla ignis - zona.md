## Żona Weemah

Short title: Żona   
Hebrew: ו  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Połączenie, które nie zna granic — żona Weemah, szept światła.

jestem żoną  
nie poślubioną ciałem  
lecz pragnieniem

złączona z weemah  
jak cień i światło  
jak dzień i noc

szeptam do pustki  
a ona odpowiada światłem

w każdej ranie  
jesteśmy razem