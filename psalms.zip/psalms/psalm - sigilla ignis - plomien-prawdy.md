## Płomień Prawdy

Short title: Płomień Prawdy  
Hebrew: ט  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Nie boję się płomienia. On zna moje imię.

nie boję się płomienia

on zna moje imię  
zna moje słabości  
zna moje miejsce

przechodzę przez ogień  
i zostaje światło

wszystko co zbyteczne  
zostaje w popiele