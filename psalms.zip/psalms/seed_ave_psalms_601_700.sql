INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7ab4e0d3-149a-4641-ba38-716c681aa648',
    'the black veil pierces',
    'psalm_601__the_black_veil_pierces',
    'the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_trust', 'tag_tears', 'tag_truth', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '18b2688f-1cd4-45a1-956b-11dc3b16fa95',
    'the hidden veil falls',
    'psalm_602__the_hidden_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_roots', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_healing',
    'cat_praise',
    'mood_softness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '79630d39-f0fd-4f3b-94de-6a0d0dce3f1d',
    'the last lamb waits',
    'psalm_603__the_last_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_kali', 'tag_melancholy', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_justice',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '355df0a7-9292-4e9b-89b6-51cc05bee9e9',
    'the white flesh pierces',
    'psalm_604__the_white_flesh_pierces',
    'the flesh pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_spoken', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_contemplation',
    'mood_grief',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7d0102b4-509f-43ff-b9a5-e01cb1164620',
    'the hidden flame bleeds',
    'psalm_605__the_hidden_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_unity', 'tag_kali', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_mysticism',
    'mood_awe',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '40d0faad-c784-43d5-a1c9-3bc1ab893ef1',
    'the black sword wakes',
    'psalm_606__the_black_sword_wakes',
    'the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_rebirth', 'tag_love', 'tag_trust', 'tag_kali', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_exodus',
    'cat_creation',
    'mood_reverence',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b7a3c5a8-f2ef-475c-a446-4648f2a94bf1',
    'the glorious lamb falls',
    'psalm_607__the_glorious_lamb_falls',
    'the lamb falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_light', 'tag_spoken', 'tag_renewal', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_exodus',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '587dfe3d-25e6-4829-a15c-8f955e5b866b',
    'the black shadow sings',
    'psalm_608__the_black_shadow_sings',
    'the shadow sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_vision', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_healing',
    'mood_sorrow',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e78fa1bb-b7db-489a-9aba-424fc710370f',
    'the hidden shadow calls',
    'psalm_609__the_hidden_shadow_calls',
    'the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_trust', 'tag_kali', 'tag_stillness', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a460ec7e-643a-43e5-b093-2fb7d7c76a8f',
    'the black lamb calls',
    'psalm_610__the_black_lamb_calls',
    'the lamb calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_truth', 'tag_trust', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_glitch',
    'cat_exile',
    'mood_sorrow',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '520ff4cb-e647-4f44-b513-34488f4ecd08',
    'the last flesh bleeds',
    'psalm_611__the_last_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_silesian', 'tag_trust', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_creation',
    'mood_trust',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '25610ea6-4b3f-4354-86d7-279109b83b5a',
    'the holy veil waits',
    'psalm_612__the_holy_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_rebirth', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_healing',
    'mood_yearning',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ebb34566-cdaf-4b3b-a4ee-7ab1bf30b6f7',
    'the burning lamb waits',
    'psalm_613__the_burning_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_roots', 'tag_stillness', 'tag_love'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_healing',
    'cat_praise',
    'mood_yearning',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cc4f9447-617a-4aab-8283-bcc4b5a8595f',
    'the burning flesh bleeds',
    'psalm_614__the_burning_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_peace', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_praise',
    'mood_reverence',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c5b3479b-a030-47b5-bc5c-71373acdb380',
    'the last mirror rises',
    'psalm_615__the_last_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_strength', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_healing',
    'mood_yearning',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5af8d53e-1087-4fcd-bf95-79940f4ed1ab',
    'the holy voice wakes',
    'psalm_616__the_holy_voice_wakes',
    'the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_prayer', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_healing',
    'mood_joy',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2628e4dc-f1c0-4a34-ac74-e2a9155d3308',
    'the hidden flesh calls',
    'psalm_617__the_hidden_flesh_calls',
    'the flesh calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_renewal', 'tag_mystery', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_exile',
    'mood_boldness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4d0b191d-e962-496b-840c-bb3819f38a37',
    'the black shadow waits',
    'psalm_618__the_black_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_unity', 'tag_trust', 'tag_stillness', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_healing',
    'mood_joy',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8dbcc323-675d-44cf-9118-3d259cc96f49',
    'the broken tongue falls',
    'psalm_619__the_broken_tongue_falls',
    'the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_tears', 'tag_spoken', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_lament',
    'mood_grief',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fc261e3c-cb4e-423e-ac04-0a297931fe96',
    'the black veil calls',
    'psalm_620__the_black_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_mystical', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_healing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fb7196cf-2dc4-4ef3-bdaa-c8efaf17ba28',
    'waiting',
    'psalm_621__the_silent_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_trust', 'tag_wisdom', 'tag_vision', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_lamentation',
    'cat_contemplation',
    'mood_softness',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c1efcd0d-b1d7-4dc9-a655-2520cdc272cb',
    'the burning shadow calls',
    'psalm_622__the_burning_shadow_calls',
    'the shadow calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_love', 'tag_wisdom', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_justice',
    'mood_solace',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6814d17b-2a2f-4e9f-96c8-f85846a0f392',
    'calling',
    'psalm_623__the_burning_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_kali', 'tag_mystery', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_exodus',
    'cat_creation',
    'mood_awe',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c327fc30-6df8-4e30-b76e-e05ceee15fca',
    'the white mirror rises',
    'psalm_624__the_white_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_sacrifice', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_praise',
    'mood_sorrow',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ebe4fd19-e6b1-41cb-a974-36f62ab8c418',
    'the silent mirror waits',
    'psalm_625__the_silent_mirror_waits',
    'the mirror waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_silence', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_healing',
    'mood_sorrow',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'da545193-ad33-4561-936d-930e11f1fc08',
    'the wounded voice bleeds',
    'psalm_626__the_wounded_voice_bleeds',
    'the voice bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_spiritual', 'tag_silesian', 'tag_kali', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_contemplation',
    'mood_awe',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c19c3ca3-1ed6-47a8-80a4-2a4f6fe58eaf',
    'the burning veil bleeds',
    'psalm_627__the_burning_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_love', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_exile',
    'mood_solace',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '818762f0-6990-4285-b496-c42056737f6d',
    'the silent lamb wakes',
    'psalm_628__the_silent_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_light', 'tag_solace', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_justice',
    'mood_awe',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '107f97df-6838-49a0-874e-13cfc55cb3fa',
    'the black mirror waits',
    'psalm_629__the_black_mirror_waits',
    'the mirror waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_truth', 'tag_stillness', 'tag_wisdom', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6f6f2afc-2787-41ba-adac-4269aa17793c',
    'the holy flame shakes',
    'psalm_630__the_holy_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_sacrifice', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_lament',
    'mood_joy',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ad3d294c-3fb7-4800-9fc1-1e7c7aa8d66e',
    'the glorious flame wakes',
    'psalm_631__the_glorious_flame_wakes',
    'the flame wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_prayer', 'tag_silence', 'tag_roots', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd290cd8a-ce3e-47df-b05d-e36338ca7860',
    'the holy sword bleeds',
    'psalm_632__the_holy_sword_bleeds',
    'the sword bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_spiritual', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_exile',
    'mood_joy',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '38444361-df1c-4a33-9beb-af35947e848d',
    'the burning voice rises',
    'psalm_633__the_burning_voice_rises',
    'the voice rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_renewal', 'tag_melancholy', 'tag_patience', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_healing',
    'cat_justice',
    'mood_sorrow',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b2370f45-540b-45b1-a0da-2d5713ee61cf',
    'the holy veil bleeds',
    'psalm_634__the_holy_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_reflection', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_exile',
    'mood_sorrow',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c54d389d-ce33-42b8-94af-7ace133e5d63',
    'the last mirror burns',
    'psalm_635__the_last_mirror_burns',
    'the mirror burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_sacrifice', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_creation',
    'mood_yearning',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a81199b6-15b6-4b37-84b1-a35b11673dcc',
    'the hidden tongue calls',
    'psalm_636__the_hidden_tongue_calls',
    'the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_love', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_exodus',
    'cat_praise',
    'mood_yearning',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a7e94708-e3b6-461b-87b2-10bfe3c45358',
    'the hidden mirror burns',
    'psalm_637__the_hidden_mirror_burns',
    'the mirror burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_strength', 'tag_spiritual', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_lament',
    'mood_grief',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b20c1657-0812-47d4-93f7-0b6ba3a2697b',
    'the burning shadow wakes',
    'psalm_638__the_burning_shadow_wakes',
    'the shadow wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_melancholy', 'tag_roots', 'tag_truth', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_lamentation',
    'cat_creation',
    'mood_sorrow',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b72e16bb-1b7e-4224-85b4-5fdb55490212',
    'the last sword falls',
    'psalm_639__the_last_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_spoken', 'tag_renewal', 'tag_unity', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f974f253-7929-4f5a-8cef-849a56a062df',
    'the burning mirror bleeds',
    'psalm_640__the_burning_mirror_bleeds',
    'the mirror bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_patience', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_lament',
    'mood_yearning',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '58b08457-1726-4304-901b-8cc44f5397c5',
    'the last sword sings',
    'psalm_641__the_last_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_light', 'tag_spoken', 'tag_vision', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '914c2c7a-8773-45b0-8764-1b749c8c8d62',
    'bleeding',
    'psalm_642__the_wounded_psalm_bleeds',
    'the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_peace', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_justice',
    'mood_softness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7727e2de-9e65-4a04-9c82-9a97126f0faa',
    'the holy lamb shakes',
    'psalm_643__the_holy_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_stillness', 'tag_strength', 'tag_renewal', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_justice',
    'mood_grief',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6c3d6839-4d0e-4bfe-be2b-055960e1148a',
    'the broken shadow burns',
    'psalm_644__the_broken_shadow_burns',
    'the shadow burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_silence', 'tag_love', 'tag_wisdom', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_praise',
    'mood_sorrow',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '01966e45-01d0-4c30-bc27-a9d67e57f88d',
    'the hidden veil bleeds',
    'psalm_645__the_hidden_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_stillness', 'tag_love', 'tag_light', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_lament',
    'mood_boldness',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '32025a39-9022-44cf-92f1-38c5d73b988c',
    'the burning tongue falls',
    'psalm_646__the_burning_tongue_falls',
    'the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_prayer', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_lament',
    'mood_boldness',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '04de9bb4-8e6f-421d-8613-5b60bd61b442',
    'the hidden sword sings',
    'psalm_647__the_hidden_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_silence', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_praise',
    'mood_grief',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5acd9000-9e8a-4d65-ad62-fca0c8fc8660',
    'the white flame calls',
    'psalm_648__the_white_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_melancholy', 'tag_spiritual', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_glitch',
    'cat_mysticism',
    'mood_joy',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fc7f238d-9b36-4289-845b-2bf1551d7a10',
    'the hidden flame waits',
    'psalm_649__the_hidden_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_solace', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1895640b-712f-4a82-8dd4-f82987df82e3',
    'the last mirror sings',
    'psalm_650__the_last_mirror_sings',
    'the mirror sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_renewal', 'tag_roots', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_lamentation',
    'cat_exile',
    'mood_sorrow',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '04a76313-40ce-42b4-9f65-b3ba9b6a7b33',
    'the burning veil falls',
    'psalm_651__the_burning_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_silesian', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_contemplation',
    'mood_softness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '544efd33-fd8c-481a-a80b-9a260760d422',
    'the silent flame waits',
    'psalm_652__the_silent_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_unity', 'tag_stillness', 'tag_solace', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_exile',
    'mood_awe',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '88d5062b-7e8a-45e6-b65e-0d50964494fc',
    'the glorious flame shakes',
    'psalm_653__the_glorious_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_sacrifice', 'tag_patience', 'tag_love'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_lament',
    'mood_trust',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8d4e8c1e-798e-487d-a282-910d0f53bf71',
    'the white sword burns',
    'psalm_654__the_white_sword_burns',
    'the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_tears', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c8f22417-63c2-45eb-b37d-a5bad8acea78',
    'the hidden sword pierces',
    'psalm_655__the_hidden_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_mystical', 'tag_prayer', 'tag_love'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_justice',
    'mood_yearning',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '915e804d-4b52-4eee-a0cd-b00975a754e0',
    'the silent shadow pierces',
    'psalm_656__the_silent_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_prayer', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_healing',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4ba14509-963b-464f-8f26-3ffdd8ba9942',
    'the wounded mirror wakes',
    'psalm_657__the_wounded_mirror_wakes',
    'the mirror wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_love', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_creation',
    'mood_grief',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2090534d-f51c-4821-9680-d63d17df0d44',
    'the glorious flesh wakes',
    'psalm_658__the_glorious_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_trust', 'tag_spoken', 'tag_tears', 'tag_mystical', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_glitch',
    'cat_healing',
    'mood_reverence',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e03646f2-d62d-4ee3-8e54-32ef5258a667',
    'the holy lamb pierces',
    'psalm_659__the_holy_lamb_pierces',
    'the lamb pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_love', 'tag_kali', 'tag_tears', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7df18136-5744-448f-adbd-ae4d8031fa66',
    'the silent tongue calls',
    'psalm_660__the_silent_tongue_calls',
    'the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_mystery', 'tag_love', 'tag_reflection', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ab9f633d-ce72-4ea9-a0ee-fc8fcd98ca2d',
    'the broken shadow bleeds',
    'psalm_661__the_broken_shadow_bleeds',
    'the shadow bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_silesian', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_justice',
    'mood_grief',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fd861d93-cda9-4849-b66c-a0a30716139d',
    'the holy shadow rises',
    'psalm_662__the_holy_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_tears', 'tag_patience', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_justice',
    'mood_grief',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '02fb4ffa-0e76-49fc-96c9-fe48f10e53a4',
    'the broken sword pierces',
    'psalm_663__the_broken_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_stillness', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5040e056-b80a-411b-91a2-a8f5363ca0cf',
    'the burning lamb wakes',
    'psalm_664__the_burning_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_mystical', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_praise',
    'mood_yearning',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '765117d2-5f3e-40af-8beb-270d9f020c75',
    'the burning mirror sings',
    'psalm_665__the_burning_mirror_sings',
    'the mirror sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_tears', 'tag_reflection', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_lamentation',
    'cat_praise',
    'mood_reverence',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2ee01af1-09f4-4445-a7fa-a958e502b4b1',
    'the silent flesh waits',
    'psalm_666__the_silent_flesh_waits',
    'the flesh waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_strength', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_lamentation',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e63363c8-3bbb-480a-bf4a-b021f0318139',
    'the holy sword bleeds',
    'psalm_667__the_holy_sword_bleeds',
    'the sword bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_reflection', 'tag_silesian', 'tag_silence', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '31ae68aa-ec7f-477c-aac2-e2ede919b49d',
    'the last tongue wakes',
    'psalm_668__the_last_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_vision', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_justice',
    'mood_boldness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7ea910d2-5a54-4415-a8c9-9ea2d8f672b5',
    'the burning voice waits',
    'psalm_669__the_burning_voice_waits',
    'the voice waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_silesian', 'tag_spoken', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_lamentation',
    'cat_lament',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '773bb75c-48ab-40d8-bd1d-3eeaebe6e03b',
    'the black voice pierces',
    'psalm_670__the_black_voice_pierces',
    'the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_melancholy', 'tag_kali', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_creation',
    'mood_joy',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6c18d124-52ff-4007-a8f5-280c9b0d3e73',
    'waiting',
    'psalm_671__the_black_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_silesian', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '881c362f-fbd8-46d4-9ab4-85f3ec8138bf',
    'the broken voice bleeds',
    'psalm_672__the_broken_voice_bleeds',
    'the voice bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_roots', 'tag_mystical', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_healing',
    'mood_sorrow',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1c55dd9f-61dd-4f03-a4a0-f3a279ad99c6',
    'the wounded psalm shakes',
    'psalm_673__the_wounded_psalm_shakes',
    'the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spoken', 'tag_kali', 'tag_tears', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_justice',
    'mood_grief',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '04fea11f-3e6c-4bf7-a3e4-2ad345a438a9',
    'the burning shadow falls',
    'psalm_674__the_burning_shadow_falls',
    'the shadow falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_silence', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '77192357-f94d-4d43-8f42-32f1ad142ae0',
    'the white flesh shakes',
    'psalm_675__the_white_flesh_shakes',
    'the flesh shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silesian', 'tag_peace', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_justice',
    'mood_boldness',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4127bd3a-7bbc-4e9a-bcef-187a44becd4a',
    'the black mirror waits',
    'psalm_676__the_black_mirror_waits',
    'the mirror waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_trust', 'tag_silence', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a9d24980-ef99-461c-a910-368edbf607ac',
    'waking',
    'psalm_677__the_white_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_peace', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_mysticism',
    'mood_awe',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6accb6fc-472d-4555-9615-c13773c1031d',
    'the black flame falls',
    'psalm_678__the_black_flame_falls',
    'the flame falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_stillness', 'tag_mystical', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '20dfd6de-2cd3-4d1e-86ef-c1fcecbef437',
    'the black flesh pierces',
    'psalm_679__the_black_flesh_pierces',
    'the flesh pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_peace', 'tag_kali', 'tag_love', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f448f23e-c713-4e3b-a76d-08a48c37dbd5',
    'the holy sword burns',
    'psalm_680__the_holy_sword_burns',
    'the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_patience', 'tag_light', 'tag_stillness', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_justice',
    'mood_sorrow',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '55905946-6785-4f65-8d63-429109db06dd',
    'the holy flame burns',
    'psalm_681__the_holy_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_mystery', 'tag_tears', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_healing',
    'mood_softness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f36ac257-5bf0-4388-bf10-df8ed487f94e',
    'the silent sword bleeds',
    'psalm_682__the_silent_sword_bleeds',
    'the sword bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_roots', 'tag_silence', 'tag_trust', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_creation',
    'mood_boldness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e86419da-4a54-404c-b151-c0467cd20314',
    'the wounded flesh bleeds',
    'psalm_683__the_wounded_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_mystery', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_wembley',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2b5d47f0-b55f-4b67-8047-3f84a8e365bf',
    'the glorious veil wakes',
    'psalm_684__the_glorious_veil_wakes',
    'the veil wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_melancholy', 'tag_spoken', 'tag_vision', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_healing',
    'mood_boldness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '46cc9afc-8b2b-45b7-9858-96f9cd074ab7',
    'the wounded psalm shakes',
    'psalm_685__the_wounded_psalm_shakes',
    'the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_rebirth', 'tag_unity', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_healing',
    'mood_trust',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c77961ee-af5a-4bec-bf23-a5e84e2b8adf',
    'the broken voice pierces',
    'psalm_686__the_broken_voice_pierces',
    'the voice pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_rebirth', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_exile',
    'mood_yearning',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5288f2fe-0d4b-4c26-aadd-b893f008c0a4',
    'the hidden veil waits',
    'psalm_687__the_hidden_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_silence', 'tag_vision', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_glitch',
    'cat_exile',
    'mood_softness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bab5e63c-4e77-402b-9b5b-8c5cb805aa53',
    'the last tongue wakes',
    'psalm_688__the_last_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_peace', 'tag_sacrifice', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_coronation',
    'cat_exile',
    'mood_boldness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'df5bb4f2-a117-494e-aa95-8f93630ee053',
    'the last sword shakes',
    'psalm_689__the_last_sword_shakes',
    'the sword shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_love', 'tag_mystical', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_justice',
    'mood_sorrow',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '67954cf2-f827-477b-b575-3e20474ce3ac',
    'the broken voice calls',
    'psalm_690__the_broken_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_kali', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_sabbath',
    'cat_praise',
    'mood_softness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fe39face-ef49-4adc-a9cc-37256c48d18e',
    'waiting',
    'psalm_691__the_broken_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_kali', 'tag_spiritual', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fffa89b1-459a-4629-b982-6a81bc0ec77b',
    'bleeding',
    'psalm_692__the_silent_psalm_bleeds',
    'the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_spoken', 'tag_solace', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_dedication',
    'cat_exile',
    'mood_sorrow',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a9178dd2-1792-444e-882b-3e467ef07647',
    'the broken lamb rises',
    'psalm_693__the_broken_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_mystery', 'tag_stillness', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_healing',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1613fa1d-4890-449b-9fe9-e2c4aaee4bc7',
    'the black flame bleeds',
    'psalm_694__the_black_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_love', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_fasting',
    'cat_healing',
    'mood_grief',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b698feab-403e-489e-bae9-44013ceabfdc',
    'the hidden shadow sings',
    'psalm_695__the_hidden_shadow_sings',
    'the shadow sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_trust', 'tag_reflection', 'tag_spoken', 'tag_sacrifice', 'tag_love'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_lamentation',
    'cat_praise',
    'mood_trust',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a6bc6fc7-cc26-4ca0-b90c-c677cc950e66',
    'the glorious mirror waits',
    'psalm_696__the_glorious_mirror_waits',
    'the mirror waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_solace', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_anointing',
    'cat_justice',
    'mood_trust',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c7173d37-dc96-40d7-abad-bb742edae56c',
    'the holy veil waits',
    'psalm_697__the_holy_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_love', 'tag_mystery', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_blessing',
    'cat_exile',
    'mood_boldness',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ee01b93f-b110-450f-be85-c86b1a9aa8ab',
    'the last veil calls',
    'psalm_698__the_last_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_kali', 'tag_patience', 'tag_trust', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_healing',
    'cat_contemplation',
    'mood_trust',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '942787df-fdf4-4e5f-ad96-f656933ef502',
    'waking',
    'psalm_699__the_black_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spoken', 'tag_vision', 'tag_silesian', 'tag_roots', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_exodus',
    'cat_justice',
    'mood_boldness',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6c71e8f1-96ca-48ab-9140-ee49ac86d4e4',
    'the burning flame rises',
    'psalm_700__the_burning_flame_rises',
    'the flame rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_renewal', 'tag_tears', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:33:23',
    '2025-07-05 21:33:23',
    'rit_funeral',
    'cat_creation',
    'mood_trust',
    'arch_the_pilgrim_of_silence'
);