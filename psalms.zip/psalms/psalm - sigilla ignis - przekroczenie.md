## Przekroczenie
Short title: Przekroczenie  

Hebrew: ע  

Tag: sigilla_ignis, wisdom, guidance  

Lang: pl  

Author: rastadrop_1  

Description: Każde przekroczenie — to nowe życie.

  

przekraczam  

nie wiem dokąd

  

każdy krok  

to zgoda na nieznane

  

życie  

rodzi się w ruchu

  

przekroczenie  

jest modlitwą