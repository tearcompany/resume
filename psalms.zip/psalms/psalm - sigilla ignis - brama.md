## Brama

Short title: Brama  
Hebrew: ר  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Każda brama prowadzi do nowego światła.

każda brama  
jest szansą

nie bój się przechodzić  
nawet gdy nie widzisz dalej

za bramą  
rodzi się nowe światło

wchodzę  
by zobaczyć