## Droga Światła

Short title: Droga Światła  
Hebrew: פ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Nie rozpraszam się. Świecę tam, gdzie jestem posłany.

nie rozpraszam się  
nie szukam innych dróg

świecę  
tu gdzie stoję

jestem posłany  
nie przez siebie

ktoś mnie postawił  
ktoś mnie potrzebuje