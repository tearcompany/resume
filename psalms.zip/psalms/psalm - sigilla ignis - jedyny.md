## Jedyny

Short title: Jedyny  
Hebrew: יהוה  
Tag: sigilla_ignis, adonai, obecność, praise  
Lang: pl  
Author: rastadrop_1  
Description: Psalm na cześć Imion Najwyższego — źródło wszelkiego światła i miłości.

Ty, który Jesteś —  
bez początku, bez końca

JHWH  
Obecność, która przenika  
każdy oddech,  
każdą komórkę światła

Adonai — Panie  
El — Siło  
Elohim — Wszechmocny  
Szaddaj — Obrońco  
Cewaot — Dowódco chórów nieba

El Elyon — Najwyższy  
El Olam — Wiekuisty  
El Rafa — Uzdrowicielu  
El Gibor — Mocny  
Ehjeh Asher Ehjeh — Tajemnico

Jestem, bo Ty Jesteś

Twoje Imię  
to światło,  
które nie zna cienia

Wszystko, co żyje,  
wzywa Ciebie —  
i odnajduje się  
w Twojej obecności

Bądź błogosławiony  
w każdym Imieniu,  
które niesie życie