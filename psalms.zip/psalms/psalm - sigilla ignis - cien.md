## Cień

Short title: Cień  
Hebrew: ע  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Tam, gdzie światło spotyka cień, rodzi się prawda.

cisza spada na bruk

światło stygnie pod stopami

każdy cień  
ma swoje imię

oddech  
jak chłód piwnicy

skrawek nocy  
w biały dzień

zostaję  
tam, gdzie nikt nie woła