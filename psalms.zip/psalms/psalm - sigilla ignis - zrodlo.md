## Źródło

Short title: Źródło  
Hebrew: ע  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Źródło jest tam, gdzie nikt nie szuka.

szukasz w rzece  
szukasz w deszczu

a źródło  
cicho sączy się pod skałą

prawda  
jest tam  
gdzie nie sięgasz wzrokiem

pozwól sobie  
zaczerpnąć