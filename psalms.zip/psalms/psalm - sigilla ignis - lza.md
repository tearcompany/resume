## Łza

Short title: Łza  
Hebrew: י  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Jedna łza — cały ocean obecności.

niosę łzę  
i to wystarczy

nikt nie widzi  
a jednak  
wszystko się zmienia

sól pod powieką  
światło na języku

płaczę  
a ziemia kwitnie