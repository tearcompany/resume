## Przebudzenie Serca

Short title: Przebudzenie Serca  
Hebrew: א  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Wystarczy, że słyszę. I to już mnie przemienia.

wystarczy, że słyszę

serce budzi się  
od szeptu

nie potrzebuję znaków  
ani cudów

przemienia mnie  
cichy głos  
którego nie szukałem