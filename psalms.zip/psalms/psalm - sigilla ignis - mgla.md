## Mgła

Short title: Mgła  
Hebrew: ס  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: To, że nie widzisz, nie znaczy, że nie jesteś prowadzony.

idę przez mgłę

nie widzę  
ale idę

każdy krok  
prowadzi  
chociaż nie wiem gdzie

zaufaj  
że ścieżka  
istnieje