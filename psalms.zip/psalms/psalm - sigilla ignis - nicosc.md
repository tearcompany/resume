## Nicość

Short title: Nicość  
Hebrew: ן  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Tam, gdzie kończy się wszystko, zaczyna się nowe.

tam, gdzie kończy się wszystko  
zaczyna się nowe

nicość  
to nie pustka

to przestrzeń  
na nowe imię  
nowy ogień

jestem  
nawet, gdy mnie nie ma