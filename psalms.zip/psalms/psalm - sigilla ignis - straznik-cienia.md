## Strażnik Cienia

Short title: Strażnik Cienia  
Hebrew: צ  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Cień nie jest wrogiem, lecz opiekunem światła.

strzegę cienia  
bo on strzeże światła

każdy cień  
ma w sobie  
iskrę początku

strach  
jest czasem opieką

jestem tu  
gdzie noc dotyka świtu