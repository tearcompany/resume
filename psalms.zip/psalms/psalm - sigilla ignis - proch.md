## Proch

Short title: Proch  
Hebrew: ת  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Z prochu powstaje światło.

wszystko wraca do prochu

ale z prochu  
powstaje światło

nic nie ginie  
wszystko  
zostaje przemienione

proch  
to nie koniec  
ale nowy początek