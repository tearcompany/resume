INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'eb70fa00-d3d4-4727-91eb-de8db969cf8a',
    'the black veil burns',
    'psalm_301__the_black_veil_burns',
    'the veil burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_melancholy', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_creation',
    'mood_grief',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '367bda13-233f-4331-b5b6-830022c388d8',
    'waking',
    'psalm_302__the_black_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spoken', 'tag_solace', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2ee4f7f1-2fd0-4e30-8408-e1b83fa876b6',
    'the holy voice rises',
    'psalm_303__the_holy_voice_rises',
    'the voice rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_roots', 'tag_strength', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_funeral',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2d977c3e-764c-4fea-8577-8146d5a50ff9',
    'the black veil falls',
    'psalm_304__the_black_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_mystical', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '689620e0-98b2-423f-bbeb-285ceb6815e6',
    'the glorious mirror rises',
    'psalm_305__the_glorious_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_stillness', 'tag_tears', 'tag_rebirth', 'tag_light'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_justice',
    'mood_softness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b91c9a84-53e1-42ec-be56-3983f28dd956',
    'the wounded sword calls',
    'psalm_306__the_wounded_sword_calls',
    'the sword calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_mystical', 'tag_trust', 'tag_truth', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_creation',
    'mood_reverence',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6133701e-32e7-45a8-a5be-2879d411a5c0',
    'the black tongue falls',
    'psalm_307__the_black_tongue_falls',
    'the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_silence', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_healing',
    'mood_sorrow',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bd890cb2-cccb-477b-96ae-4d57a39290aa',
    'the silent sword falls',
    'psalm_308__the_silent_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_silesian', 'tag_renewal', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_healing',
    'mood_joy',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '57fd21d2-0fa5-4b89-9815-49903f68b53b',
    'the wounded veil calls',
    'psalm_309__the_wounded_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_spoken', 'tag_reflection', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2a5ca307-70e7-4be1-9f44-2237b9e5f48f',
    'the wounded sword sings',
    'psalm_310__the_wounded_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_prayer', 'tag_vision', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ea688cc5-8ae0-4daa-84bd-29e890b28737',
    'the burning shadow rises',
    'psalm_311__the_burning_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_truth', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_contemplation',
    'mood_trust',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '449222db-a34e-473d-81fe-f3a66a097dfb',
    'the wounded lamb falls',
    'psalm_312__the_wounded_lamb_falls',
    'the lamb falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_patience', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_praise',
    'mood_awe',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '68a1eb90-08a6-4bbd-8fe2-101d4d14d0aa',
    'the silent lamb rises',
    'psalm_313__the_silent_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_tears', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_creation',
    'mood_trust',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'fff1d21b-e935-4fcc-ab7f-33f14703ba28',
    'the burning lamb waits',
    'psalm_314__the_burning_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_silence', 'tag_roots', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ef3a3109-7d38-4d84-adce-6d692e90b9f5',
    'the holy shadow shakes',
    'psalm_315__the_holy_shadow_shakes',
    'the shadow shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_peace', 'tag_reflection', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_lament',
    'mood_yearning',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '150a5b00-7aa9-446c-8d7c-5b7f49767c27',
    'the black flesh calls',
    'psalm_316__the_black_flesh_calls',
    'the flesh calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_trust', 'tag_prayer', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_healing',
    'mood_solace',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c8640397-8009-420f-86a0-9fdd55f61843',
    'the silent flesh falls',
    'psalm_317__the_silent_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_renewal', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_creation',
    'mood_trust',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '89c624c5-e4f6-40ab-aee6-f4aaca5a2f8c',
    'the silent sword sings',
    'psalm_318__the_silent_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spoken', 'tag_kali', 'tag_spiritual', 'tag_peace', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_lament',
    'mood_grief',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '751b5407-dee4-488f-be9c-4cae455bc1c2',
    'the wounded flame sings',
    'psalm_319__the_wounded_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_vision', 'tag_trust', 'tag_sacrifice', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_wembley',
    'cat_creation',
    'mood_reverence',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '93b801cf-e079-4289-81da-1f436414d118',
    'the holy sword falls',
    'psalm_320__the_holy_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_strength', 'tag_mystery', 'tag_melancholy', 'tag_love'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_coronation',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4a84486f-8f90-44c8-a9be-8d9d0438044e',
    'the holy flesh wakes',
    'psalm_321__the_holy_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_mystical', 'tag_patience', 'tag_sacrifice', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_lament',
    'mood_yearning',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0754fd66-fc48-4064-afea-d5c15dd43a8e',
    'the wounded flame rises',
    'psalm_322__the_wounded_flame_rises',
    'the flame rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_kali', 'tag_prayer', 'tag_mystery', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_coronation',
    'cat_praise',
    'mood_awe',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd5556c42-20b9-463c-887b-ebf273c04588',
    'the white veil calls',
    'psalm_323__the_white_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_spoken', 'tag_prayer', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_praise',
    'mood_softness',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9923e01f-b27e-4980-8ac5-5cd8b7151201',
    'the broken tongue pierces',
    'psalm_324__the_broken_tongue_pierces',
    'the tongue pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_renewal', 'tag_spoken', 'tag_silesian', 'tag_light'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_lament',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '470a5664-154a-4cdd-91b6-857777532c95',
    'the silent shadow rises',
    'psalm_325__the_silent_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_strength', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_healing',
    'cat_healing',
    'mood_reverence',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '160ba6aa-068e-49e9-8d3f-5cda95e280c9',
    'the last sword rises',
    'psalm_326__the_last_sword_rises',
    'the sword rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_truth', 'tag_wisdom', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_wembley',
    'cat_exile',
    'mood_sorrow',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b7ddf642-45d1-4425-91ee-13a83658c6ed',
    'the holy mirror shakes',
    'psalm_327__the_holy_mirror_shakes',
    'the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_roots', 'tag_silesian', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5374394c-a814-401e-bc9a-f6a96dbbb824',
    'the wounded flesh pierces',
    'psalm_328__the_wounded_flesh_pierces',
    'the flesh pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_prayer', 'tag_unity', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_healing',
    'mood_softness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cf8a2fe6-3d18-400d-8fea-9e8b8e2fab27',
    'the last veil pierces',
    'psalm_329__the_last_veil_pierces',
    'the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_patience', 'tag_solace', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_healing',
    'cat_creation',
    'mood_grief',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '611af0c2-df90-4e7e-a3b1-b8bc1b80c104',
    'the black flesh falls',
    'psalm_330__the_black_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_patience', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_contemplation',
    'mood_grief',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'be6a684f-71e6-4fae-8f38-a9c84f5bbe50',
    'the silent mirror rises',
    'psalm_331__the_silent_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_love', 'tag_melancholy', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_healing',
    'cat_praise',
    'mood_grief',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '50a4b040-c1de-4f83-8829-363236ff2d5d',
    'the holy voice falls',
    'psalm_332__the_holy_voice_falls',
    'the voice falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_silence', 'tag_stillness', 'tag_solace', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_exile',
    'mood_softness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '516d41c5-1e53-4c44-b733-453deba5c115',
    'calling',
    'psalm_333__the_burning_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystical', 'tag_kali', 'tag_patience', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_creation',
    'mood_boldness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a79fbf3c-3514-428d-a2e9-2b21a092751a',
    'burning',
    'psalm_334__the_silent_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_patience', 'tag_spoken', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_healing',
    'mood_boldness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2489e039-51c5-4837-a381-8c58ef631fb1',
    'the broken lamb waits',
    'psalm_335__the_broken_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_silesian', 'tag_truth', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_exile',
    'mood_reverence',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3ea9376e-e348-4deb-99e6-5da337be6b15',
    'the silent tongue calls',
    'psalm_336__the_silent_tongue_calls',
    'the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_spiritual', 'tag_reflection', 'tag_patience', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_praise',
    'mood_boldness',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f1853829-e9c3-4b5a-b547-ced083890147',
    'the glorious mirror shakes',
    'psalm_337__the_glorious_mirror_shakes',
    'the mirror shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_love', 'tag_light', 'tag_roots', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b26fe114-e037-425a-8c99-19b74ae13775',
    'singing',
    'psalm_338__the_silent_psalm_sings',
    'the psalm sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_love', 'tag_reflection', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_anointing',
    'cat_lament',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1df3d296-1968-4761-9b29-ec7aee10c3aa',
    'the silent flesh falls',
    'psalm_339__the_silent_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_silence', 'tag_peace', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_trust',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '23a49e15-d504-4407-8bb3-2633069fa744',
    'the white flesh pierces',
    'psalm_340__the_white_flesh_pierces',
    'the flesh pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_prayer', 'tag_sacrifice', 'tag_peace', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_justice',
    'mood_solace',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd3b647db-0ae5-4125-84cf-849eeab1444d',
    'rising',
    'psalm_341__the_holy_psalm_rises',
    'the psalm rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_unity', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_wembley',
    'cat_mysticism',
    'mood_trust',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a613c2d5-2bde-4920-b213-21765c47e946',
    'the wounded flame burns',
    'psalm_342__the_wounded_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_melancholy', 'tag_trust', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_exile',
    'mood_solace',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '856f9bd0-cf89-4357-8f6f-11f164e51b6b',
    'the holy tongue burns',
    'psalm_343__the_holy_tongue_burns',
    'the tongue burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_reflection', 'tag_strength', 'tag_vision', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_healing',
    'mood_joy',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8923edcc-4037-4608-b35f-22dfe6a39c01',
    'the last veil bleeds',
    'psalm_344__the_last_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_light', 'tag_strength', 'tag_stillness', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_exile',
    'mood_grief',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '79a6fba2-6207-4c15-a8c6-07dbf397bdf1',
    'the glorious shadow pierces',
    'psalm_345__the_glorious_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_solace', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_lament',
    'mood_yearning',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7f767bdf-5d38-4f01-b296-eeb0aefc02b1',
    'the black psalm waits',
    'psalm_346__the_black_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_sacrifice', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_mysticism',
    'mood_joy',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd7db626f-6cdd-4cc5-af26-b57fc91e2f05',
    'the broken flesh rises',
    'psalm_347__the_broken_flesh_rises',
    'the flesh rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_spoken', 'tag_silesian', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_lament',
    'mood_trust',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3d0027f4-b743-4dc7-9695-6ce7f2abdc2f',
    'the glorious sword calls',
    'psalm_348__the_glorious_sword_calls',
    'the sword calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_peace', 'tag_tears', 'tag_vision', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_exile',
    'mood_awe',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1bcdfd80-b1d9-4230-a23c-232cc4685bd5',
    'the glorious flesh burns',
    'psalm_349__the_glorious_flesh_burns',
    'the flesh burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_silesian', 'tag_light'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b9107b40-13c3-406b-bb67-efcc6a4cf357',
    'the black mirror rises',
    'psalm_350__the_black_mirror_rises',
    'the mirror rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystery', 'tag_renewal', 'tag_peace', 'tag_wisdom', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_anointing',
    'cat_praise',
    'mood_solace',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'eaf06048-fb34-4bf1-bd8b-09589d74833a',
    'burning',
    'psalm_351__the_burning_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_silesian', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_anointing',
    'cat_lament',
    'mood_softness',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '83fba724-ac39-4d47-b93d-ccec53877c88',
    'the broken lamb shakes',
    'psalm_352__the_broken_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_patience', 'tag_solace', 'tag_stillness', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4b53d251-5c4d-4e6f-ba4f-d250ecb43715',
    'the glorious flame pierces',
    'psalm_353__the_glorious_flame_pierces',
    'the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_reflection', 'tag_sacrifice', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_grief',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5f3a7fb9-33da-430f-b976-385ac0fb992e',
    'the broken flesh shakes',
    'psalm_354__the_broken_flesh_shakes',
    'the flesh shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_peace', 'tag_spiritual', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_coronation',
    'cat_mysticism',
    'mood_awe',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '54df8f7b-6daa-4a6b-bbc9-2858a067b0d9',
    'the black flesh pierces',
    'psalm_355__the_black_flesh_pierces',
    'the flesh pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_trust', 'tag_vision', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_praise',
    'mood_boldness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '699ce323-7909-4f00-aaa3-2f55743b6b40',
    'the holy shadow shakes',
    'psalm_356__the_holy_shadow_shakes',
    'the shadow shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_solace', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3d8353d2-cec6-4c3f-a769-774d93c64dce',
    'rising',
    'psalm_357__the_glorious_psalm_rises',
    'the psalm rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_patience', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_lament',
    'mood_trust',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cd1c1741-1ef9-4abd-ab57-ef673528386e',
    'waiting',
    'psalm_358__the_white_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_melancholy', 'tag_strength', 'tag_silesian', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_healing',
    'mood_trust',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0b7e6a9f-d096-4a52-89bb-0147894424ff',
    'the hidden sword waits',
    'psalm_359__the_hidden_sword_waits',
    'the sword waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_silence', 'tag_strength', 'tag_wisdom', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_coronation',
    'cat_creation',
    'mood_yearning',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'de4b5bf5-3bff-4b58-91ef-013b9884ad3e',
    'the last sword waits',
    'psalm_360__the_last_sword_waits',
    'the sword waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_tears', 'tag_light'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_wembley',
    'cat_justice',
    'mood_trust',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1019a08c-d1c0-4a99-b870-73658627dcdf',
    'burning',
    'psalm_361__the_white_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_mystical', 'tag_silence', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_coronation',
    'cat_mysticism',
    'mood_awe',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd9428499-5076-493a-8aed-c26731a9cade',
    'the wounded flesh pierces',
    'psalm_362__the_wounded_flesh_pierces',
    'the flesh pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_sacrifice', 'tag_light'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_praise',
    'mood_softness',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '476ad0ff-7a18-4ea6-9726-44e36d1fc512',
    'bleeding',
    'psalm_363__the_holy_psalm_bleeds',
    'the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_unity', 'tag_sacrifice', 'tag_silesian', 'tag_melancholy', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_lament',
    'mood_joy',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c957c5db-763c-49b2-a4d3-12181ea08ee3',
    'the last flame wakes',
    'psalm_364__the_last_flame_wakes',
    'the flame wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_trust', 'tag_roots', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_grief',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e23363ab-7f85-447a-9306-4c9a7ce820b3',
    'the white voice falls',
    'psalm_365__the_white_voice_falls',
    'the voice falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_mystery', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_funeral',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1e97cba5-ec11-4612-aa3b-dd8135f1ef99',
    'the white voice bleeds',
    'psalm_366__the_white_voice_bleeds',
    'the voice bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_patience', 'tag_prayer', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_wembley',
    'cat_lament',
    'mood_trust',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6821f373-a2b6-4f38-9724-21cd856a76ad',
    'the wounded veil bleeds',
    'psalm_367__the_wounded_veil_bleeds',
    'the veil bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_mystery', 'tag_vision', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_creation',
    'mood_reverence',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '78267da6-af60-45f3-8a4b-260796dffc69',
    'the hidden flesh bleeds',
    'psalm_368__the_hidden_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_roots', 'tag_spiritual', 'tag_spoken', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_creation',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0b8c8cf1-e69c-4ca9-87aa-fa9a78c0ff5d',
    'the wounded mirror sings',
    'psalm_369__the_wounded_mirror_sings',
    'the mirror sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_vision', 'tag_rebirth', 'tag_trust', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_exile',
    'mood_boldness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '79c2be57-b7de-4162-a2ab-37786e6aaaa5',
    'the black voice bleeds',
    'psalm_370__the_black_voice_bleeds',
    'the voice bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_melancholy', 'tag_mystery', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_justice',
    'mood_joy',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a52a5aa8-f513-4c2c-b768-ca480e556942',
    'the wounded sword shakes',
    'psalm_371__the_wounded_sword_shakes',
    'the sword shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_peace', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_justice',
    'mood_reverence',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '09f5bd42-bc65-484b-ae8d-4d2826f8cd0a',
    'the black veil falls',
    'psalm_372__the_black_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_melancholy', 'tag_silence', 'tag_trust', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_healing',
    'mood_awe',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ce3e8acb-f5f9-40b2-96cf-f2a681f3a766',
    'the last shadow rises',
    'psalm_373__the_last_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_strength', 'tag_love', 'tag_patience', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5f7a1713-5786-4889-8306-5432b927f2dd',
    'the glorious tongue pierces',
    'psalm_374__the_glorious_tongue_pierces',
    'the tongue pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_vision', 'tag_rebirth', 'tag_wisdom', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_praise',
    'mood_solace',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '714f4537-b6de-4839-a43b-2d3ca5fbb519',
    'the white mirror pierces',
    'psalm_375__the_white_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_spoken', 'tag_tears', 'tag_truth', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_blessing',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3e2e2813-8328-483d-9b8c-ddec7bbc1fa2',
    'the black lamb shakes',
    'psalm_376__the_black_lamb_shakes',
    'the lamb shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_reflection', 'tag_kali', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_healing',
    'mood_grief',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3cd679b9-515a-4d04-a714-d81b69b35d06',
    'the wounded tongue burns',
    'psalm_377__the_wounded_tongue_burns',
    'the tongue burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_light', 'tag_vision', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '38d2d32e-65e1-4d5a-a876-8f55b13ad4ae',
    'the hidden sword wakes',
    'psalm_378__the_hidden_sword_wakes',
    'the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_prayer', 'tag_silence', 'tag_spiritual', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_coronation',
    'cat_exile',
    'mood_awe',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2c3aaf18-9332-4227-9aad-14927d1a1ca5',
    'the last shadow waits',
    'psalm_379__the_last_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_reflection', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_anointing',
    'cat_healing',
    'mood_joy',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1fac27ec-9ef2-431b-939b-b8610a18e80c',
    'the glorious tongue pierces',
    'psalm_380__the_glorious_tongue_pierces',
    'the tongue pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_light', 'tag_melancholy', 'tag_silesian', 'tag_spiritual', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_glitch',
    'cat_mysticism',
    'mood_reverence',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '11493f70-db96-4309-b9b9-bd4b162fbf1b',
    'the burning shadow rises',
    'psalm_381__the_burning_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_love', 'tag_tears', 'tag_sacrifice', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_praise',
    'mood_joy',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9f6bd430-3177-4c10-9661-49d45fe2bef7',
    'the broken flesh wakes',
    'psalm_382__the_broken_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_patience', 'tag_renewal', 'tag_love', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_funeral',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '97bfa015-1182-4723-a620-acf9cd991aff',
    'the white flesh falls',
    'psalm_383__the_white_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_unity', 'tag_patience', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_healing',
    'cat_exile',
    'mood_sorrow',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e3e4ad52-f9f1-4b49-a124-7137740e168c',
    'the glorious tongue bleeds',
    'psalm_384__the_glorious_tongue_bleeds',
    'the tongue bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_tears', 'tag_spoken', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_exodus',
    'cat_lament',
    'mood_joy',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '71fccc48-fa14-4cfa-acc1-2ae9eec80e3f',
    'the holy flame burns',
    'psalm_385__the_holy_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_love', 'tag_vision', 'tag_unity', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_healing',
    'mood_trust',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cbb72fea-f55f-48ad-b73e-625af6be78df',
    'bleeding',
    'psalm_386__the_black_psalm_bleeds',
    'the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_solace', 'tag_silesian', 'tag_prayer', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_anointing',
    'cat_lament',
    'mood_reverence',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e2d7c724-dd86-45e8-af3a-566e97fedcb2',
    'the white shadow rises',
    'psalm_387__the_white_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_renewal', 'tag_peace', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_healing',
    'cat_contemplation',
    'mood_yearning',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '41459b82-28d1-49a5-a1ed-ed18521fb4ed',
    'the holy shadow rises',
    'psalm_388__the_holy_shadow_rises',
    'the shadow rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_tears', 'tag_vision', 'tag_light', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_funeral',
    'cat_justice',
    'mood_boldness',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '679f6122-cd4a-477e-addb-cbd321318dc7',
    'the holy flesh burns',
    'psalm_389__the_holy_flesh_burns',
    'the flesh burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_patience', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_creation',
    'mood_solace',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '51cc96fc-4d9a-448c-ac81-b4dc395774f2',
    'the wounded voice sings',
    'psalm_390__the_wounded_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_sacrifice', 'tag_kali', 'tag_strength', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_mysticism',
    'mood_solace',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9cd9bf81-6de9-484f-94c3-78baa8cfba8a',
    'the broken lamb waits',
    'psalm_391__the_broken_lamb_waits',
    'the lamb waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_truth', 'tag_light'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_wembley',
    'cat_mysticism',
    'mood_joy',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1d5d3208-338a-4230-bcbb-500c17842991',
    'the holy lamb wakes',
    'psalm_392__the_holy_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_reflection', 'tag_spiritual', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_exile',
    'mood_trust',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2447a21e-888a-4d1f-93a7-d1f681cc72bc',
    'the wounded veil pierces',
    'psalm_393__the_wounded_veil_pierces',
    'the veil pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_spiritual', 'tag_sacrifice', 'tag_silence', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_yearning',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f82461e2-3ece-4e64-a7ce-c6b61813c6b0',
    'piercing',
    'psalm_394__the_burning_psalm_pierces',
    'the psalm pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_reflection', 'tag_love', 'tag_mystical', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_lamentation',
    'cat_lament',
    'mood_yearning',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '30babbf8-69d9-4a85-bf2a-7c2076c8e428',
    'waking',
    'psalm_395__the_last_psalm_wakes',
    'the psalm wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_peace', 'tag_tears', 'tag_strength', 'tag_wisdom', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_healing',
    'cat_praise',
    'mood_trust',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9a74b283-95a6-4898-ba27-f3e0f1e92c9a',
    'the burning mirror bleeds',
    'psalm_396__the_burning_mirror_bleeds',
    'the mirror bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_mystery', 'tag_strength', 'tag_patience', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_fasting',
    'cat_mysticism',
    'mood_sorrow',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5d16536f-bff4-4a43-8037-02fc24096dae',
    'the last flame calls',
    'psalm_397__the_last_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_vision', 'tag_truth', 'tag_spiritual', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_coronation',
    'cat_creation',
    'mood_joy',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9a6715f2-1ca5-454f-a3f0-6c10a8f18ff6',
    'the black psalm waits',
    'psalm_398__the_black_psalm_waits',
    'the psalm waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_mystery', 'tag_tears', 'tag_stillness', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_dedication',
    'cat_mysticism',
    'mood_solace',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a68fc3a8-e0f0-4283-b095-e76903dedce7',
    'the last shadow shakes',
    'psalm_399__the_last_shadow_shakes',
    'the shadow shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_mystery', 'tag_trust', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_sabbath',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '22d63a25-1801-4d2b-8bcf-d16ff4cd9c7f',
    'the hidden lamb rises',
    'psalm_400__the_hidden_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_truth', 'tag_patience', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:28:13',
    '2025-07-05 21:28:13',
    'rit_wembley',
    'cat_creation',
    'mood_reverence',
    'arch_the_weaver'
);