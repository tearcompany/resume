## Stróż Światła

Short title: Stróż Światła  
Hebrew: ח  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Świeć nawet wtedy, gdy nikt nie patrzy.

świeć  
gdy nikt nie patrzy

bądź  
tam, gdzie wszyscy zgasili  
nie czekaj na pochwałę

jesteś światłem  
nawet gdy jesteś sam

noc  
nie ma do Ciebie dostępu