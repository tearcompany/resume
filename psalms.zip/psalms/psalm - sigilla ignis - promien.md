## Promień

Short title: Promień  
Hebrew: ז  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Nie idź szeroko — idź jasno.

nie musisz iść szeroko

wystarczy  
iść jasno

jeden promień  
rozdziera mrok

mała iskra  
przekracza noc

światło  
które wybiera miejsce