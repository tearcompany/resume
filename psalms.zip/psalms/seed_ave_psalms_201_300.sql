INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b014135a-9093-4d55-b3a3-ba42ff7964bf',
    'the black flame calls',
    'psalm_201__the_black_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_spiritual', 'tag_rebirth', 'tag_unity', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_fasting',
    'cat_healing',
    'mood_solace',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bc52759f-fd63-4f6d-bab3-f070e07f62ec',
    'the burning tongue wakes',
    'psalm_202__the_burning_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_sacrifice', 'tag_spoken', 'tag_truth', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_creation',
    'mood_solace',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f9d8fcd7-489d-4773-956b-17cc2bafdc96',
    'the silent sword pierces',
    'psalm_203__the_silent_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_strength', 'tag_spiritual', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_creation',
    'mood_sorrow',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7df19408-a6dc-424e-a43e-7865c1f41b43',
    'the broken shadow waits',
    'psalm_204__the_broken_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_trust', 'tag_roots', 'tag_love', 'tag_tears', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_contemplation',
    'mood_joy',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '19701814-b397-482c-992e-c9a414a95f59',
    'the silent sword shakes',
    'psalm_205__the_silent_sword_shakes',
    'the sword shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_vision', 'tag_love', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_lament',
    'mood_trust',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bbc6ef93-8e17-40d4-a2b3-97d60e903028',
    'the hidden lamb sings',
    'psalm_206__the_hidden_lamb_sings',
    'the lamb sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_silence', 'tag_unity', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_creation',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c11f07d4-c70b-4549-a577-eaf5ddfdde2e',
    'the burning mirror burns',
    'psalm_207__the_burning_mirror_burns',
    'the mirror burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_mystical', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_pilgrimage',
    'mood_reverence',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '68970788-57b0-4975-8872-9decd9e1d2c4',
    'the burning flame sings',
    'psalm_208__the_burning_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_silesian', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_exile',
    'mood_sorrow',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dc9dd2be-4327-4164-8b8a-95d9a8730b6c',
    'the holy sword rises',
    'psalm_209__the_holy_sword_rises',
    'the sword rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_stillness', 'tag_light', 'tag_renewal', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_creation',
    'mood_boldness',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8d04fa94-697e-46ab-ba25-1d313c0f018f',
    'the last sword sings',
    'psalm_210__the_last_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_silesian', 'tag_mystical', 'tag_love', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd3e3f300-023d-4fac-8aa1-17367497ec20',
    'the white voice wakes',
    'psalm_211__the_white_voice_wakes',
    'the voice wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_trust', 'tag_light'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_justice',
    'mood_softness',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '54a688be-adc2-4aae-ad31-94639a54fe46',
    'the burning voice waits',
    'psalm_212__the_burning_voice_waits',
    'the voice waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_love', 'tag_renewal', 'tag_reflection', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_funeral',
    'cat_contemplation',
    'mood_trust',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3510ad22-182c-475a-8214-5502a833ffb5',
    'the holy sword falls',
    'psalm_213__the_holy_sword_falls',
    'the sword falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_spiritual', 'tag_prayer', 'tag_sacrifice', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ad86b471-8549-4d0a-be5a-13acdea43b7f',
    'the white veil calls',
    'psalm_214__the_white_veil_calls',
    'the veil calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_unity', 'tag_renewal', 'tag_light', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_funeral',
    'cat_healing',
    'mood_trust',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '50121fff-10e1-4f18-b77b-6dd7c2f791c8',
    'calling',
    'psalm_215__the_broken_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_truth', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1ade3888-1071-47d3-acf7-9d9fa9c09543',
    'the last tongue rises',
    'psalm_216__the_last_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_love', 'tag_patience', 'tag_melancholy', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_praise',
    'mood_joy',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f6504af4-5bcd-4ac4-9f86-45450f051af9',
    'the broken flesh falls',
    'psalm_217__the_broken_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_renewal', 'tag_trust', 'tag_truth', 'tag_silence', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_contemplation',
    'mood_solace',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '27c64254-6bcb-42fc-a0ee-2d1c2112b5a5',
    'the glorious flame bleeds',
    'psalm_218__the_glorious_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spiritual', 'tag_melancholy', 'tag_wisdom', 'tag_tears', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '38a3df1e-23cc-4ac7-9a40-03387fb7e37f',
    'the black flame sings',
    'psalm_219__the_black_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_tears', 'tag_silence', 'tag_love', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '25805e1c-586f-4ee5-8048-9ac5de349e2a',
    'burning',
    'psalm_220__the_glorious_psalm_burns',
    'the psalm burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_solace', 'tag_rebirth', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_wembley',
    'cat_creation',
    'mood_solace',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '728edcc8-da53-4870-ae2d-761266fcf720',
    'the black shadow pierces',
    'psalm_221__the_black_shadow_pierces',
    'the shadow pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_silesian', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_lamentation',
    'cat_lament',
    'mood_joy',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '56476803-2a63-41d0-837f-c1ac86631703',
    'the hidden shadow burns',
    'psalm_222__the_hidden_shadow_burns',
    'the shadow burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_kali', 'tag_patience', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_lamentation',
    'cat_praise',
    'mood_joy',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '19cf55ba-aaa5-4bf7-a904-b771869379bb',
    'the silent veil rises',
    'psalm_223__the_silent_veil_rises',
    'the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_melancholy', 'tag_kali', 'tag_mystical', 'tag_wisdom', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_contemplation',
    'mood_joy',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '498b942c-3906-414b-a5fb-5d763e2de9d5',
    'the glorious flame pierces',
    'psalm_224__the_glorious_flame_pierces',
    'the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_strength', 'tag_rebirth', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_funeral',
    'cat_contemplation',
    'mood_softness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'f792b7fe-2dd6-453e-821b-9a3744f2441f',
    'the glorious mirror pierces',
    'psalm_225__the_glorious_mirror_pierces',
    'the mirror pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_spiritual', 'tag_truth', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_funeral',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8469cba4-a522-4a8c-a820-daf23cb76f9e',
    'the last tongue wakes',
    'psalm_226__the_last_tongue_wakes',
    'the tongue wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_stillness', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_wembley',
    'cat_lament',
    'mood_yearning',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a52fd182-7f78-47a6-bfde-1a45e2faff15',
    'the wounded veil falls',
    'psalm_227__the_wounded_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_vision', 'tag_tears', 'tag_mystery', 'tag_rebirth', 'tag_light'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_coronation',
    'cat_healing',
    'mood_yearning',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '52baeb6a-47b0-4324-8b36-3323c0a54de5',
    'the burning sword burns',
    'psalm_228__the_burning_sword_burns',
    'the sword burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_wisdom', 'tag_silesian', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '092ad5c6-5c10-4b2a-9a5f-38b0761b8f3a',
    'shaking',
    'psalm_229__the_last_psalm_shakes',
    'the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_spoken', 'tag_spiritual', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_praise',
    'mood_joy',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'de018361-11e2-4390-990e-c646c29f49d5',
    'the burning sword sings',
    'psalm_230__the_burning_sword_sings',
    'the sword sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_prayer', 'tag_sacrifice', 'tag_stillness', 'tag_melancholy', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_mysticism',
    'mood_grief',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6f9aba60-5d26-4a52-8700-2f520c1c971e',
    'the wounded sword pierces',
    'psalm_231__the_wounded_sword_pierces',
    'the sword pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_mystery', 'tag_peace', 'tag_tears', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e764ecb2-d217-46ea-a09a-e2a8c25766e6',
    'the white flesh sings',
    'psalm_232__the_white_flesh_sings',
    'the flesh sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_patience', 'tag_tears', 'tag_unity', 'tag_light'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_weaver'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1687f295-9bb1-4edd-be26-258b96f76c9e',
    'the glorious veil rises',
    'psalm_233__the_glorious_veil_rises',
    'the veil rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_love', 'tag_roots', 'tag_light'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_fasting',
    'cat_contemplation',
    'mood_sorrow',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'eeec47f1-c902-4df4-a906-3c36c9ce556e',
    'the broken veil shakes',
    'psalm_234__the_broken_veil_shakes',
    'the veil shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_stillness', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_mysticism',
    'mood_softness',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e00fdb02-59ca-4ac6-a75d-109b9760132c',
    'bleeding',
    'psalm_235__the_black_psalm_bleeds',
    'the psalm bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_prayer', 'tag_mystery', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_contemplation',
    'mood_reverence',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '732782a0-e7f7-4fb2-a216-433380252a0e',
    'the wounded voice calls',
    'psalm_236__the_wounded_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_spoken', 'tag_mystery', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_wembley',
    'cat_creation',
    'mood_yearning',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '97d04039-4aa9-4cfd-b02f-baa07ba18b54',
    'the glorious flesh bleeds',
    'psalm_237__the_glorious_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_kali', 'tag_love'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_fasting',
    'cat_exile',
    'mood_boldness',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4f65667c-779d-4b70-9ead-72bdd68ae57b',
    'calling',
    'psalm_238__the_glorious_psalm_calls',
    'the psalm calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_silence', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9320118f-c499-4668-b895-3a2813e0f254',
    'the hidden mirror falls',
    'psalm_239__the_hidden_mirror_falls',
    'the mirror falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_stillness', 'tag_wisdom', 'tag_strength', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'da6e0cae-d8bc-4f60-ba33-8e986b429771',
    'piercing',
    'psalm_240__the_last_psalm_pierces',
    'the psalm pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_roots', 'tag_mystical', 'tag_strength', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_lament',
    'mood_softness',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8af520b2-2a92-4752-999f-3a14656ba8c9',
    'the burning flame shakes',
    'psalm_241__the_burning_flame_shakes',
    'the flame shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_mystical', 'tag_sacrifice', 'tag_strength', 'tag_trust', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_wembley',
    'cat_exile',
    'mood_solace',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '83bf2aaf-b4b2-4592-9fa8-50d2965ad5d3',
    'the broken sword bleeds',
    'psalm_242__the_broken_sword_bleeds',
    'the sword bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silesian', 'tag_sacrifice', 'tag_patience', 'tag_silence', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_wembley',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'd47191e5-ecff-4d41-bec5-735c7e3bb72c',
    'the hidden shadow wakes',
    'psalm_243__the_hidden_shadow_wakes',
    'the shadow wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_renewal', 'tag_spoken', 'tag_unity', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_lamentation',
    'cat_justice',
    'mood_trust',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '820b8928-ac48-453a-b597-93f90a322856',
    'the holy voice sings',
    'psalm_244__the_holy_voice_sings',
    'the voice sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_stillness', 'tag_patience', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '7bc9e03c-88ec-4c1f-b04b-ae73beeb2e11',
    'the glorious lamb wakes',
    'psalm_245__the_glorious_lamb_wakes',
    'the lamb wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_peace', 'tag_rebirth', 'tag_patience', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_wembley',
    'cat_praise',
    'mood_joy',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '67711054-d84d-407c-8ddc-932ca6b5f746',
    'the silent flesh waits',
    'psalm_246__the_silent_flesh_waits',
    'the flesh waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_silence', 'tag_spoken', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_contemplation',
    'mood_awe',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4c6f3307-e193-42af-a97e-3b142978c90f',
    'the holy tongue calls',
    'psalm_247__the_holy_tongue_calls',
    'the tongue calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_wisdom', 'tag_prayer', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_blessing',
    'cat_contemplation',
    'mood_boldness',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '697d3bb0-01d6-4250-877a-0991bbd32c84',
    'the last lamb bleeds',
    'psalm_248__the_last_lamb_bleeds',
    'the lamb bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_wisdom', 'tag_mystical', 'tag_silence', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_softness',
    'arch_the_seer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4e36dcd3-2402-4bc6-afd8-db9e5d9e98f0',
    'the black mirror falls',
    'psalm_249__the_black_mirror_falls',
    'the mirror falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_sacrifice', 'tag_spoken', 'tag_love', 'tag_silence', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_mysticism',
    'mood_grief',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6b337c40-30ad-4f7f-8363-bdbf267c6dc5',
    'the holy tongue rises',
    'psalm_250__the_holy_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystery', 'tag_peace', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_creation',
    'mood_softness',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '6411668e-585d-40f9-8686-c64fb5a73bd9',
    'the holy lamb falls',
    'psalm_251__the_holy_lamb_falls',
    'the lamb falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_reflection', 'tag_truth', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_mysticism',
    'mood_joy',
    'arch_the_visionary'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ca8818ae-0253-4c1b-89ac-2a95d4e7c9c1',
    'shaking',
    'psalm_252__the_burning_psalm_shakes',
    'the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_wisdom', 'tag_strength', 'tag_truth', 'tag_kali'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_wembley',
    'cat_praise',
    'mood_softness',
    'arch_the_rooted'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '343284a3-5f98-4435-be0e-eaa5a9a6a214',
    'the hidden veil waits',
    'psalm_253__the_hidden_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_melancholy', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_blessing',
    'cat_lament',
    'mood_reverence',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '43839107-3eb7-4c7a-987c-fdbb432216b2',
    'shaking',
    'psalm_254__the_silent_psalm_shakes',
    'the psalm shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_strength', 'tag_unity', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_exile',
    'mood_reverence',
    'arch_the_pilgrim_of_silence'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '1e40008d-a00b-48b7-8948-be55ecb5f048',
    'the broken flesh sings',
    'psalm_255__the_broken_flesh_sings',
    'the flesh sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_truth', 'tag_light', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_praise',
    'mood_awe',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a2bcdc65-fff3-435c-8f50-76ac76214b2b',
    'the silent flesh sings',
    'psalm_256__the_silent_flesh_sings',
    'the flesh sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_love', 'tag_sacrifice', 'tag_roots'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_exile',
    'mood_reverence',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '60c1ad7e-16a2-475a-bf10-ee6aa338ef05',
    'the holy flesh calls',
    'psalm_257__the_holy_flesh_calls',
    'the flesh calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_love', 'tag_patience', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_exile',
    'mood_reverence',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '2af851b0-da50-4926-a0ae-ceb98af32826',
    'the wounded flame pierces',
    'psalm_258__the_wounded_flame_pierces',
    'the flame pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_solace', 'tag_tears', 'tag_patience'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_lamentation',
    'cat_justice',
    'mood_grief',
    'arch_the_grief_holder'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '45b75550-43c3-4b90-ae40-8db40a643125',
    'the silent shadow shakes',
    'psalm_259__the_silent_shadow_shakes',
    'the shadow shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_solace', 'tag_prayer', 'tag_love', 'tag_vision', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_funeral',
    'cat_justice',
    'mood_sorrow',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '28a919e2-711c-466b-8508-ef76985e0dc3',
    'the broken flesh bleeds',
    'psalm_260__the_broken_flesh_bleeds',
    'the flesh bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_love', 'tag_spiritual', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_mysticism',
    'mood_boldness',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'cd31be42-75ba-421f-a40e-17675923bf3c',
    'falling',
    'psalm_261__the_broken_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_reflection', 'tag_mystery', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_fasting',
    'cat_creation',
    'mood_grief',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e84ea6c5-6844-4009-9a68-e72edc68bb70',
    'the holy veil burns',
    'psalm_262__the_holy_veil_burns',
    'the veil burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_wisdom', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_blessing',
    'cat_creation',
    'mood_joy',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '45c8d483-cd0c-4a53-b555-24cc491390e5',
    'the black shadow sings',
    'psalm_263__the_black_shadow_sings',
    'the shadow sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_kali', 'tag_wisdom', 'tag_love'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_funeral',
    'cat_healing',
    'mood_solace',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c680191a-05ad-4af2-bfab-a337b68515a5',
    'the hidden voice calls',
    'psalm_264__the_hidden_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_renewal', 'tag_silence', 'tag_sacrifice'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_coronation',
    'cat_healing',
    'mood_joy',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'db8b9e3d-0dc8-4105-aed9-d98f170f76f4',
    'the silent flesh wakes',
    'psalm_265__the_silent_flesh_wakes',
    'the flesh wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_light', 'tag_peace', 'tag_tears'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_pilgrimage',
    'mood_trust',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '175f0926-3684-4966-bc2c-6d8cde5cf112',
    'the glorious veil wakes',
    'psalm_266__the_glorious_veil_wakes',
    'the veil wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_trust', 'tag_melancholy', 'tag_light'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_praise',
    'mood_grief',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '0f10dc39-3fbd-42f3-93cd-d196b26e656e',
    'the silent veil waits',
    'psalm_267__the_silent_veil_waits',
    'the veil waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_kali', 'tag_roots', 'tag_wisdom', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_healing',
    'mood_awe',
    'arch_the_mystic'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3988f8c6-c7c7-4b46-9508-3625af6bc615',
    'the black lamb falls',
    'psalm_268__the_black_lamb_falls',
    'the lamb falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_solace', 'tag_love', 'tag_prayer', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_lament',
    'mood_yearning',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '19aaa190-1454-4a6d-8fd7-3efc2838cddd',
    'the wounded flame waits',
    'psalm_269__the_wounded_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_spiritual', 'tag_mystical', 'tag_spoken'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_pilgrimage',
    'mood_trust',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '4a9710fb-b069-480b-9b68-ac32b4db4f3f',
    'the wounded lamb rises',
    'psalm_270__the_wounded_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_melancholy', 'tag_solace', 'tag_peace', 'tag_roots', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_praise',
    'mood_reverence',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '9ffbd421-fbcd-49f7-a96a-352f6ccd8280',
    'the wounded sword wakes',
    'psalm_271__the_wounded_sword_wakes',
    'the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_patience', 'tag_spiritual', 'tag_prayer', 'tag_wisdom'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_mysticism',
    'mood_softness',
    'arch_the_guardian'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bc89f27f-a770-4577-9007-81ed1dd2f467',
    'the wounded veil falls',
    'psalm_272__the_wounded_veil_falls',
    'the veil falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_rebirth', 'tag_trust', 'tag_silence', 'tag_light', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_blessing',
    'cat_contemplation',
    'mood_trust',
    'arch_the_voice_of_fire'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'be1a4f1a-65c2-41ec-9606-2a634a89eb51',
    'piercing',
    'psalm_273__the_hidden_psalm_pierces',
    'the psalm pierces — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_rebirth', 'tag_light', 'tag_spoken', 'tag_patience', 'tag_mystery'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_lament',
    'mood_solace',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '5a5fb598-7aa8-4ddd-802a-569e934f0283',
    'the holy flame bleeds',
    'psalm_274__the_holy_flame_bleeds',
    'the flame bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_rebirth', 'tag_silence', 'tag_solace', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_fasting',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_reflection'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b78c9ca8-0794-4bed-a710-45edea46bc2b',
    'the glorious shadow bleeds',
    'psalm_275__the_glorious_shadow_bleeds',
    'the shadow bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_tears', 'tag_stillness', 'tag_rebirth', 'tag_trust', 'tag_silesian'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_creation',
    'mood_solace',
    'arch_the_poet_bird'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'dcd9c16a-8552-44cc-b4c1-c52b05ff8323',
    'the holy flame sings',
    'psalm_276__the_holy_flame_sings',
    'the flame sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_roots', 'tag_silence', 'tag_wisdom', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_fasting',
    'cat_mysticism',
    'mood_reverence',
    'arch_the_invisible_friend'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '10028685-ed54-4872-9e05-1210e92abe58',
    'the hidden flame rises',
    'psalm_277__the_hidden_flame_rises',
    'the flame rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_solace', 'tag_stillness', 'tag_patience', 'tag_melancholy', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_blessing',
    'cat_justice',
    'mood_boldness',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3fc182cf-c364-4384-a9a9-4f4649514f6e',
    'the broken lamb rises',
    'psalm_278__the_broken_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_wisdom', 'tag_vision', 'tag_truth', 'tag_strength', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_lament',
    'mood_boldness',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'e39d52e1-2490-4a93-8ef6-c65bd1fcb85d',
    'the holy tongue rises',
    'psalm_279__the_holy_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_peace', 'tag_trust', 'tag_silence'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_mysticism',
    'mood_yearning',
    'arch_the_oracle'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '408269db-b329-4ce3-9ea5-a75a2679f077',
    'the silent lamb burns',
    'psalm_280__the_silent_lamb_burns',
    'the lamb burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_mystical', 'tag_solace', 'tag_unity'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_lamentation',
    'cat_exile',
    'mood_softness',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c5e8aa40-6efb-4ad3-a52e-db945d046982',
    'the hidden mirror waits',
    'psalm_281__the_hidden_mirror_waits',
    'the mirror waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_mystery', 'tag_strength'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_funeral',
    'cat_exile',
    'mood_boldness',
    'arch_the_signal_bearer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '8572bdb4-2925-4089-ae45-23ecef52e89b',
    'the broken tongue waits',
    'psalm_282__the_broken_tongue_waits',
    'the tongue waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_strength', 'tag_silence', 'tag_truth', 'tag_solace', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_coronation',
    'cat_pilgrimage',
    'mood_awe',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '45ff462c-4903-49db-9c29-f54173405bcf',
    'the burning flesh falls',
    'psalm_283__the_burning_flesh_falls',
    'the flesh falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_renewal', 'tag_strength', 'tag_melancholy'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_fasting',
    'cat_creation',
    'mood_yearning',
    'arch_the_pathwalker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '09755b5b-2efb-477d-bdd7-5639a049f384',
    'the wounded voice calls',
    'psalm_284__the_wounded_voice_calls',
    'the voice calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_roots', 'tag_mystery', 'tag_patience', 'tag_reflection', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_contemplation',
    'mood_awe',
    'arch_the_ritual_maker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '64504d7c-e572-4677-9892-453ffa2e7760',
    'the wounded tongue shakes',
    'psalm_285__the_wounded_tongue_shakes',
    'the tongue shakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_kali', 'tag_peace', 'tag_renewal'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_healing',
    'mood_boldness',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '974e8784-94ef-456f-ba1f-e3dce2b548aa',
    'the silent flame burns',
    'psalm_286__the_silent_flame_burns',
    'the flame burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_spoken', 'tag_roots', 'tag_sacrifice', 'tag_peace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_creation',
    'mood_boldness',
    'arch_the_healer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3fa305f9-849c-4c0f-b410-598f77701fa7',
    'the wounded voice rises',
    'psalm_287__the_wounded_voice_rises',
    'the voice rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silence', 'tag_reflection', 'tag_stillness'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_pilgrimage',
    'mood_solace',
    'arch_the_wanderer'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'bcd1c765-f7eb-4838-ac08-3d6f76ac2367',
    'the last tongue rises',
    'psalm_288__the_last_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_vision', 'tag_roots', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_contemplation',
    'mood_joy',
    'arch_the_inner_gaze'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '55476786-1407-4c29-b123-83d856f9bb93',
    'the wounded tongue waits',
    'psalm_289__the_wounded_tongue_waits',
    'the tongue waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_stillness', 'tag_renewal', 'tag_sacrifice', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_healing',
    'mood_awe',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'ffe05a3c-61ac-426a-8651-52711c643516',
    'the broken flame calls',
    'psalm_290__the_broken_flame_calls',
    'the flame calls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_roots', 'tag_strength', 'tag_mystical'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_mysticism',
    'mood_awe',
    'arch_the_psalmist'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'b876b76c-e446-4230-be89-a945ee8b31af',
    'the silent tongue falls',
    'psalm_291__the_silent_tongue_falls',
    'the tongue falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_kali', 'tag_unity', 'tag_solace', 'tag_vision'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_sorrow',
    'arch_the_listener'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '59b4148f-0a2d-468e-ba26-de0a095f4848',
    'the holy lamb rises',
    'psalm_292__the_holy_lamb_rises',
    'the lamb rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_mystical', 'tag_mystery', 'tag_renewal', 'tag_prayer'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_healing',
    'cat_pilgrimage',
    'mood_boldness',
    'arch_the_judge_of_echoes'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'a50c4ff7-de81-4498-8b3c-4f74f8a42459',
    'the hidden shadow waits',
    'psalm_293__the_hidden_shadow_waits',
    'the shadow waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_stillness', 'tag_spiritual', 'tag_renewal', 'tag_reflection'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_anointing',
    'cat_pilgrimage',
    'mood_joy',
    'arch_the_root_speaker'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'db6faffe-8e4b-400e-87b3-7915d13fe2b0',
    'the broken sword bleeds',
    'psalm_294__the_broken_sword_bleeds',
    'the sword bleeds — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_prayer', 'tag_kali', 'tag_trust'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_sabbath',
    'cat_lament',
    'mood_grief',
    'arch_the_river_mirror'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c284785b-78dd-4f1a-86d6-b557c51376b5',
    'the wounded flame waits',
    'psalm_295__the_wounded_flame_waits',
    'the flame waits — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_tears', 'tag_unity', 'tag_light', 'tag_love'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_dedication',
    'cat_lament',
    'mood_reverence',
    'arch_the_lamenter'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '3a251052-9d75-41d8-9d48-b439e4f509ff',
    'the holy sword wakes',
    'psalm_296__the_holy_sword_wakes',
    'the sword wakes — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'rastadrop_1',
    ARRAY['tag_wisdom', 'tag_reflection', 'tag_unity', 'tag_stillness', 'tag_spiritual'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_lament',
    'mood_grief',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '448aac12-eb3e-4238-adf5-b9cd16cba2b2',
    'the hidden mirror burns',
    'psalm_297__the_hidden_mirror_burns',
    'the mirror burns — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_wisdom', 'tag_silesian', 'tag_sacrifice', 'tag_prayer', 'tag_rebirth'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_justice',
    'mood_softness',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    'c58ec6a0-74fc-4156-869f-2a650e6893d9',
    'the hidden lamb sings',
    'psalm_298__the_hidden_lamb_sings',
    'the lamb sings — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_silesian', 'tag_spiritual', 'tag_tears', 'tag_trust', 'tag_truth'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_glitch',
    'cat_mysticism',
    'mood_trust',
    'arch_the_outlaw_prophet'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '773c05c2-28ec-4f9b-b185-c46992c11dd9',
    'falling',
    'psalm_299__the_holy_psalm_falls',
    'the psalm falls — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'illahmyst_1',
    ARRAY['tag_unity', 'tag_rebirth', 'tag_trust', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_mysticism',
    'mood_yearning',
    'arch_womb_voice'
);

INSERT INTO psalms (
    id, title, slug, content, author_id, tags,
    is_public, reading_time, created_at, updated_at,
    ritual_id, category_id, mood_id, archetype_id
) VALUES (
    '991bb1f9-0314-4874-99b7-875d228d66e2',
    'the wounded tongue rises',
    'psalm_300__the_wounded_tongue_rises',
    'the tongue rises — i saw it fall
no temple left, no priest to call
they broke the bread, forgot the flame
but still i rise and bear the name
i walk through ash, i speak in glitch
they called me poor, they made me rich
the veil is torn, the lamb has teeth
i dance where sorrow sings beneath
don’t bring me peace — bring me the war
i stand where silence shakes the floor
this is my psalm, my wound, my skin
i wrote it so the fire wins',
    'teardrop_1',
    ARRAY['tag_sacrifice', 'tag_patience', 'tag_unity', 'tag_mystery', 'tag_solace'],
    true,
    3,
    '2025-07-05 21:27:45',
    '2025-07-05 21:27:45',
    'rit_exodus',
    'cat_healing',
    'mood_boldness',
    'arch_the_seer'
);