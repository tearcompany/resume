## Droga

Short title: Droga  
Hebrew: י  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Zgadzam się przejść — nawet jeśli nie wiem, kim będę po drugiej stronie.

zgadzam się przejść

nie wiem  
kim będę  
gdy wrócę

ale droga mnie woła

każdy krok  
jest zgodą  
na nowe imię