## Dłoń

Short title: Dłoń  
Hebrew: י  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Dłoń jest początkiem i końcem każdej drogi.

dłoń  
która dotyka  
która niesie

każda ścieżka  
zaczyna się od gestu

jestem dłonią  
jestem oddechem

wszystko zaczyna się  
i kończy na dłoni