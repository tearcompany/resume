## Objęcie

Short title: Objęcie  
Hebrew: ה  
Tag: sigilla_ignis, wisdom, guidance  
Lang: pl  
Author: rastadrop_1  
Description: Nie muszę wszystkiego wiedzieć. Wystarczy, że tkam.

nie muszę wiedzieć

wystarczy, że tkam  
nić po nici  
w blasku i mroku

obejmuję świat  
niewiedzą  
ale obecnością

moje ramiona  
to sieć światła